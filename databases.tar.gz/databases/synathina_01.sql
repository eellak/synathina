-- MySQL dump 10.13  Distrib 8.0.15, for Linux (x86_64)
--
-- Host: localhost    Database: synathina_01
-- ------------------------------------------------------
-- Server version	8.0.15

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `prefi_assets`
--

DROP TABLE IF EXISTS `prefi_assets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `prefi_assets` (
  `id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Primary Key',
  `parent_id` int(11) NOT NULL DEFAULT '0' COMMENT 'Nested set parent.',
  `lft` int(11) NOT NULL DEFAULT '0' COMMENT 'Nested set lft.',
  `rgt` int(11) NOT NULL DEFAULT '0' COMMENT 'Nested set rgt.',
  `level` int(10) unsigned NOT NULL COMMENT 'The cached level in the nested tree.',
  `name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'The unique name for the asset.\n',
  `title` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'The descriptive title for the asset.',
  `rules` varchar(5120) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'JSON encoded access control.'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prefi_assets`
--

LOCK TABLES `prefi_assets` WRITE;
/*!40000 ALTER TABLE `prefi_assets` DISABLE KEYS */;
INSERT INTO `prefi_assets` VALUES (1,0,0,1347,0,'root.1','Root Asset','{\"core.login.site\":{\"6\":1,\"2\":1},\"core.login.admin\":{\"6\":1},\"core.login.offline\":{\"6\":1},\"core.admin\":{\"8\":1},\"core.manage\":{\"7\":1},\"core.create\":{\"6\":1,\"3\":1},\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1},\"core.edit.own\":{\"6\":1,\"3\":1},\"attachments.delete.own\":{\"6\":1,\"3\":1},\"attachments.edit.state.own\":{\"6\":1,\"4\":1},\"attachments.edit.state.ownparent\":{\"6\":1,\"4\":1},\"attachments.edit.ownparent\":{\"6\":1,\"3\":1},\"attachments.delete.ownparent\":{\"6\":1,\"3\":1}}'),(2,1,1,2,1,'com_admin','com_admin','{}'),(3,1,3,6,1,'com_banners','com_banners','{\"core.admin\":{\"7\":1},\"core.manage\":{\"6\":1},\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(4,1,7,8,1,'com_cache','com_cache','{\"core.admin\":{\"7\":1},\"core.manage\":{\"7\":1}}'),(5,1,9,10,1,'com_checkin','com_checkin','{\"core.admin\":{\"7\":1},\"core.manage\":{\"7\":1}}'),(6,1,11,12,1,'com_config','com_config','{}'),(7,1,13,16,1,'com_contact','com_contact','{\"core.admin\":{\"7\":1},\"core.manage\":{\"6\":1},\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[],\"core.edit.own\":[]}'),(8,1,17,610,1,'com_content','com_content','{\"core.admin\":{\"7\":1},\"core.manage\":{\"6\":1},\"core.create\":{\"3\":1},\"core.delete\":[],\"core.edit\":{\"4\":1},\"core.edit.state\":{\"5\":1},\"core.edit.own\":[]}'),(9,1,249,250,1,'com_cpanel','com_cpanel','{}'),(10,1,1077,1078,1,'com_installer','com_installer','{\"core.admin\":[],\"core.manage\":{\"7\":0},\"core.delete\":{\"7\":0},\"core.edit.state\":{\"7\":0}}'),(11,1,1075,1076,1,'com_languages','com_languages','{\"core.admin\":{\"7\":1},\"core.manage\":[],\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(12,1,1073,1074,1,'com_login','com_login','{}'),(13,1,369,594,1,'com_mailto','com_mailto','{}'),(14,1,611,612,1,'com_massmail','com_massmail','{}'),(15,1,1071,1072,1,'com_media','com_media','{\"core.admin\":{\"7\":1},\"core.manage\":{\"6\":1},\"core.create\":{\"3\":1},\"core.delete\":{\"5\":1}}'),(16,1,1069,1070,1,'com_menus','com_menus','{\"core.admin\":{\"7\":1},\"core.manage\":[],\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(17,1,251,252,1,'com_messages','com_messages','{\"core.admin\":{\"7\":1},\"core.manage\":{\"7\":1}}'),(18,1,613,996,1,'com_modules','com_modules','{\"core.admin\":{\"7\":1},\"core.manage\":[],\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(19,1,1045,1108,1,'com_newsfeeds','com_newsfeeds','{\"core.admin\":{\"7\":1},\"core.manage\":{\"6\":1},\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[],\"core.edit.own\":[]}'),(20,1,357,472,1,'com_plugins','com_plugins','{\"core.admin\":{\"7\":1},\"core.manage\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(21,1,983,984,1,'com_redirect','com_redirect','{\"core.admin\":{\"7\":1},\"core.manage\":[]}'),(22,1,729,996,1,'com_search','com_search','{\"core.admin\":{\"7\":1},\"core.manage\":{\"6\":1}}'),(23,1,737,996,1,'com_templates','com_templates','{\"core.admin\":{\"7\":1},\"core.manage\":[],\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(24,1,777,996,1,'com_users','com_users','{\"core.admin\":{\"7\":1},\"core.manage\":[],\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(26,1,365,366,1,'com_wrapper','com_wrapper','{}'),(27,8,18,227,2,'com_content.category.2','Διάφορα','{\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[],\"core.edit.own\":[]}'),(28,3,4,5,2,'com_banners.category.3','Uncategorised','{\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(29,7,14,15,2,'com_contact.category.4','Uncategorised','{\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[],\"core.edit.own\":[]}'),(30,19,1046,1107,2,'com_newsfeeds.category.5','Uncategorised','{\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[],\"core.edit.own\":[]}'),(32,24,372,471,1,'com_users.category.7','Uncategorised','{\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(33,1,795,996,1,'com_finder','com_finder','{\"core.admin\":{\"7\":1},\"core.manage\":{\"6\":1}}'),(34,1,809,996,1,'com_joomlaupdate','com_joomlaupdate','{\"core.admin\":[],\"core.manage\":[],\"core.delete\":[],\"core.edit.state\":[]}'),(35,1,817,996,1,'com_tags','com_tags','{\"core.admin\":[],\"core.manage\":[],\"core.manage\":[],\"core.delete\":[],\"core.edit.state\":[]}'),(36,1,837,996,1,'com_contenthistory','com_contenthistory','{}'),(37,1,981,982,1,'com_ajax','com_ajax','{}'),(38,1,849,996,1,'com_postinstall','com_postinstall','{}'),(39,18,614,615,2,'com_modules.module.1','Main Menu Greek','{\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[],\"module.edit.frontend\":[]}'),(40,18,254,471,2,'com_modules.module.2','Login','{\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(41,18,1068,1161,2,'com_modules.module.3','Popular Articles','{\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(42,18,1066,1165,2,'com_modules.module.4','Recently Added Articles','{\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(43,18,616,617,2,'com_modules.module.8','Toolbar','{\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(44,18,256,471,2,'com_modules.module.9','Quick Icons','{\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(45,18,618,619,2,'com_modules.module.10','Logged-in Users','{\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(46,18,620,621,2,'com_modules.module.12','Admin Menu','{\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(47,18,622,623,2,'com_modules.module.13','Admin Submenu','{\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(48,18,624,625,2,'com_modules.module.14','User Status','{\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(49,18,258,471,2,'com_modules.module.15','Title','{\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(50,18,1064,1165,2,'com_modules.module.16','Login Form','{\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[],\"module.edit.frontend\":[]}'),(51,18,626,627,2,'com_modules.module.17','Breadcrumbs','{\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[],\"module.edit.frontend\":[]}'),(52,18,260,471,2,'com_modules.module.79','Multilanguage status','{\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(53,18,628,629,2,'com_modules.module.86','Core Version','{\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[]}'),(56,8,444,497,2,'com_content.category.8','Άρθρα','{}'),(57,56,229,230,3,'com_content.article.1','Τι έκαναν οι πολίτες αυτήν την εβδομάδα;','{\"core.admin\":{\"7\":1},\"core.manage\":{\"6\":1},\"core.create\":{\"3\":1},\"core.delete\":[],\"core.edit\":{\"4\":1},\"core.edit.state\":{\"5\":1},\"core.edit.own\":[]}'),(58,1,979,980,1,'com_jce','JCE','{}'),(59,56,231,232,3,'com_content.article.2','Τι έκαναν οι πολίτες αυτήν την εβδομάδα; (2)','{\"core.admin\":{\"7\":1},\"core.manage\":{\"6\":1},\"core.create\":{\"3\":1},\"core.delete\":[],\"core.edit\":{\"4\":1},\"core.edit.state\":{\"5\":1},\"core.edit.own\":[]}'),(60,56,1113,1114,3,'com_content.article.3','Τι έκαναν οι πολίτες αυτήν την εβδομάδα; (3)','{\"core.admin\":{\"7\":1},\"core.manage\":{\"6\":1},\"core.create\":{\"3\":1},\"core.delete\":[],\"core.edit\":{\"4\":1},\"core.edit.state\":{\"5\":1},\"core.edit.own\":[]}'),(61,56,233,234,3,'com_content.article.4','Τι έκαναν οι πολίτες αυτήν την εβδομάδα; (4)','{\"core.admin\":{\"7\":1},\"core.manage\":{\"6\":1},\"core.create\":{\"3\":1},\"core.delete\":[],\"core.edit\":{\"4\":1},\"core.edit.state\":{\"5\":1},\"core.edit.own\":[]}'),(62,27,19,20,3,'com_content.article.5','Συχνές Ερωτήσεις','{\"core.admin\":{\"7\":1},\"core.manage\":{\"6\":1},\"core.create\":{\"3\":1},\"core.delete\":[],\"core.edit\":{\"4\":1},\"core.edit.state\":{\"5\":1},\"core.edit.own\":[]}'),(63,18,1062,1149,2,'com_modules.module.87','Footer Menu Greek','{\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[],\"module.edit.frontend\":[]}'),(64,27,21,22,3,'com_content.article.6','Όροι χρήσης','{\"core.admin\":{\"7\":1},\"core.manage\":{\"6\":1},\"core.create\":{\"3\":1},\"core.delete\":[],\"core.edit\":{\"4\":1},\"core.edit.state\":{\"5\":1},\"core.edit.own\":[]}'),(65,18,630,631,2,'com_modules.module.88','Language Switcher','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1},\"module.edit.frontend\":[]}'),(66,18,632,633,2,'com_modules.module.89','Extra Links_gr','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1},\"module.edit.frontend\":[]}'),(67,8,60,227,2,'com_content.category.9','Press','{}'),(68,67,305,306,3,'com_content.article.7','Title press article linkable','{\"core.admin\":{\"7\":1},\"core.manage\":{\"6\":1},\"core.create\":{\"3\":1},\"core.delete\":[],\"core.edit\":{\"4\":1},\"core.edit.state\":{\"5\":1},\"core.edit.own\":[]}'),(69,67,1101,1102,3,'com_content.article.8','Title press article (2)','{\"core.admin\":{\"7\":1},\"core.manage\":{\"6\":1},\"core.create\":{\"3\":1},\"core.delete\":[],\"core.edit\":{\"4\":1},\"core.edit.state\":{\"5\":1},\"core.edit.own\":[]}'),(70,67,57,58,3,'com_content.article.9','Title press article (3)','{\"core.admin\":{\"7\":1},\"core.manage\":{\"6\":1},\"core.create\":{\"3\":1},\"core.delete\":[],\"core.edit\":{\"4\":1},\"core.edit.state\":{\"5\":1},\"core.edit.own\":[]}'),(71,1,997,998,1,'com_attachments','com_attachments','{\"core.admin\":[],\"core.manage\":[],\"core.create\":[],\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[],\"core.edit.own\":[],\"attachments.edit.state.own\":[],\"attachments.delete.own\":[],\"attachments.edit.ownparent\":[],\"attachments.edit.state.ownparent\":[],\"attachments.delete.ownparent\":[]}'),(72,67,1045,1218,3,'com_content.article.10','Title press article (4)','{\"core.admin\":{\"7\":1},\"core.manage\":{\"6\":1},\"core.create\":{\"3\":1},\"core.delete\":[],\"core.edit\":{\"4\":1},\"core.edit.state\":{\"5\":1},\"core.edit.own\":[]}'),(73,18,634,635,2,'com_modules.module.90','News Banner','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1},\"module.edit.frontend\":[]}'),(74,56,235,236,3,'com_content.article.11','Τι έκαναν οι πολίτες αυτήν την εβδομάδα; (5)','{\"core.admin\":{\"7\":1},\"core.manage\":{\"6\":1},\"core.create\":{\"3\":1},\"core.delete\":[],\"core.edit\":{\"4\":1},\"core.edit.state\":{\"5\":1},\"core.edit.own\":[]}'),(75,56,53,54,3,'com_content.article.12','Τι έκαναν οι πολίτες αυτήν την εβδομάδα; (6)','{\"core.admin\":{\"7\":1},\"core.manage\":{\"6\":1},\"core.create\":{\"3\":1},\"core.delete\":[],\"core.edit\":{\"4\":1},\"core.edit.state\":{\"5\":1},\"core.edit.own\":[]}'),(76,56,237,238,3,'com_content.article.13','Τι έκαναν οι πολίτες αυτήν την εβδομάδα; (7)','{\"core.admin\":{\"7\":1},\"core.manage\":{\"6\":1},\"core.create\":{\"3\":1},\"core.delete\":[],\"core.edit\":{\"4\":1},\"core.edit.state\":{\"5\":1},\"core.edit.own\":[]}'),(77,56,1111,1112,3,'com_content.article.14','Τι έκαναν οι πολίτες αυτήν την εβδομάδα; (8)','{\"core.admin\":{\"7\":1},\"core.manage\":{\"6\":1},\"core.create\":{\"3\":1},\"core.delete\":[],\"core.edit\":{\"4\":1},\"core.edit.state\":{\"5\":1},\"core.edit.own\":[]}'),(78,56,1109,1110,3,'com_content.article.15','Τι έκαναν οι πολίτες αυτήν την εβδομάδα; (9)','{\"core.admin\":{\"7\":1},\"core.manage\":{\"6\":1},\"core.create\":{\"3\":1},\"core.delete\":[],\"core.edit\":{\"4\":1},\"core.edit.state\":{\"5\":1},\"core.edit.own\":[]}'),(79,56,55,56,3,'com_content.article.16','Τι έκαναν οι πολίτες αυτήν την εβδομάδα; (10)','{\"core.admin\":{\"7\":1},\"core.manage\":{\"6\":1},\"core.create\":{\"3\":1},\"core.delete\":[],\"core.edit\":{\"4\":1},\"core.edit.state\":{\"5\":1},\"core.edit.own\":[]}'),(80,8,330,1141,2,'com_content.category.10','Νέα','{}'),(82,18,284,471,2,'com_modules.module.91','Dizi images','{}'),(83,18,262,471,2,'com_modules.module.92','Images gallery','{}'),(84,1,999,1000,1,'com_di','com_di','{}'),(88,18,1060,1167,2,'com_modules.module.93','Άρθρα','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1},\"module.edit.frontend\":[]}'),(89,18,636,637,2,'com_modules.module.94','Άρθρα','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1},\"module.edit.frontend\":[]}'),(96,18,1058,1167,2,'com_modules.module.95','test','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1},\"module.edit.frontend\":[]}'),(106,18,638,639,2,'com_modules.module.96','User Menu Greek','{\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[],\"module.edit.frontend\":[]}'),(107,8,1100,1149,2,'com_content.category.11','Συναθηνά','{}'),(108,107,1097,1098,3,'com_content.article.26','Οι αριθμοί μιλούν','{\"core.admin\":{\"7\":1},\"core.manage\":{\"6\":1},\"core.create\":{\"3\":1},\"core.delete\":[],\"core.edit\":{\"4\":1},\"core.edit.state\":{\"5\":1},\"core.edit.own\":[]}'),(109,107,239,240,3,'com_content.article.27','Τα εργαλεία μας στη διάθεσή σας','{\"core.admin\":{\"7\":1},\"core.manage\":{\"6\":1},\"core.create\":{\"3\":1},\"core.delete\":[],\"core.edit\":{\"4\":1},\"core.edit.state\":{\"5\":1},\"core.edit.own\":[]}'),(110,107,1095,1096,3,'com_content.article.28','To συνΑθηνά στην πράξη','{\"core.admin\":{\"7\":1},\"core.manage\":{\"6\":1},\"core.create\":{\"3\":1},\"core.delete\":[],\"core.edit\":{\"4\":1},\"core.edit.state\":{\"5\":1},\"core.edit.own\":[]}'),(111,107,1093,1094,3,'com_content.article.29','Λίγα λόγια για το συνΑθηνά και την αποστολή του','{\"core.admin\":{\"7\":1},\"core.manage\":{\"6\":1},\"core.create\":{\"3\":1},\"core.delete\":[],\"core.edit\":{\"4\":1},\"core.edit.state\":{\"5\":1},\"core.edit.own\":[]}'),(112,18,264,471,2,'com_modules.module.97','Synathina Banner','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1},\"module.edit.frontend\":[]}'),(328,8,308,315,2,'com_content.category.12','Ομάδες','{}'),(329,328,97,228,3,'com_content.article.30','Οι ομάδες','{\"core.admin\":{\"7\":1},\"core.manage\":{\"6\":1},\"core.create\":{\"3\":1},\"core.delete\":[],\"core.edit\":{\"4\":1},\"core.edit.state\":{\"5\":1},\"core.edit.own\":[]}'),(330,8451,601,602,3,'com_content.article.31','Οι υποστηρικτές','{\"core.admin\":{\"7\":1},\"core.manage\":{\"6\":1},\"core.create\":{\"3\":1},\"core.delete\":[],\"core.edit\":{\"4\":1},\"core.edit.state\":{\"5\":1},\"core.edit.own\":[]}'),(331,328,281,282,3,'com_content.article.32','Διασύνδεση','{\"core.admin\":{\"7\":1},\"core.manage\":{\"6\":1},\"core.create\":{\"3\":1},\"core.delete\":[],\"core.edit\":{\"4\":1},\"core.edit.state\":{\"5\":1},\"core.edit.own\":[]}'),(332,18,640,641,2,'com_modules.module.98','Ομάδες','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1},\"module.edit.frontend\":[]}'),(333,18,642,1141,2,'com_modules.module.99','Υποστηρικτές','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1},\"module.edit.frontend\":[]}'),(1883,18,1056,1167,2,'com_modules.module.100','Δράσεις','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1},\"module.edit.frontend\":[]}'),(1887,8,1092,1191,2,'com_content.category.13','Δίκτυο','{}'),(1888,1887,241,242,3,'com_content.article.33','Η σύνδεσή μας με το δίκτυο','{\"core.admin\":{\"7\":1},\"core.manage\":{\"6\":1},\"core.create\":{\"3\":1},\"core.delete\":[],\"core.edit\":{\"4\":1},\"core.edit.state\":{\"5\":1},\"core.edit.own\":[]}'),(1889,1887,451,490,3,'com_content.article.34','Ομάδα εργασίας Creative Citizenship του δικτύου Eurocities','{\"core.admin\":{\"7\":1},\"core.manage\":{\"6\":1},\"core.create\":{\"3\":1},\"core.delete\":[],\"core.edit\":{\"4\":1},\"core.edit.state\":{\"5\":1},\"core.edit.own\":[]}'),(1890,1887,165,228,3,'com_content.article.35','European City Makers','{\"core.admin\":{\"7\":1},\"core.manage\":{\"6\":1},\"core.create\":{\"3\":1},\"core.delete\":[],\"core.edit\":{\"4\":1},\"core.edit.state\":{\"5\":1},\"core.edit.own\":[]}'),(1891,1887,243,244,3,'com_content.article.36','Bloomberg Philanthropies Mayor\'s Challenge','{\"core.admin\":{\"7\":1},\"core.manage\":{\"6\":1},\"core.create\":{\"3\":1},\"core.delete\":[],\"core.edit\":{\"4\":1},\"core.edit.state\":{\"5\":1},\"core.edit.own\":[]}'),(1906,27,23,24,3,'com_content.article.37','Η στέγη του συνΑθηνά','{\"core.admin\":{\"7\":1},\"core.manage\":{\"6\":1},\"core.create\":{\"3\":1},\"core.delete\":[],\"core.edit\":{\"4\":1},\"core.edit.state\":{\"5\":1},\"core.edit.own\":[]}'),(1907,18,334,471,2,'com_modules.module.101','Στέγη','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1},\"module.edit.frontend\":[]}'),(1908,8,246,471,2,'com_content.category.14','Εγχείριδια δράσεων / Toolkits','{}'),(1909,1908,459,482,3,'com_content.article.38','2016','{\"core.admin\":{\"7\":1},\"core.manage\":{\"6\":1},\"core.create\":{\"3\":1},\"core.delete\":[],\"core.edit\":{\"4\":1},\"core.edit.state\":{\"5\":1},\"core.edit.own\":[]}'),(1910,1908,1089,1090,3,'com_content.article.39','2015','{\"core.admin\":{\"7\":1},\"core.manage\":{\"6\":1},\"core.create\":{\"3\":1},\"core.delete\":[],\"core.edit\":{\"4\":1},\"core.edit.state\":{\"5\":1},\"core.edit.own\":[]}'),(1911,18,1054,1149,2,'com_modules.module.102','Εγχείριδια δράσεων','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1},\"module.edit.frontend\":[]}'),(1912,8,228,471,2,'com_content.category.15','Open Calls','{}'),(1914,1913,231,472,3,'com_content.article.40','The groups','{\"core.admin\":{\"7\":1},\"core.manage\":{\"6\":1},\"core.create\":{\"3\":1},\"core.delete\":[],\"core.edit\":{\"4\":1},\"core.edit.state\":{\"5\":1},\"core.edit.own\":[]}'),(1915,8452,605,606,3,'com_content.article.41','The sponsors','{\"core.admin\":{\"7\":1},\"core.manage\":{\"6\":1},\"core.create\":{\"3\":1},\"core.delete\":[],\"core.edit\":{\"4\":1},\"core.edit.state\":{\"5\":1},\"core.edit.own\":[]}'),(1916,1913,267,472,3,'com_content.article.42','Connectivity','{\"core.admin\":{\"7\":1},\"core.manage\":{\"6\":1},\"core.create\":{\"3\":1},\"core.delete\":[],\"core.edit\":{\"4\":1},\"core.edit.state\":{\"5\":1},\"core.edit.own\":[]}'),(1917,18,344,471,2,'com_modules.module.103','Main Menu English','{\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[],\"module.edit.frontend\":[]}'),(1918,18,336,471,2,'com_modules.module.104','Activities','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1},\"module.edit.frontend\":[]}'),(1919,18,338,471,2,'com_modules.module.105','Toolkits','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1},\"module.edit.frontend\":[]}'),(1920,8,316,471,2,'com_content.category.17','Synathina kiosk','{}'),(1921,8,248,471,2,'com_content.category.18','Network','{}'),(1922,8,332,471,2,'com_content.category.19','Synathina','{}'),(1923,1922,331,472,3,'com_content.article.43','What the numbers say','{\"core.admin\":{\"7\":1},\"core.manage\":{\"6\":1},\"core.create\":{\"3\":1},\"core.delete\":[],\"core.edit\":{\"4\":1},\"core.edit.state\":{\"5\":1},\"core.edit.own\":[]}'),(1924,1922,1081,1082,3,'com_content.article.44','Our tools at your disposal','{\"core.admin\":{\"7\":1},\"core.manage\":{\"6\":1},\"core.create\":{\"3\":1},\"core.delete\":[],\"core.edit\":{\"4\":1},\"core.edit.state\":{\"5\":1},\"core.edit.own\":[]}'),(1925,1922,341,342,3,'com_content.article.45','SynAthina in action','{\"core.admin\":{\"7\":1},\"core.manage\":{\"6\":1},\"core.create\":{\"3\":1},\"core.delete\":[],\"core.edit\":{\"4\":1},\"core.edit.state\":{\"5\":1},\"core.edit.own\":[]}'),(1926,1922,385,386,3,'com_content.article.46','A few words about synAthina and its mission','{\"core.admin\":{\"7\":1},\"core.manage\":{\"6\":1},\"core.create\":{\"3\":1},\"core.delete\":[],\"core.edit\":{\"4\":1},\"core.edit.state\":{\"5\":1},\"core.edit.own\":[]}'),(1927,18,1052,1169,2,'com_modules.module.106','User Menu English','{\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[],\"module.edit.frontend\":[]}'),(1928,1921,1087,1088,3,'com_content.article.47','Our connection with the Network','{\"core.admin\":{\"7\":1},\"core.manage\":{\"6\":1},\"core.create\":{\"3\":1},\"core.delete\":[],\"core.edit\":{\"4\":1},\"core.edit.state\":{\"5\":1},\"core.edit.own\":[]}'),(1929,1921,317,318,3,'com_content.article.48','Creative Citizenship working group of the Eurocities Network','{\"core.admin\":{\"7\":1},\"core.manage\":{\"6\":1},\"core.create\":{\"3\":1},\"core.delete\":[],\"core.edit\":{\"4\":1},\"core.edit.state\":{\"5\":1},\"core.edit.own\":[]}'),(1930,1921,1085,1086,3,'com_content.article.49','European City Makers','{\"core.admin\":{\"7\":1},\"core.manage\":{\"6\":1},\"core.create\":{\"3\":1},\"core.delete\":[],\"core.edit\":{\"4\":1},\"core.edit.state\":{\"5\":1},\"core.edit.own\":[]}'),(1931,1921,1083,1084,3,'com_content.article.50','Bloomberg Philanthropies Mayor\'s Challenge','{\"core.admin\":{\"7\":1},\"core.manage\":{\"6\":1},\"core.create\":{\"3\":1},\"core.delete\":[],\"core.edit\":{\"4\":1},\"core.edit.state\":{\"5\":1},\"core.edit.own\":[]}'),(1932,1921,317,472,3,'com_content.article.51','Social Dynamo','{\"core.admin\":{\"7\":1},\"core.manage\":{\"6\":1},\"core.create\":{\"3\":1},\"core.delete\":[],\"core.edit\":{\"4\":1},\"core.edit.state\":{\"5\":1},\"core.edit.own\":[]}'),(1933,27,25,26,3,'com_content.article.52','The kiosk','{\"core.admin\":{\"7\":1},\"core.manage\":{\"6\":1},\"core.create\":{\"3\":1},\"core.delete\":[],\"core.edit\":{\"4\":1},\"core.edit.state\":{\"5\":1},\"core.edit.own\":[]}'),(1934,18,356,471,2,'com_modules.module.107','Articles','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1},\"module.edit.frontend\":[]}'),(1935,27,27,28,3,'com_content.article.53','Terms of use','{\"core.admin\":{\"7\":1},\"core.manage\":{\"6\":1},\"core.create\":{\"3\":1},\"core.delete\":[],\"core.edit\":{\"4\":1},\"core.edit.state\":{\"5\":1},\"core.edit.own\":[]}'),(1936,18,346,471,2,'com_modules.module.108','Footer Menu English','{\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[],\"module.edit.frontend\":[]}'),(1937,18,286,471,2,'com_modules.module.109','Στέγη (copy)','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1},\"module.edit.frontend\":[]}'),(1938,18,354,471,2,'com_modules.module.110','Synathina Slider','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1},\"module.edit.frontend\":[]}'),(1949,80,29,228,3,'com_content.article.57','Καιρός για ποδήλατο','{\"core.admin\":{\"7\":1},\"core.manage\":{\"6\":1},\"core.create\":{\"3\":1},\"core.delete\":[],\"core.edit\":{\"4\":1},\"core.edit.state\":{\"5\":1},\"core.edit.own\":[]}'),(1950,1912,229,230,3,'com_content.article.58','Open Call: η WWF σας καλεί σε διοργάνωση δράσεων στο πράσινο της πόλης στα πλαίσια της Παγκόσμιας Ημ','{\"core.admin\":{\"7\":1},\"core.manage\":{\"6\":1},\"core.create\":{\"3\":1},\"core.delete\":[],\"core.edit\":{\"4\":1},\"core.edit.state\":{\"5\":1},\"core.edit.own\":[]}'),(1951,1912,231,232,3,'com_content.article.59','Open Call: Aνοιχτή Πρόσκληση της 1ης Κοινότητας του δήμου Αθηναίων για ενεργούς πολίτες της περιοχής','{\"core.admin\":{\"7\":1},\"core.manage\":{\"6\":1},\"core.create\":{\"3\":1},\"core.delete\":[],\"core.edit\":{\"4\":1},\"core.edit.state\":{\"5\":1},\"core.edit.own\":[]}'),(1952,80,1113,1114,3,'com_content.article.60','Τρία χρόνια EMFASIS','{\"core.admin\":{\"7\":1},\"core.manage\":{\"6\":1},\"core.create\":{\"3\":1},\"core.delete\":[],\"core.edit\":{\"4\":1},\"core.edit.state\":{\"5\":1},\"core.edit.own\":[]}'),(2208,18,1048,1049,2,'com_modules.module.111','Open call','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1},\"module.edit.frontend\":[]}'),(2891,1,1163,1164,1,'#__ucm_content.1','#__ucm_content.1','[]'),(2893,1,1165,1166,1,'#__ucm_content.2','#__ucm_content.2','[]'),(2897,1,1167,1168,1,'#__ucm_content.3','#__ucm_content.3','[]'),(2899,1,1169,1170,1,'#__ucm_content.4','#__ucm_content.4','[]'),(2902,1,1171,1172,1,'#__ucm_content.5','#__ucm_content.5','[]'),(2904,1,1173,1174,1,'#__ucm_content.6','#__ucm_content.6','[]'),(2906,1,1175,1176,1,'#__ucm_content.7','#__ucm_content.7','[]'),(2907,1,1177,1178,1,'#__ucm_content.8','#__ucm_content.8','[]'),(2910,1,1179,1180,1,'#__ucm_content.9','#__ucm_content.9','[]'),(2948,1,1181,1182,1,'#__ucm_content.10','#__ucm_content.10','[]'),(3071,1,1183,1184,1,'#__ucm_content.11','#__ucm_content.11','[]'),(3091,1,1185,1186,1,'#__ucm_content.12','#__ucm_content.12','[]'),(3112,1,1187,1188,1,'#__ucm_content.13','#__ucm_content.13','[]'),(3141,1,1189,1190,1,'#__ucm_content.14','#__ucm_content.14','[]'),(3614,1,1191,1192,1,'#__ucm_content.15','#__ucm_content.15','[]'),(3710,1,1193,1194,1,'#__ucm_content.16','#__ucm_content.16','[]'),(3732,1,1195,1196,1,'#__ucm_content.17','#__ucm_content.17','[]'),(3738,1,1197,1198,1,'#__ucm_content.18','#__ucm_content.18','[]'),(3826,1,1199,1200,1,'#__ucm_content.19','#__ucm_content.19','[]'),(3865,1,1201,1202,1,'#__ucm_content.20','#__ucm_content.20','[]'),(3891,1,1203,1204,1,'#__ucm_content.21','#__ucm_content.21','[]'),(3898,18,358,471,2,'com_modules.module.112','Extra Links_en','{\"core.delete\":[],\"core.edit\":[],\"core.edit.state\":[],\"module.edit.frontend\":[]}'),(4068,1,1205,1206,1,'#__ucm_content.22','#__ucm_content.22','[]'),(4101,1,1207,1208,1,'#__ucm_content.23','#__ucm_content.23','[]'),(4228,1,1209,1210,1,'#__ucm_content.24','#__ucm_content.24','[]'),(4238,1,1211,1212,1,'#__ucm_content.25','#__ucm_content.25','[]'),(4310,1,1213,1214,1,'#__ucm_content.26','#__ucm_content.26','[]'),(4313,1,1215,1216,1,'#__ucm_content.27','#__ucm_content.27','[]'),(4331,1,1217,1218,1,'#__ucm_content.28','#__ucm_content.28','[]'),(4336,1,1219,1220,1,'#__ucm_content.29','#__ucm_content.29','[]'),(4341,1,1221,1222,1,'#__ucm_content.30','#__ucm_content.30','[]'),(4373,1,1223,1224,1,'#__ucm_content.31','#__ucm_content.31','[]'),(4382,1,1225,1226,1,'#__ucm_content.32','#__ucm_content.32','[]'),(4444,1,1227,1228,1,'#__ucm_content.33','#__ucm_content.33','[]'),(4446,1,1229,1230,1,'#__ucm_content.34','#__ucm_content.34','[]'),(4905,8,370,591,2,'com_content.category.20','Βέλτιστες πρακτικές','{}'),(4906,8,350,527,2,'com_content.category.21','Best practices','{}'),(6027,1,1231,1232,1,'com_support','COM_SUPPORT','{}'),(6578,1,1233,1234,1,'com_supportersexports','Supportersexports','{}'),(8440,18,1104,1105,2,'com_modules.module.113','Βέλτιστες Πρακτικές','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1},\"module.edit.frontend\":[]}'),(8441,18,1106,1107,2,'com_modules.module.114','Best Practices','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1},\"module.edit.frontend\":[]}'),(8442,18,1108,1141,2,'com_modules.module.115','Mobile Menu Greek','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1},\"module.edit.frontend\":[]}'),(8443,18,986,987,2,'com_modules.module.116','Mobile Menu English','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1},\"module.edit.frontend\":[]}'),(8444,18,988,989,2,'com_modules.module.117','Top Menu Greek','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1},\"module.edit.frontend\":[]}'),(8445,18,990,991,2,'com_modules.module.118','Top Menu English','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1},\"module.edit.frontend\":[]}'),(8446,18,992,993,2,'com_modules.module.119','Οι αριθμοί μιλούν','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1},\"module.edit.frontend\":[]}'),(8447,18,994,995,2,'com_modules.module.120','What the numbers say','{\"core.delete\":{\"6\":1},\"core.edit\":{\"6\":1,\"4\":1},\"core.edit.state\":{\"6\":1,\"5\":1},\"module.edit.frontend\":[]}'),(8451,8,598,603,2,'com_content.category.22','Υποστηρικτές','{}'),(8452,8,604,609,2,'com_content.category.23','Supporters','{}'),(8615,27,189,190,3,'com_content.article.782','MIGRANTS\' INTEGRATION','{\"core.admin\":{\"7\":1},\"core.manage\":{\"6\":1},\"core.create\":{\"3\":1},\"core.delete\":[],\"core.edit\":{\"4\":1},\"core.edit.state\":{\"5\":1},\"core.edit.own\":[]}'),(0,80,227,228,3,'com_content.article.813','Ο ΤΙΤΛΟΣ ΜΟΥ','{\"core.admin\":{\"7\":1},\"core.manage\":{\"6\":1},\"core.create\":{\"3\":1},\"core.delete\":[],\"core.edit\":{\"4\":1},\"core.edit.state\":{\"5\":1},\"core.edit.own\":[]}'),(0,80,227,228,3,'com_content.article.814','Ο ΤΙΤΛΟΣ ΜΟΥ Νο 2','{\"core.admin\":{\"7\":1},\"core.manage\":{\"6\":1},\"core.create\":{\"3\":1},\"core.delete\":[],\"core.edit\":{\"4\":1},\"core.edit.state\":{\"5\":1},\"core.edit.own\":[]}');
/*!40000 ALTER TABLE `prefi_assets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prefi_associations`
--

DROP TABLE IF EXISTS `prefi_associations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `prefi_associations` (
  `id` int(11) NOT NULL COMMENT 'A reference to the associated item.',
  `context` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'The context of the associated item.',
  `key` char(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'The key for the association computed from an md5 on associated ids.',
  PRIMARY KEY (`context`,`id`),
  KEY `idx_key` (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prefi_associations`
--

LOCK TABLES `prefi_associations` WRITE;
/*!40000 ALTER TABLE `prefi_associations` DISABLE KEYS */;
INSERT INTO `prefi_associations` VALUES (138,'com_menus.item','0e729f41894c9b9384b1e56b9e87632b'),(148,'com_menus.item','0e729f41894c9b9384b1e56b9e87632b'),(119,'com_menus.item','0fe3451dea125e24f86783437c88c517'),(159,'com_menus.item','0fe3451dea125e24f86783437c88c517'),(126,'com_menus.item','127c8ec919d85560b268e293f08f68c8'),(161,'com_menus.item','127c8ec919d85560b268e293f08f68c8'),(129,'com_menus.item','23d0230786090eb77d8f786a82e4b5e5'),(152,'com_menus.item','23d0230786090eb77d8f786a82e4b5e5'),(184,'com_menus.item','2ceb51098133b7c98d299c32723d7f4d'),(191,'com_menus.item','2ceb51098133b7c98d299c32723d7f4d'),(22,'com_categories.item','33605822f40f20d63765477b7ed44d3d'),(130,'com_menus.item','3a1301d120249880cc2caf60d28820fe'),(153,'com_menus.item','3a1301d120249880cc2caf60d28820fe'),(121,'com_menus.item','5168de7b69c970131a5b90b285570ce7'),(151,'com_menus.item','5168de7b69c970131a5b90b285570ce7'),(11,'com_categories.item','56eb310454e3352fadf38b4cf8cdb9aa'),(137,'com_menus.item','58980d71ae1fdc70e3b551c351ac7b82'),(147,'com_menus.item','58980d71ae1fdc70e3b551c351ac7b82'),(116,'com_menus.item','5e37585ff94f369292042be321797014'),(155,'com_menus.item','5e37585ff94f369292042be321797014'),(146,'com_menus.item','625bd2ffd425710356c92b852bcb59b6'),(154,'com_menus.item','625bd2ffd425710356c92b852bcb59b6'),(21,'com_categories.item','7d798a84bf4b26fafbf7e535086e83fc'),(141,'com_menus.item','7fff4852fcf3dae01e357616e1c470cb'),(157,'com_menus.item','7fff4852fcf3dae01e357616e1c470cb'),(19,'com_categories.item','970a2c4b0d40ecdd076329f68c480724'),(23,'com_categories.item','9f97d25ab0971a6f707145bc1b5d7387'),(122,'com_menus.item','a331f7ca502f8847c9181092c7ad46ee'),(183,'com_menus.item','a331f7ca502f8847c9181092c7ad46ee'),(187,'com_menus.item','ad30bf87580cc1c1a6ec59a41d813386'),(193,'com_menus.item','ad30bf87580cc1c1a6ec59a41d813386'),(120,'com_menus.item','ba1cbf4f7794e2beabf64bee3d759b7b'),(150,'com_menus.item','ba1cbf4f7794e2beabf64bee3d759b7b'),(110,'com_menus.item','bd10ece5dce31a664d6ff7581d829090'),(117,'com_menus.item','d2e669b8176adc09b99b20f28bd35883'),(158,'com_menus.item','d2e669b8176adc09b99b20f28bd35883'),(145,'com_menus.item','defbfc97c3a2b3e45fb4b96829446bcd'),(156,'com_menus.item','defbfc97c3a2b3e45fb4b96829446bcd'),(20,'com_categories.item','e017b1add86a23886613431f90d71104'),(18,'com_categories.item','e2948e58f4dc223ed5fd054e88f67623'),(17,'com_categories.item','e8b86d83856c87ae8bf08c3d6ec80a6c'),(189,'com_menus.item','ea06f03d82ecf4a9ccd4233783728d4f'),(195,'com_menus.item','ea06f03d82ecf4a9ccd4233783728d4f'),(12,'com_categories.item','f6ed0f1c18e62523f046b5a8e95111f6'),(16,'com_categories.item','fe59bf6754f6185fab8e23f43359434b');
/*!40000 ALTER TABLE `prefi_associations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prefi_attachments`
--

DROP TABLE IF EXISTS `prefi_attachments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `prefi_attachments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `filename` varchar(256) NOT NULL,
  `filename_sys` varchar(512) NOT NULL,
  `file_type` varchar(128) NOT NULL,
  `file_size` int(11) unsigned NOT NULL,
  `url` varchar(1024) NOT NULL DEFAULT '',
  `uri_type` enum('file','url') DEFAULT 'file',
  `url_valid` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `url_relative` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `url_verify` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `display_name` varchar(80) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL DEFAULT '',
  `icon_filename` varchar(20) NOT NULL,
  `access` int(11) NOT NULL DEFAULT '1',
  `state` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `user_field_1` varchar(255) NOT NULL DEFAULT '',
  `user_field_2` varchar(255) NOT NULL DEFAULT '',
  `user_field_3` varchar(255) NOT NULL DEFAULT '',
  `parent_type` varchar(100) NOT NULL DEFAULT 'com_content',
  `parent_entity` varchar(100) NOT NULL DEFAULT 'article',
  `parent_id` int(11) unsigned DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `modified` datetime DEFAULT NULL,
  `modified_by` int(11) NOT NULL,
  `download_count` int(11) unsigned DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=74 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prefi_attachments`
--

LOCK TABLES `prefi_attachments` WRITE;
/*!40000 ALTER TABLE `prefi_attachments` DISABLE KEYS */;
INSERT INTO `prefi_attachments` VALUES (2,'pdf-test.pdf','C:\\wamp\\www\\synathina\\attachments\\article\\10\\pdf-test.pdf','application/pdf',20597,'attachments/article/10/pdf-test.pdf','file',0,0,0,'','','pdf.gif',1,1,'','','','com_content','article',10,'2016-03-28 15:13:16',233,'2016-03-28 15:47:13',233,0),(3,'pdf-test.pdf','C:\\wamp\\www\\synathina\\attachments\\article\\9\\pdf-test.pdf','application/pdf',20597,'attachments/article/9/pdf-test.pdf','file',0,0,0,'','','pdf.gif',1,1,'','','','com_content','article',9,'2016-03-28 15:13:25',233,'2016-03-28 15:47:04',233,0),(4,'pdf-test.pdf','C:\\wamp\\www\\synathina\\attachments\\article\\8\\pdf-test.pdf','application/pdf',20597,'attachments/article/8/pdf-test.pdf','file',0,0,0,'','','pdf.gif',1,1,'','','','com_content','article',8,'2016-03-28 15:13:36',233,'2016-03-28 15:46:55',233,0),(5,'pdf-test.pdf','C:\\wamp\\www\\synathina\\attachments\\article\\1\\pdf-test.pdf','application/pdf',20597,'attachments/article/1/pdf-test.pdf','file',0,0,0,'Τεστ pdf 1','','pdf.gif',1,1,'','','','com_content','article',1,'2016-04-11 08:38:12',233,'2016-04-11 08:38:12',233,0),(6,'pdf-test - Copy.pdf','C:\\wamp\\www\\synathina\\attachments\\article\\1\\pdf-test - Copy.pdf','application/pdf',20597,'attachments/article/1/pdf-test - Copy.pdf','file',0,0,0,'Τεστ pdf 2','','pdf.gif',1,1,'','','','com_content','article',1,'2016-04-11 08:38:33',233,'2016-04-11 08:38:33',233,0),(7,'pdf-test - Copy (2).pdf','C:\\wamp\\www\\synathina\\attachments\\article\\1\\pdf-test - Copy (2).pdf','application/pdf',20597,'attachments/article/1/pdf-test - Copy (2).pdf','file',0,0,0,'Τεστ pdf 3','','pdf.gif',1,1,'','','','com_content','article',1,'2016-04-11 08:38:45',233,'2016-04-11 08:38:45',233,0),(8,'pdf-test.pdf','/home/steficdemo/public_html/new/attachments/article/38/pdf-test.pdf','application/pdf',20597,'attachments/article/38/pdf-test.pdf','file',0,0,0,'','','pdf.gif',1,1,'','','','com_content','article',38,'2016-05-28 08:09:01',233,'2016-05-28 08:09:01',233,0),(9,'pdf-test - Copy.pdf','/home/steficdemo/public_html/new/attachments/article/38/pdf-test - Copy.pdf','application/pdf',20597,'attachments/article/38/pdf-test - Copy.pdf','file',0,0,0,'','','pdf.gif',1,1,'','','','com_content','article',38,'2016-05-28 08:09:14',233,'2016-05-28 08:09:14',233,0),(10,'pdf-test - Copy (2).pdf','/home/steficdemo/public_html/new/attachments/article/39/pdf-test - Copy (2).pdf','application/pdf',20597,'attachments/article/39/pdf-test - Copy (2).pdf','file',0,0,0,'','','pdf.gif',1,1,'','','','com_content','article',39,'2016-05-28 08:09:48',233,'2016-05-28 08:09:48',233,0),(11,'pdf-test - Copy.pdf','/home/steficdemo/public_html/new/attachments/article/39/pdf-test - Copy.pdf','application/pdf',20597,'attachments/article/39/pdf-test - Copy.pdf','file',0,0,0,'','','pdf.gif',1,1,'','','','com_content','article',39,'2016-05-28 08:16:46',233,'2016-05-28 08:16:46',233,0),(12,'pdf-test.pdf','/home/steficdemo/public_html/new/attachments/article/39/pdf-test.pdf','application/pdf',20597,'attachments/article/39/pdf-test.pdf','file',0,0,0,'','','pdf.gif',1,1,'','','','com_content','article',39,'2016-05-28 10:32:37',233,'2016-05-28 10:32:37',233,0);
/*!40000 ALTER TABLE `prefi_attachments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prefi_banner_clients`
--

DROP TABLE IF EXISTS `prefi_banner_clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `prefi_banner_clients` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `contact` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `extrainfo` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `state` tinyint(3) NOT NULL DEFAULT '0',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `metakey` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `own_prefix` tinyint(4) NOT NULL DEFAULT '0',
  `metakey_prefix` varchar(400) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `purchase_type` tinyint(4) NOT NULL DEFAULT '-1',
  `track_clicks` tinyint(4) NOT NULL DEFAULT '-1',
  `track_impressions` tinyint(4) NOT NULL DEFAULT '-1',
  PRIMARY KEY (`id`),
  KEY `idx_own_prefix` (`own_prefix`),
  KEY `idx_metakey_prefix` (`metakey_prefix`(100))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prefi_banner_clients`
--

LOCK TABLES `prefi_banner_clients` WRITE;
/*!40000 ALTER TABLE `prefi_banner_clients` DISABLE KEYS */;
/*!40000 ALTER TABLE `prefi_banner_clients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prefi_banner_tracks`
--

DROP TABLE IF EXISTS `prefi_banner_tracks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `prefi_banner_tracks` (
  `track_date` datetime NOT NULL,
  `track_type` int(10) unsigned NOT NULL,
  `banner_id` int(10) unsigned NOT NULL,
  `count` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`track_date`,`track_type`,`banner_id`),
  KEY `idx_track_date` (`track_date`),
  KEY `idx_track_type` (`track_type`),
  KEY `idx_banner_id` (`banner_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prefi_banner_tracks`
--

LOCK TABLES `prefi_banner_tracks` WRITE;
/*!40000 ALTER TABLE `prefi_banner_tracks` DISABLE KEYS */;
/*!40000 ALTER TABLE `prefi_banner_tracks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prefi_banners`
--

DROP TABLE IF EXISTS `prefi_banners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `prefi_banners` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cid` int(11) NOT NULL DEFAULT '0',
  `type` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `alias` varchar(400) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `imptotal` int(11) NOT NULL DEFAULT '0',
  `impmade` int(11) NOT NULL DEFAULT '0',
  `clicks` int(11) NOT NULL DEFAULT '0',
  `clickurl` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `state` tinyint(3) NOT NULL DEFAULT '0',
  `catid` int(10) unsigned NOT NULL DEFAULT '0',
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `custombannercode` varchar(2048) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `sticky` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `metakey` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `params` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `own_prefix` tinyint(1) NOT NULL DEFAULT '0',
  `metakey_prefix` varchar(400) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `purchase_type` tinyint(4) NOT NULL DEFAULT '-1',
  `track_clicks` tinyint(4) NOT NULL DEFAULT '-1',
  `track_impressions` tinyint(4) NOT NULL DEFAULT '-1',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `reset` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `language` char(7) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `created_by` int(10) unsigned NOT NULL DEFAULT '0',
  `created_by_alias` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(10) unsigned NOT NULL DEFAULT '0',
  `version` int(10) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `idx_state` (`state`),
  KEY `idx_own_prefix` (`own_prefix`),
  KEY `idx_metakey_prefix` (`metakey_prefix`(100)),
  KEY `idx_banner_catid` (`catid`),
  KEY `idx_language` (`language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prefi_banners`
--

LOCK TABLES `prefi_banners` WRITE;
/*!40000 ALTER TABLE `prefi_banners` DISABLE KEYS */;
/*!40000 ALTER TABLE `prefi_banners` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prefi_categories`
--

DROP TABLE IF EXISTS `prefi_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `prefi_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `asset_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'FK to the #__assets table.',
  `parent_id` int(10) unsigned NOT NULL DEFAULT '0',
  `lft` int(11) NOT NULL DEFAULT '0',
  `rgt` int(11) NOT NULL DEFAULT '0',
  `level` int(10) unsigned NOT NULL DEFAULT '0',
  `path` varchar(400) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `extension` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `alias` varchar(400) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `note` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `checked_out` int(11) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `access` int(10) unsigned NOT NULL DEFAULT '0',
  `params` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `metadesc` varchar(1024) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'The meta description for the page.',
  `metakey` varchar(1024) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'The meta keywords for the page.',
  `metadata` varchar(2048) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'JSON encoded metadata properties.',
  `created_user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `created_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `modified_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `hits` int(10) unsigned NOT NULL DEFAULT '0',
  `language` char(7) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `version` int(10) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `cat_idx` (`extension`,`published`,`access`),
  KEY `idx_access` (`access`),
  KEY `idx_checkout` (`checked_out`),
  KEY `idx_path` (`path`(100)),
  KEY `idx_left_right` (`lft`,`rgt`),
  KEY `idx_alias` (`alias`(100)),
  KEY `idx_language` (`language`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prefi_categories`
--

LOCK TABLES `prefi_categories` WRITE;
/*!40000 ALTER TABLE `prefi_categories` DISABLE KEYS */;
INSERT INTO `prefi_categories` VALUES (1,0,0,0,43,0,'','system','ROOT','root','','',1,0,'0000-00-00 00:00:00',1,'{}','','','{}',42,'2011-01-01 00:00:01',0,'0000-00-00 00:00:00',0,'*',1),(2,27,1,3,4,1,'uncategorised','com_content','Διάφορα','uncategorised','','',1,233,'2018-07-23 13:29:39',1,'{\"category_layout\":\"\",\"image\":\"\",\"image_alt\":\"\"}','','','{\"author\":\"\",\"robots\":\"\"}',42,'2011-01-01 00:00:01',233,'2016-03-28 14:37:39',0,'*',1),(3,28,1,9,10,1,'uncategorised','com_banners','Uncategorised','uncategorised','','',1,0,'0000-00-00 00:00:00',1,'{\"category_layout\":\"\",\"image\":\"\"}','','','{\"author\":\"\",\"robots\":\"\"}',42,'2011-01-01 00:00:01',0,'0000-00-00 00:00:00',0,'*',1),(4,29,1,23,24,1,'uncategorised','com_contact','Uncategorised','uncategorised','','',1,0,'0000-00-00 00:00:00',1,'{\"category_layout\":\"\",\"image\":\"\"}','','','{\"author\":\"\",\"robots\":\"\"}',42,'2011-01-01 00:00:01',0,'0000-00-00 00:00:00',0,'*',1),(5,30,1,29,30,1,'uncategorised','com_newsfeeds','Uncategorised','uncategorised','','',1,0,'0000-00-00 00:00:00',1,'{\"category_layout\":\"\",\"image\":\"\"}','','','{\"author\":\"\",\"robots\":\"\"}',42,'2011-01-01 00:00:01',0,'0000-00-00 00:00:00',0,'*',1),(7,32,1,35,36,1,'uncategorised','com_users','Uncategorised','uncategorised','','',1,0,'0000-00-00 00:00:00',1,'{\"category_layout\":\"\",\"image\":\"\"}','','','{\"author\":\"\",\"robots\":\"\"}',42,'2011-01-01 00:00:01',0,'0000-00-00 00:00:00',0,'*',1),(8,56,1,1,2,1,'άρθρα','com_content','Άρθρα','άρθρα','','',0,0,'0000-00-00 00:00:00',1,'{\"category_layout\":\"\",\"image\":\"\",\"image_alt\":\"\"}','','','{\"author\":\"\",\"robots\":\"\"}',233,'2016-03-28 12:39:57',233,'2016-06-26 16:12:54',0,'*',1),(9,67,1,5,6,1,'press','com_content','Press','press','','',1,0,'0000-00-00 00:00:00',1,'{\"category_layout\":\"\",\"image\":\"\",\"image_alt\":\"\"}','','','{\"author\":\"\",\"robots\":\"\"}',233,'2016-03-28 15:09:43',0,'2016-03-28 15:09:43',0,'*',1),(10,80,1,7,8,1,'νέα','com_content','Νέα','νέα','','',1,233,'2019-02-14 09:59:27',1,'{\"category_layout\":\"\",\"image\":\"\",\"image_alt\":\"\"}','','','{\"author\":\"\",\"robots\":\"\"}',233,'2016-03-29 10:15:51',233,'2016-06-26 16:12:48',0,'*',1),(11,107,1,11,12,1,'συναθηνά','com_content','Συναθηνά','συναθηνά','','',1,0,'0000-00-00 00:00:00',1,'{\"category_layout\":\"\",\"image\":\"\",\"image_alt\":\"\"}','','','{\"author\":\"\",\"robots\":\"\"}',233,'2016-05-10 00:06:55',0,'2016-05-10 00:06:55',0,'el-GR',1),(12,328,1,13,14,1,'ομάδες','com_content','Ομάδες','ομάδες','','',1,233,'2018-08-27 14:09:08',1,'{\"category_layout\":\"\",\"image\":\"\",\"image_alt\":\"\"}','','','{\"author\":\"\",\"robots\":\"\"}',233,'2016-05-12 12:20:13',0,'2016-05-12 12:20:13',0,'el-GR',1),(13,1887,1,15,16,1,'δίκτυο','com_content','Δίκτυο','δίκτυο','','',1,0,'0000-00-00 00:00:00',1,'{\"category_layout\":\"\",\"image\":\"\",\"image_alt\":\"\"}','','','{\"author\":\"\",\"robots\":\"\"}',233,'2016-05-24 12:48:32',233,'2017-01-25 10:31:15',0,'*',1),(14,1908,1,17,18,1,'εγχείριδια-δράσεων-toolkits','com_content','Εγχείριδια δράσεων / Toolkits','εγχείριδια-δράσεων-toolkits','','',1,0,'0000-00-00 00:00:00',1,'{\"category_layout\":\"\",\"image\":\"\",\"image_alt\":\"\"}','','','{\"author\":\"\",\"robots\":\"\"}',233,'2016-05-28 08:08:28',0,'2016-05-28 08:08:28',0,'*',1),(15,1912,1,19,20,1,'open-calls','com_content','Open Calls','open-calls','','',1,233,'2018-07-17 12:28:35',1,'{\"category_layout\":\"\",\"image\":\"\",\"image_alt\":\"\"}','','','{\"author\":\"\",\"robots\":\"\"}',233,'2016-05-29 11:52:36',0,'2016-05-29 11:52:36',0,'*',1),(16,1913,1,21,22,1,'groups','com_content','Groups','groups','','',1,233,'2018-07-23 13:23:54',1,'{\"category_layout\":\"\",\"image\":\"\",\"image_alt\":\"\"}','','','{\"author\":\"\",\"robots\":\"\"}',233,'2016-05-29 12:48:39',0,'2016-05-29 12:48:39',0,'en-GB',1),(17,1920,1,25,26,1,'synathina-kiosk','com_content','Synathina kiosk','synathina-kiosk','','',1,0,'0000-00-00 00:00:00',1,'{\"category_layout\":\"\",\"image\":\"\",\"image_alt\":\"\"}','','','{\"author\":\"\",\"robots\":\"\"}',233,'2016-05-29 13:35:19',233,'2016-05-29 13:35:35',0,'en-GB',1),(18,1921,1,27,28,1,'network','com_content','Network','network','','',1,0,'0000-00-00 00:00:00',1,'{\"category_layout\":\"\",\"image\":\"\",\"image_alt\":\"\"}','','','{\"author\":\"\",\"robots\":\"\"}',233,'2016-05-29 13:36:02',233,'2017-01-25 11:07:23',0,'en-GB',1),(19,1922,1,31,32,1,'synathina','com_content','Synathina','synathina','','',1,0,'0000-00-00 00:00:00',1,'{\"category_layout\":\"\",\"image\":\"\",\"image_alt\":\"\"}','','','{\"author\":\"\",\"robots\":\"\"}',233,'2016-05-29 13:38:48',0,'2016-05-29 13:38:48',0,'en-GB',1),(20,4905,1,33,34,1,'καλές-πρακτικές','com_content','Βέλτιστες πρακτικές','καλές-πρακτικές','','',1,233,'2018-07-23 13:26:06',1,'{\"category_layout\":\"\",\"image\":\"\",\"image_alt\":\"\"}','','','{\"author\":\"\",\"robots\":\"\"}',233,'2017-02-02 13:25:32',233,'2017-03-14 13:12:26',0,'el-GR',1),(21,4906,1,37,38,1,'best-practices','com_content','Best practices','best-practices','','',1,233,'2018-07-17 12:28:27',1,'{\"category_layout\":\"\",\"image\":\"\",\"image_alt\":\"\"}','','','{\"author\":\"\",\"robots\":\"\"}',233,'2017-02-02 13:25:51',0,'2017-02-02 13:25:51',0,'en-GB',1),(22,8451,1,39,40,1,'υποστηρικτές','com_content','Υποστηρικτές','υποστηρικτές','','',1,233,'2018-07-23 13:39:43',1,'{\"category_layout\":\"\",\"image\":\"\",\"image_alt\":\"\"}','','','{\"author\":\"\",\"robots\":\"\"}',233,'2018-05-14 18:07:41',0,'2018-05-14 18:07:41',0,'el-GR',1),(23,8452,1,41,42,1,'supporters','com_content','Supporters','supporters','','',1,233,'2018-07-23 13:23:39',1,'{\"category_layout\":\"\",\"image\":\"\",\"image_alt\":\"\"}','','','{\"author\":\"\",\"robots\":\"\"}',233,'2018-05-14 18:08:00',233,'2018-05-14 19:19:03',0,'en-GB',1);
/*!40000 ALTER TABLE `prefi_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prefi_contact_details`
--

DROP TABLE IF EXISTS `prefi_contact_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `prefi_contact_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `alias` varchar(400) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `con_position` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `suburb` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `state` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `postcode` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `telephone` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fax` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `misc` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `image` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_to` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `default_con` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `params` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `catid` int(11) NOT NULL DEFAULT '0',
  `access` int(10) unsigned NOT NULL DEFAULT '0',
  `mobile` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `webpage` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `sortname1` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `sortname2` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `sortname3` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `language` char(7) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(10) unsigned NOT NULL DEFAULT '0',
  `created_by_alias` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(10) unsigned NOT NULL DEFAULT '0',
  `metakey` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `metadesc` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `metadata` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `featured` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT 'Set if article is featured.',
  `xreference` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'A reference to enable linkages to external data sets.',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `version` int(10) unsigned NOT NULL DEFAULT '1',
  `hits` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_access` (`access`),
  KEY `idx_checkout` (`checked_out`),
  KEY `idx_state` (`published`),
  KEY `idx_catid` (`catid`),
  KEY `idx_createdby` (`created_by`),
  KEY `idx_featured_catid` (`featured`,`catid`),
  KEY `idx_language` (`language`),
  KEY `idx_xreference` (`xreference`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prefi_contact_details`
--

LOCK TABLES `prefi_contact_details` WRITE;
/*!40000 ALTER TABLE `prefi_contact_details` DISABLE KEYS */;
INSERT INTO `prefi_contact_details` VALUES (1,'Επικοινωνία','επικοινωνία','','','','','','','','','<p>Η ομάδα του συνΑθηνά σε περιμένει τις Ανοιχτές Δευτέρες στο γραφείο της, από τις 3 έως τις 7 μ.μ. <br /><br /> <strong>Γραφείο συνΑθηνά:</strong>&nbsp;Σεράφειο Συγκρότημα, Κτίριο Β\' 2ος όροφος, Πειραιώς και Πέτρου Ράλλη, Ρουφ.<br /><strong>στέγη του συνΑθηνά: </strong>Αθηνάς 55, πλατεία Βαρβάκειου.</p>\r\n<p>&nbsp;</p>\r\n<div class=\"is-block inline-list__label\">Social Media:</div>\r\n<ul class=\"inline-list inline-list--socialmedia\">\r\n<li><a href=\"https://www.facebook.com/SunAthina\" target=\"_blank\" class=\"facebook\"><i class=\"fa fa-facebook\"></i></a></li>\r\n<li><a href=\"https://twitter.com/synathina\" target=\"_blank\" class=\"twitter\"><i class=\"fa fa-twitter\"></i></a></li>\r\n<li><a href=\"https://www.instagram.com/synathina/\" target=\"_blank\" class=\"instagram\"><i class=\"fa fa-instagram\"></i></a></li>\r\n<li><a href=\"https://www.linkedin.com/company/synathina\" target=\"_blank\" class=\"linkedin\"><i class=\"fa fa-linkedin\"></i></a></li>\r\n<li><a href=\"https://www.youtube.com/channel/UCgA-jpbuZG4YMuQE5GGewZA\" target=\"_blank\" class=\"youtube-icon\"><i class=\"fa fa-youtube\"></i></a></li>\r\n</ul>','','synathina@athens.gr',0,1,0,'0000-00-00 00:00:00',1,'{\"show_contact_category\":\"\",\"show_contact_list\":\"\",\"presentation_style\":\"plain\",\"show_tags\":\"\",\"show_name\":\"\",\"show_position\":\"\",\"show_email\":\"\",\"show_street_address\":\"\",\"show_suburb\":\"\",\"show_state\":\"\",\"show_postcode\":\"\",\"show_country\":\"\",\"show_telephone\":\"\",\"show_mobile\":\"\",\"show_fax\":\"\",\"show_webpage\":\"\",\"show_misc\":\"\",\"show_image\":\"\",\"allow_vcard\":\"\",\"show_articles\":\"\",\"articles_display_num\":\"\",\"show_profile\":\"\",\"show_links\":\"\",\"linka_name\":\"\",\"linka\":false,\"linkb_name\":\"\",\"linkb\":false,\"linkc_name\":\"\",\"linkc\":false,\"linkd_name\":\"\",\"linkd\":false,\"linke_name\":\"\",\"linke\":false,\"contact_layout\":\"\",\"show_email_form\":\"\",\"show_email_copy\":\"\",\"banned_email\":\"\",\"banned_subject\":\"\",\"banned_text\":\"\",\"validate_session\":\"\",\"custom_reply\":\"\",\"redirect\":\"\"}',0,4,1,'','','','','','*','2016-03-28 14:35:06',233,'','2017-10-29 18:19:19',233,'','','{\"robots\":\"\",\"rights\":\"\"}',0,'','0000-00-00 00:00:00','0000-00-00 00:00:00',15,3160),(2,'Contact','contact','','','','','','','','','<p>On Monday afternoons, from 3pm to 7pm, the offices of synAthina are open for groups and citizens who would like to present and discuss their activities or wish to learn more about the mission of synAthina. Together, we can think about ways to cooperate and the tools we need to provide to citizens’ groups in order to support their activities (communication, housing, connection with other groups, municipal services and supporters, etc.) and to realize their projects more effectively. Open Mondays is the most regular channel of direct communication between synAthina and citizens’ groups. The knowledge we gain from our weekly meetings helps us create tools to update the services and the practices of the Municipality.<br /><br /></p>\r\n<p>The offices of synAthina are located in Serafio Complex, on the 2nd floor of Building B, Peiraios &amp; Petrou Ralli, Rouf. There is no need for prior contact if you wish to visit us. In any case, knowing that you plan to visit us allows us to be better prepared.<br /><br /> Email:&nbsp;<a href=\"mailto:synathina@athens.gr\">synathina@athens.gr<br /><br /></a><a href=\"mailto:synathina@cityofathens.gr\"></a></p>\r\n<div class=\"is-block inline-list__label\">Social Media:</div>\r\n<ul class=\"inline-list inline-list--socialmedia\">\r\n<li><a href=\"https://www.facebook.com/SunAthina\" target=\"_blank\" class=\"facebook\"><i class=\"fa fa-facebook\"></i></a></li>\r\n<li><a href=\"https://twitter.com/synathina\" target=\"_blank\" class=\"twitter\"><i class=\"fa fa-twitter\"></i></a></li>\r\n<li><a href=\"https://www.instagram.com/synathina/\" target=\"_blank\" class=\"instagram\"><i class=\"fa fa-instagram\"></i></a></li>\r\n<li><a href=\"https://www.linkedin.com/company/synathina\" target=\"_blank\" class=\"linkedin\"><i class=\"fa fa-linkedin\"></i></a></li>\r\n<li><a href=\"https://www.youtube.com/channel/UCgA-jpbuZG4YMuQE5GGewZA\" target=\"_blank\" class=\"youtube-icon\"><i class=\"fa fa-youtube\"></i></a></li>\r\n</ul>','','synathina@athens.gr',0,1,0,'0000-00-00 00:00:00',2,'{\"show_contact_category\":\"\",\"show_contact_list\":\"\",\"presentation_style\":\"plain\",\"show_tags\":\"\",\"show_name\":\"\",\"show_position\":\"\",\"show_email\":\"\",\"show_street_address\":\"\",\"show_suburb\":\"\",\"show_state\":\"\",\"show_postcode\":\"\",\"show_country\":\"\",\"show_telephone\":\"\",\"show_mobile\":\"\",\"show_fax\":\"\",\"show_webpage\":\"\",\"show_misc\":\"\",\"show_image\":\"\",\"allow_vcard\":\"\",\"show_articles\":\"\",\"articles_display_num\":\"\",\"show_profile\":\"\",\"show_links\":\"\",\"linka_name\":\"\",\"linka\":false,\"linkb_name\":\"\",\"linkb\":false,\"linkc_name\":\"\",\"linkc\":false,\"linkd_name\":\"\",\"linkd\":false,\"linke_name\":\"\",\"linke\":false,\"contact_layout\":\"\",\"show_email_form\":\"\",\"show_email_copy\":\"\",\"banned_email\":\"\",\"banned_subject\":\"\",\"banned_text\":\"\",\"validate_session\":\"\",\"custom_reply\":\"\",\"redirect\":\"\"}',0,4,1,'','','','','','*','2016-05-29 14:38:49',233,'','2017-10-29 18:09:58',233,'','','{\"robots\":\"\",\"rights\":\"\"}',0,'','0000-00-00 00:00:00','0000-00-00 00:00:00',11,4973);
/*!40000 ALTER TABLE `prefi_contact_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prefi_content`
--

DROP TABLE IF EXISTS `prefi_content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `prefi_content` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `asset_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'FK to the #__assets table.',
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `alias` varchar(400) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `introtext` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `fulltext` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `state` tinyint(3) NOT NULL DEFAULT '0',
  `catid` int(10) unsigned NOT NULL DEFAULT '0',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(10) unsigned NOT NULL DEFAULT '0',
  `created_by_alias` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `images` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `urls` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attribs` varchar(5120) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `version` int(10) unsigned NOT NULL DEFAULT '1',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `metakey` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `metadesc` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `access` int(10) unsigned NOT NULL DEFAULT '0',
  `hits` int(10) unsigned NOT NULL DEFAULT '0',
  `metadata` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `featured` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT 'Set if article is featured.',
  `language` char(7) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'The language code for the article.',
  `xreference` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'A reference to enable linkages to external data sets.',
  PRIMARY KEY (`id`),
  KEY `idx_access` (`access`),
  KEY `idx_checkout` (`checked_out`),
  KEY `idx_state` (`state`),
  KEY `idx_catid` (`catid`),
  KEY `idx_createdby` (`created_by`),
  KEY `idx_featured_catid` (`featured`,`catid`),
  KEY `idx_language` (`language`),
  KEY `idx_xreference` (`xreference`)
) ENGINE=InnoDB AUTO_INCREMENT=815 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prefi_content`
--

LOCK TABLES `prefi_content` WRITE;
/*!40000 ALTER TABLE `prefi_content` DISABLE KEYS */;
INSERT INTO `prefi_content` VALUES (1,57,'Τι έκαναν οι πολίτες αυτήν την εβδομάδα;','τι-έκαναν-οι-πολίτες-αυτήν-την-εβδομάδα','<p>Μια εβδομάδα γεμάτη δράσεις για τον πολιτισμό, την καλλιτεχνική έκφραση, το περιβάλλον και την υγεία ολοκληρώθηκε! δράσεις για την Αθήνα. Η ομάδα του...</p>\r\n','\r\n<p><img src=\"images/news/new.jpg\" alt=\"\" />&nbsp;</p>\r\n<p>Μια εβδομάδα γεμάτη δράσεις για τον πολιτισμό, την καλλιτεχνική έκφραση, το περιβάλλον και την υγεία ολοκληρώθηκε! δράσεις για την Αθήνα. Η ομάδα του...Μια εβδομάδα γεμάτη δράσεις για τον πολιτισμό, την καλλιτεχνική έκφραση, το περιβάλλον και την υγεία ολοκληρώθηκε! δράσεις για την Αθήνα. Η ομάδα του...Μια εβδομάδα γεμάτη δράσεις για τον πολιτισμό, την καλλιτεχνική έκφραση, το περιβάλλον και την υγεία ολοκληρώθηκε! δράσεις για την Αθήνα. Η ομάδα του...Μια εβδομάδα γεμάτη δράσεις για τον πολιτισμό, την καλλιτεχνική έκφραση, το περιβάλλον και την υγεία ολοκληρώθηκε! δράσεις για την Αθήνα. Η ομάδα του...Μια εβδομάδα γεμάτη δράσεις για τον πολιτισμό, την καλλιτεχνική έκφραση, το περιβάλλον και την υγεία ολοκληρώθηκε! δράσεις για την Αθήνα. Η ομάδα του...</p>\r\n<p><iframe src=\"https://www.youtube.com/embed/aDgXtbI1sJM\" width=\"420\" height=\"315\" frameborder=\"0\" allowfullscreen=\"allowfullscreen\"></iframe></p>\r\n<p>Μια εβδομάδα γεμάτη δράσεις για τον πολιτισμό, την καλλιτεχνική έκφραση, το περιβάλλον και την υγεία ολοκληρώθηκε! δράσεις για την Αθήνα. Η ομάδα του...Μια εβδομάδα γεμάτη δράσεις για τον πολιτισμό, την καλλιτεχνική έκφραση, το περιβάλλον και την υγεία ολοκληρώθηκε! δράσεις για την Αθήνα. Η ομάδα του...Μια εβδομάδα γεμάτη δράσεις για τον πολιτισμό, την καλλιτεχνική έκφραση, το περιβάλλον και την υγεία ολοκληρώθηκε! δράσεις για την Αθήνα. Η ομάδα του...</p>',-2,8,'2016-04-11 12:40:00',233,'','2016-04-11 10:40:51',233,233,'2016-07-03 15:34:54','2016-03-28 12:40:32','0000-00-00 00:00:00','{\"image_intro\":\"images\\/news\\/new.jpg\",\"float_intro\":\"\",\"image_intro_alt\":\"\",\"image_intro_caption\":\"\",\"image_fulltext\":\"\",\"float_fulltext\":\"\",\"image_fulltext_alt\":\"\",\"image_fulltext_caption\":\"\"}','{\"urla\":false,\"urlatext\":\"\",\"targeta\":\"\",\"urlb\":false,\"urlbtext\":\"\",\"targetb\":\"\",\"urlc\":false,\"urlctext\":\"\",\"targetc\":\"\"}','{\"news_subtitle\":\"23 Νοεμβρίου - 30 Δεκεμβρίου\",\"article_video\":\"\",\"show_title\":\"\",\"link_titles\":\"\",\"show_tags\":\"\",\"show_intro\":\"\",\"info_block_position\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_vote\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',11,58,'','',1,1819,'{\"robots\":\"\",\"author\":\"\",\"rights\":\"\",\"xreference\":\"\"}',0,'*',''),(2,59,'Τι έκαναν οι πολίτες αυτήν την εβδομάδα; (2)','τι-έκαναν-οι-πολίτες-αυτήν-την-εβδομάδα-2','<p>Μια εβδομάδα γεμάτη δράσεις για τον πολιτισμό, την καλλιτεχνική έκφραση, το περιβάλλον και την υγεία ολοκληρώθηκε! δράσεις για την Αθήνα. Η ομάδα του...</p>\r\n','\r\n<p>&nbsp;</p>\r\n<p>Μια εβδομάδα γεμάτη δράσεις για τον πολιτισμό, την καλλιτεχνική έκφραση, το περιβάλλον και την υγεία ολοκληρώθηκε! δράσεις για την Αθήνα. Η ομάδα του...Μια εβδομάδα γεμάτη δράσεις για τον πολιτισμό, την καλλιτεχνική έκφραση, το περιβάλλον και την υγεία ολοκληρώθηκε! δράσεις για την Αθήνα. Η ομάδα του...Μια εβδομάδα γεμάτη δράσεις για τον πολιτισμό, την καλλιτεχνική έκφραση, το περιβάλλον και την υγεία ολοκληρώθηκε! δράσεις για την Αθήνα. Η ομάδα του...Μια εβδομάδα γεμάτη δράσεις για τον πολιτισμό, την καλλιτεχνική έκφραση, το περιβάλλον και την υγεία ολοκληρώθηκε! δράσεις για την Αθήνα. Η ομάδα του...Μια εβδομάδα γεμάτη δράσεις για τον πολιτισμό, την καλλιτεχνική έκφραση, το περιβάλλον και την υγεία ολοκληρώθηκε! δράσεις για την Αθήνα. Η ομάδα του...</p>\r\n<p>Μια εβδομάδα γεμάτη δράσεις για τον πολιτισμό, την καλλιτεχνική έκφραση, το περιβάλλον και την υγεία ολοκληρώθηκε! δράσεις για την Αθήνα. Η ομάδα του...Μια εβδομάδα γεμάτη δράσεις για τον πολιτισμό, την καλλιτεχνική έκφραση, το περιβάλλον και την υγεία ολοκληρώθηκε! δράσεις για την Αθήνα. Η ομάδα του...Μια εβδομάδα γεμάτη δράσεις για τον πολιτισμό, την καλλιτεχνική έκφραση, το περιβάλλον και την υγεία ολοκληρώθηκε! δράσεις για την Αθήνα. Η ομάδα του...</p>',-2,8,'2015-12-02 13:40:00',233,'','2016-03-28 13:22:27',0,0,'0000-00-00 00:00:00','2016-03-28 12:40:32','0000-00-00 00:00:00','{\"image_intro\":\"images\\/news\\/new.jpg\",\"float_intro\":\"\",\"image_intro_alt\":\"\",\"image_intro_caption\":\"\",\"image_fulltext\":\"\",\"float_fulltext\":\"\",\"image_fulltext_alt\":\"\",\"image_fulltext_caption\":\"\"}','{\"urla\":false,\"urlatext\":\"\",\"targeta\":\"\",\"urlb\":false,\"urlbtext\":\"\",\"targetb\":\"\",\"urlc\":false,\"urlctext\":\"\",\"targetc\":\"\"}','{\"news_subtitle\":\"23 Νοεμβρίου - 30 Δεκεμβρίου\",\"show_title\":\"\",\"link_titles\":\"\",\"show_tags\":\"\",\"show_intro\":\"\",\"info_block_position\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_vote\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',1,57,'','',1,3536,'{\"robots\":\"\",\"author\":\"\",\"rights\":\"\",\"xreference\":\"\"}',0,'*',''),(3,60,'Τι έκαναν οι πολίτες αυτήν την εβδομάδα; (3)','τι-έκαναν-οι-πολίτες-αυτήν-την-εβδομάδα-3','<p>Μια εβδομάδα γεμάτη δράσεις για τον πολιτισμό, την καλλιτεχνική έκφραση, το περιβάλλον και την υγεία ολοκληρώθηκε! δράσεις για την Αθήνα. Η ομάδα του...</p>\r\n','\r\n<p>&nbsp;</p>\r\n<p>Μια εβδομάδα γεμάτη δράσεις για τον πολιτισμό, την καλλιτεχνική έκφραση, το περιβάλλον και την υγεία ολοκληρώθηκε! δράσεις για την Αθήνα. Η ομάδα του...Μια εβδομάδα γεμάτη δράσεις για τον πολιτισμό, την καλλιτεχνική έκφραση, το περιβάλλον και την υγεία ολοκληρώθηκε! δράσεις για την Αθήνα. Η ομάδα του...Μια εβδομάδα γεμάτη δράσεις για τον πολιτισμό, την καλλιτεχνική έκφραση, το περιβάλλον και την υγεία ολοκληρώθηκε! δράσεις για την Αθήνα. Η ομάδα του...Μια εβδομάδα γεμάτη δράσεις για τον πολιτισμό, την καλλιτεχνική έκφραση, το περιβάλλον και την υγεία ολοκληρώθηκε! δράσεις για την Αθήνα. Η ομάδα του...Μια εβδομάδα γεμάτη δράσεις για τον πολιτισμό, την καλλιτεχνική έκφραση, το περιβάλλον και την υγεία ολοκληρώθηκε! δράσεις για την Αθήνα. Η ομάδα του...</p>\r\n<p>Μια εβδομάδα γεμάτη δράσεις για τον πολιτισμό, την καλλιτεχνική έκφραση, το περιβάλλον και την υγεία ολοκληρώθηκε! δράσεις για την Αθήνα. Η ομάδα του...Μια εβδομάδα γεμάτη δράσεις για τον πολιτισμό, την καλλιτεχνική έκφραση, το περιβάλλον και την υγεία ολοκληρώθηκε! δράσεις για την Αθήνα. Η ομάδα του...Μια εβδομάδα γεμάτη δράσεις για τον πολιτισμό, την καλλιτεχνική έκφραση, το περιβάλλον και την υγεία ολοκληρώθηκε! δράσεις για την Αθήνα. Η ομάδα του...</p>',-2,8,'2016-01-20 13:40:00',233,'','2016-03-29 09:15:16',233,0,'0000-00-00 00:00:00','2016-03-28 12:40:32','0000-00-00 00:00:00','{\"image_intro\":\"images\\/news\\/new.jpg\",\"float_intro\":\"\",\"image_intro_alt\":\"\",\"image_intro_caption\":\"\",\"image_fulltext\":\"\",\"float_fulltext\":\"\",\"image_fulltext_alt\":\"\",\"image_fulltext_caption\":\"\"}','{\"urla\":false,\"urlatext\":\"\",\"targeta\":\"\",\"urlb\":false,\"urlbtext\":\"\",\"targetb\":\"\",\"urlc\":false,\"urlctext\":\"\",\"targetc\":\"\"}','{\"news_subtitle\":\"23 Νοεμβρίου - 30 Δεκεμβρίου\",\"show_title\":\"\",\"link_titles\":\"\",\"show_tags\":\"\",\"show_intro\":\"\",\"info_block_position\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_vote\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',2,56,'','',1,2714,'{\"robots\":\"\",\"author\":\"\",\"rights\":\"\",\"xreference\":\"\"}',0,'*',''),(4,61,'Τι έκαναν οι πολίτες αυτήν την εβδομάδα; (4)','τι-έκαναν-οι-πολίτες-αυτήν-την-εβδομάδα-4','<p>Μια εβδομάδα γεμάτη δράσεις για τον πολιτισμό, την καλλιτεχνική έκφραση, το περιβάλλον και την υγεία ολοκληρώθηκε! δράσεις για την Αθήνα. Η ομάδα του...</p>\r\n','\r\n<p>&nbsp;</p>\r\n<p>Μια εβδομάδα γεμάτη δράσεις για τον πολιτισμό, την καλλιτεχνική έκφραση, το περιβάλλον και την υγεία ολοκληρώθηκε! δράσεις για την Αθήνα. Η ομάδα του...Μια εβδομάδα γεμάτη δράσεις για τον πολιτισμό, την καλλιτεχνική έκφραση, το περιβάλλον και την υγεία ολοκληρώθηκε! δράσεις για την Αθήνα. Η ομάδα του...Μια εβδομάδα γεμάτη δράσεις για τον πολιτισμό, την καλλιτεχνική έκφραση, το περιβάλλον και την υγεία ολοκληρώθηκε! δράσεις για την Αθήνα. Η ομάδα του...Μια εβδομάδα γεμάτη δράσεις για τον πολιτισμό, την καλλιτεχνική έκφραση, το περιβάλλον και την υγεία ολοκληρώθηκε! δράσεις για την Αθήνα. Η ομάδα του...Μια εβδομάδα γεμάτη δράσεις για τον πολιτισμό, την καλλιτεχνική έκφραση, το περιβάλλον και την υγεία ολοκληρώθηκε! δράσεις για την Αθήνα. Η ομάδα του...</p>\r\n<p>Μια εβδομάδα γεμάτη δράσεις για τον πολιτισμό, την καλλιτεχνική έκφραση, το περιβάλλον και την υγεία ολοκληρώθηκε! δράσεις για την Αθήνα. Η ομάδα του...Μια εβδομάδα γεμάτη δράσεις για τον πολιτισμό, την καλλιτεχνική έκφραση, το περιβάλλον και την υγεία ολοκληρώθηκε! δράσεις για την Αθήνα. Η ομάδα του...Μια εβδομάδα γεμάτη δράσεις για τον πολιτισμό, την καλλιτεχνική έκφραση, το περιβάλλον και την υγεία ολοκληρώθηκε! δράσεις για την Αθήνα. Η ομάδα του...</p>',-2,8,'2015-12-02 13:40:00',233,'','2016-03-28 13:22:32',0,0,'0000-00-00 00:00:00','2016-03-28 12:40:32','0000-00-00 00:00:00','{\"image_intro\":\"images\\/news\\/new.jpg\",\"float_intro\":\"\",\"image_intro_alt\":\"\",\"image_intro_caption\":\"\",\"image_fulltext\":\"\",\"float_fulltext\":\"\",\"image_fulltext_alt\":\"\",\"image_fulltext_caption\":\"\"}','{\"urla\":false,\"urlatext\":\"\",\"targeta\":\"\",\"urlb\":false,\"urlbtext\":\"\",\"targetb\":\"\",\"urlc\":false,\"urlctext\":\"\",\"targetc\":\"\"}','{\"news_subtitle\":\"23 Νοεμβρίου - 30 Δεκεμβρίου\",\"show_title\":\"\",\"link_titles\":\"\",\"show_tags\":\"\",\"show_intro\":\"\",\"info_block_position\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_vote\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',1,55,'','',1,1833,'{\"robots\":\"\",\"author\":\"\",\"rights\":\"\",\"xreference\":\"\"}',0,'*',''),(5,62,'Συχνές Ερωτήσεις','συχνές-ερωτήσεις','<p><br /><strong>1. Πώς κάνω εγγραφή νέου χρήστη αν είμαι διοργανωτής ή υποστηρικτής δράσεων;</strong></p>\r\n<p>Από το μενού πατάτε «Εγγραφή» και οδηγείστε στη φόρμα εγγραφής χρήστη. Ένας χρήστης μπορεί να είναι είτε διοργανωτής δράσεων είτε υποστηρικτής δράσεων ή και τα δύο. &nbsp;<br /> <br />Συμπληρώνετε όλα τα υποχρεωτικά πεδία τα οποία είναι σημειωμένα με αστερίσκο.</p>\r\n<p>Εάν εγγραφείτε ως υποστηρικτής είναι απαραίτητο να συμπληρώσετε στο κάτω μέρος της φόρμας, σύμφωνα με τα κατάλληλα πεδία, όσα πιστεύετε πως μπορείτε να προσφέρετε στις ομάδες που διοργανώνουν δράσεις.</p>\r\n<p>Εφόσον κατά την εγγραφή σας έχετε καταχωρήσει την ομάδα, τον οργανισμό ή την εταιρία σας ως διοργανωτή δράσεων, μπορείτε στη συνέχεια μέσα από το «Ο Λογαριασμός Μου» να κάνετε επεξεργασία των στοιχείων σας. Στην περίπτωση που έχετε εγγραφεί μόνο ως διοργανωτής μπορείτε να επεξεργαστείτε τα στοιχεία σας ώστε να γίνετε και / μόνο υποστηρικτής και αντίστροφα.</p>\r\n<p>* Όταν κάνετε εγγραφή, πρέπει η ομάδα, ο φορέας ή η εταιρεία σας περάσει από την έγκριση του δήμου Αθηναίων προκειμένου το προφίλ σας να δημοσιευθεί στην ιστοσελίδα. Όταν εγκριθεί από το δήμο (μέσα σε διάστημα 48 ωρών), θα ειδοποιηθείτε με σχετικό email.</p>\r\n<p><br /><strong>2. Πώς κάνω είσοδο χρήστη στην πλατφόρμα αν έχω ήδη κάνει εγγραφή ως διοργανωτής ή υποστηρικτής δράσεων; Τι κάνω αν έχω ξεχάσει τον κωδικό μου;</strong><br /><strong>(και για διοργανωτές και για υποστηρικτές δράσεων)</strong></p>\r\n<p>Από το μενού πατάτε «Είσοδος» και οδηγείστε στη φόρμα εισόδου. Συμπληρώνετε το email και τον κωδικό σας.</p>\r\n<p>Εάν ξεχάσατε τον κωδικό σας πατήστε τον αντίστοιχο σύνδεσμο κάτω από τη φόρμα.</p>\r\n<p><br /><strong>3. Πως καταχωρίζω μια νέα δράση;</strong> <br /><strong>Πως κλείνω τη στέγη του συνΑθηνά για δράση της ομάδας μου;</strong><br /><strong>Πως μπορώ να επεξεργαστώ μια ήδη καταχωρισμένη δράση μου; </strong><br /><strong>(για διοργανωτές δράσεων)</strong></p>\r\n<p>Για να καταχωρίσετε μία δράση, για να κλείσετε τη στέγη του συνΑθηνά για τη δράση σας ή για να επεξεργαστείτε μια καταχωρημένη δράση σας θα πρέπει πρώτα να έχετε κάνει «Είσοδο» από το menu.</p>\r\n<p>Στη συνέχεια, επιλέγοντας το «Καταχώριση Δράσης» από το μενού, συμπληρώνετε τα απαραίτητα πεδία στην αντίστοιχη φόρμα.</p>\r\n<p>Για την καταχώριση της δράσης σας είναι απαραίτητη η συμπλήρωση των στοιχείων τουλάχιστον μιας επιμέρους δράσης.&nbsp;<br /><br />Επιλέξτε το + στο τέλος του πεδίου «Επιμέρους Δράση 1» σε περίπτωση που η δράση σας:</p>\r\n<p>α. πραγματοποιείται σε περισσότερα από ένα σημεία στην Αθήνα</p>\r\n<p>β. είναι επαναλαμβανόμενη σε διαφορετικές ημερομηνίες ή/και ώρες</p>\r\n<p>γ. περιέχει περισσότερες από μία επιμέρους δράσεις σε περισσότερα από ένα σημεία στην Αθήνα (π.χ. Φεστιβάλ Δρόμου το οποίο περιλαμβάνει περισσότερες από μία δράσεις, σε διαφορετικές ώρες στο ίδιο ή σε διαφορετικό σημείο στο χάρτη όπως συναυλία, δράση καθαρισμού, δράση για παιδιά, κ.ο.κ.). Βεβαιωθείτε ότι έχετε καταχωρίσει όλα τα σημεία στο χάρτη καθώς και τις διαφορετικές ημέρες και ώρες των δράσεων σας.</p>\r\n<p>Εάν η δράση σας επιθυμείτε να πραγματοποιηθεί στη στέγη του συνΑθηνά, πατήστε την επιλογή «ΧΡΗΣΗ ΣΤΕΓΗΣ συνΑθηνά».</p>\r\n<p>* Όταν καταχωρίζεται μια δράση, πρέπει να περάσει από την έγκριση του δήμου προκειμένου να δημοσιευθεί στην ιστοσελίδα. Όταν εγκριθεί από το δήμο (μέσα σε διάστημα 48 ωρών) θα ειδοποιηθείτε με σχετικό email.</p>\r\n<p>Επεξεργασία της δράσης σας μπορείτε να κάνετε από το λογαριασμό σας, από την επιλογή «Επεξεργασία δράσεων».</p>\r\n<p><br /><strong>4. Πως κλείνω τη στέγη του συνΑθηνά για συνάντηση («κλειστό meeting») της ομάδας μου; (και για διοργανωτές και για υποστηρικτές δράσεων)</strong></p>\r\n<p>Επιλέξτε τη σελίδα «Στέγη» από το μενού και πατήστε την επιλογή «ΧΡΗΣΙΜΟΠΟΙΗΣΕ ΤΗ ΣΤΕΓΗ ΓΙΑ ΤΗΝ ΟΜΑΔΑ ΣΟΥ» στο κάτω μέρος του ημερολογίου.</p>\r\n<p>Για να κλείσετε τη στέγη, θα πρέπει πρώτα να έχετε κάνει «Είσοδο» από το menu.</p>\r\n<p>* Η περιγραφή της δραστηριότητας δεν είναι δημόσια, αλλά χρησιμοποιείται προς ενημέρωση του συνΑθηνά για τους σκοπούς της συνάντησης που αιτείστε.</p>\r\n<p><br /><strong>5. Πως ανεβάζω open call; (και για διοργανωτές και για υποστηρικτές δράσεων)</strong></p>\r\n<p>Επιλέξτε το «Καταχώρηση Open Call» από το μενού.<br />Συμπληρώστε τα πεδία της φόρμας.<br />Μπορείτε να επεξεργαστείτε τα στοιχεία του open call σας επιλέγοντας το&nbsp;«Επεξεργασία Open Call» από το&nbsp;«Ο Λογαριασμός μου».</p>\r\n<p>&nbsp;<br /><strong>6. Πώς μπορώ να χρησιμοποιήσω την ηλεκτρονική πλατφόρμα του συνΑθηνά αν είμαι υποστηρικτής δράσεων;</strong></p>\r\n<p>Εφόσον έχετε κάνει εγγραφή ως υποστηρικτής δράσεων, έχετε συμπληρώσει στην αντίστοιχη φόρμα τη μορφή της υποστήριξης που μπορείτε να προσφέρετε σε όσους διοργανώνουν δράσεις. Αντιστοιχίζοντας τη μορφή της υποστήριξής σας με τις ανάγκες των δράσεων που καταχωρίζονται στο σύστημα, το συνΑθηνά σας ενημερώνει με email:<br />α) για όλες τις σχεδιαζόμενες δράσεις που μπορούν να αξιοποιήσουν την προσφορά σας αμέσως μόλις πραγματοποιήσετε την εγγραφή σας.<br />β) για κάθε νέα δράση που μπορεί να αξιοποιήσει την προσφορά σας αμέσως μόλις αυτή δημοσιευτεί.<br />γ) για όλες τις σχεδιαζόμενες δράσεις που μπορούν να αξιοποιήσουν την προσφορά σας σε μηνιαία βάση.<br />Στα email αυτά περιέχονται τα στοιχεία επικοινωνίας των εκπροσώπων των ομάδων πολιτών με τους οποίους θα μπορείτε να έρθετε απευθείας σε επαφή, εφόσον το επιθυμείτε.</p>\r\n<p><br /><strong>7. Σε τι μου χρησιμεύει η ηλεκτρονική πλατφόρμα του συνΑθηνά αν είμαι διοργανωτής δράσεων στην Αθήνα; Τι δυνατότητες διασύνδεσης μου δίνει;</strong></p>\r\n<p>Η ηλεκτρονική πλατφόρμα του συνΑθηνά αποτελεί εργαλείο προβολής και διάδοσης των δράσεων των ενεργών πολιτών της Αθήνας με αποδέκτες τα πιο ζωντανά κύτταρα Κοινωνίας των Πολιτών της Αθήνας, την δημοτική αρχή, τους υποστηρικτές δράσεων καθώς και το ευρύτερο κοινό. <br />Μέσα από την ηλεκτρονική πλατφόρμα του συνΑθηνά οι διοργανωτές δράσεων μπορούν επίσης να κλείνουν τη στέγη του συνΑθηνά για τις δράσεις τους και για τις συναντήσεις της ομάδας τους.<br />Μέσω των ανοιχτών προσκλήσεων (open calls) οι διοργανωτές δράσεων έχουν τη δυνατότητα να προσκαλούν κάθε ενδιαφερόμενο την ενίσχυση των δράσεών τους. <br />Τέλος, μέσω του συνΑθηνά οι ομάδες πολιτών που διοργανώνουν δράσεις μπορούν:<br />α) να συνεργάζονται με άλλες ομάδες πολιτών<br />β) να συνδέονται με ένα δίκτυο υποστηρικτών που μπορούν να ενισχύσουν τη δράση τους μέσω: <br />1. χρηματικής χορηγίας<br />2. προσφοράς σε τεχνογνωσία<br />3. προσφοράς σε είδος<br />4. εθελοντικής εργασίας<br />γ) να απευθύνουν τα αιτήματά τους προς τις αρμόδιες υπηρεσίες του δήμου Αθηναίων ηλεκτρονικά<br />Σε κάθε περίπτωση προτείνεται η όσο το δυνατό πιο έγκαιρη ανάρτηση των στοιχείων των δράσεών σας, ώστε να είναι πιο αποτελεσματική η προώθηση των αιτημάτων σας για υποστήριξη.</p>\r\n<p><strong>8. Πώς μπορώ να χρησιμοποιήσω την ηλεκτρονική πλατφόρμα του συνΑθηνά αν ανήκω στο ανθρώπινο δυναμικό του δήμου Αθηναίων;</strong></p>\r\n<p>Η πλατφόρμα του συνΑθηνά αποτελεί πολύτιμο εργαλείο γνώσης των προτεραιοτήτων των ενεργών πολιτών της Αθήνας. Μέσα από τις δράσεις τους οι πολίτες υποδεικνύουν λύσεις για μια πιο όμορφη, λειτουργική και βιώσιμη πόλη. <br />Οι επιμέρους αντιδημαρχίες, διευθύνσεις και υπηρεσίες μπορούν να αξιοποιούν τη δυνατότητα δημοσίευσης των ανοιχτών προσκλήσεων (open calls) για να προσκαλούν σε συμμετοχή τις δυνάμεις της Κοινωνίας των Πολιτών οι οποίες μπορούν να συνεργαστούν μαζί τους συμμετέχοντας ενεργά ή προτείνοντας λύσεις.</p>\r\n<p><strong>9. Τι είναι οι θεματικές κατηγορίες που βρίσκω στην ηλεκτρονική πλατφόρμα του συνΑθηνά;</strong></p>\r\n<p>Οι 10 θεματικές κατηγορίες του συνΑθηνά αποτυπώνουν τους βασικούς τομείς δραστηριοποίησης των ενεργών πολιτών της Αθήνας, με βάση τα στατιστικά στοιχεία που έχει συγκεντρώσει το συνΑθηνά.</p>\r\n<p><strong>10. Τι είναι τα best practices;</strong></p>\r\n<p>Best practices (βέλτιστες πρακτικές) είναι οι δράσεις που αξιολογούνται από την ομάδα του συνΑθηνά ως δράσεις υψηλής επίδρασης. Για την ανάδειξη των βέλτιστων πρακτικών η ομάδα του συνΑθηνά αξιολογεί τις δράσεις με τα παρακάτω κριτήρια: <br />1. Μέγεθος Προβολής (αριθμός ατόμων που οργάνωσαν και συμμετείχαν στη δράση ή ωφελήθηκαν από αυτήν, προβολή από τα MME)<br />2. Συνδεσιμότητα (συνεργασίες με άλλες ομάδες, μεμονωμένα άτομα, υπηρεσίες του Δήμου, υποστηρικτές και εμπειρογνώμονες) <br />3. Εντοπιότητα (αντιστοίχιση της δράσης με την υπαρκτή ανάγκη μιας περιοχής ή γειτονιάς)<br />4. Συχνότητα (βαθμός επαναληψιμότητας της δράσης)<br />5. Πρωτοτυπία (δυνατότητα μιας δράσης να φέρει κάτι νέο στην πόλη)<br />6. Δυνατότητα μεταβίβασης (δυνατότητα μιας δράσης να πραγματοποιηθεί και αλλού ή/και από άλλους).</p>\r\n<p><strong>11. Τι είναι τα toolkits;</strong></p>\r\n<p>Toolkits είναι τα εγχειρίδια που αποτυπώνουν τη μεθοδολογία του τρόπου υλοποίησης δράσεων οι οποίες έχουν χαρακτηριστεί αποτελεσματικές ως προς τον τρόπο που ενισχύουν την αλληλεπίδραση ανάμεσα στην Κοινωνία των Πολιτών και την τοπική αυτοδιοίκηση, οδηγώντας τελικά στην αναβάθμιση της δημοτικής αρχής. Στόχος τους είναι να είναι ανοιχτά και μεταβιβάσιμα, ώστε να μπορούν να υιοθετούνται από όλους όσοι ενδιαφέρονται να εφαρμόσουν αυτές τις πρακτικές.</p>','',1,2,'2016-03-28 14:37:52',233,'','2018-05-22 14:28:16',233,0,'0000-00-00 00:00:00','2016-03-28 14:37:52','0000-00-00 00:00:00','{\"image_intro\":\"\",\"float_intro\":\"\",\"image_intro_alt\":\"\",\"image_intro_caption\":\"\",\"image_fulltext\":\"\",\"float_fulltext\":\"\",\"image_fulltext_alt\":\"\",\"image_fulltext_caption\":\"\"}','{\"urla\":false,\"urlatext\":\"\",\"targeta\":\"\",\"urlb\":false,\"urlbtext\":\"\",\"targetb\":\"\",\"urlc\":false,\"urlctext\":\"\",\"targetc\":\"\"}','{\"opencall_date\":\"\",\"news_image\":\"center\",\"news_subtitle\":\"\",\"show_title\":\"\",\"link_titles\":\"\",\"show_tags\":\"\",\"show_intro\":\"\",\"info_block_position\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_vote\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',6,99,'','',1,5658,'{\"robots\":\"\",\"author\":\"\",\"rights\":\"\",\"xreference\":\"\"}',0,'*',''),(6,64,'Όροι χρήσης','όροι-χρήσης','<p>ΟΡΟΙ ΧΡΗΣΗΣ ΔΙΑΔΙΚΤΥΑΚΟΥ ΤΟΠΟΥ “συνΑθηνά”</p>\r\n<p><strong>Η πλατφόρμα</strong><br />Η λειτουργία του παρόντος διαδικτυακού τόπου υποστηρίζεται από τον Δήμο Αθηναίων (στο εξής: ο “Φορέας”) και έχει σκοπό, αφενός να αποτελέσει πλατφόρμα για την φιλοξενία και προβολή πληροφοριών σχετικά με τις συλλογικές δράσεις που οργανώνουν οι ομάδες πολιτών της Αθήνας και αφετέρου να παράσχει εν γένει υποστήριξη των δράσεων αυτών μέσω εργαλείων σύνδεσής τους με άλλες ομάδες, φορείς και τις υπηρεσίες του Φορέα.<br />Η λειτουργία και η ευθύνη του διαδικτυακού τόπου διέπεται αποκλειστικά από την εφαρμογή των παρόντων όρων χρήσης. Οι χρήστες του διαδικτυακού τόπου αποδέχονται την δεσμευτικότητα των παρόντων όρων χρήσης, τόσο ως προς τα δικαιώματα και τις υποχρεώσεις του Φορέα, όσο και ως προς τα δικαιώματα και τις υποχρεώσεις που αναγνωρίζονται για τους ίδιους, αλλά και για τρίτους. Οι παρόντες όροι είναι απολύτως συμβατοί με το ισχύον ευρωπαϊκό και ελληνικό δίκαιο, καθώς και με τα συναλλακτικά ήθη του Διαδικτύου (lex internetica) και η μη συμμόρφωση των χρηστών της ιστοσελίδας ή και τρίτων προσώπων προς αυτούς συνεπάγεται την άρση πάσης ευθύνης του Φορέα σε σχέση με τυχόν θιγόμενα φυσικά ή νομικά πρόσωπα, σύμφωνα και με τις ειδικότερα ισχύουσες διατάξεις. Παράλληλα, οι χρήστες του διαδικτυακού τόπου αναγνωρίζουν το δικαίωμα του Φορέα να μεταβάλλει διατάξεις των παρόντων όρων, στο μέτρο που δεν αφορούν δεσμευτικές νομικά υποχρεώσεις του και χωρίς να επηρεάζονται τετελεσμένες καταστάσεις. Οι χρήστες που χρησιμοποιούν τις υπηρεσίες του διαδικτυακού τόπου αλλά και που απλώς τον επισκέπτονται αναγνωρίζουν ότι διάβασαν τους παρόντες όρους, συμφωνούν με αυτούς και αναλαμβάνουν την υποχρέωση τήρησής τους.<br />Για τους σκοπούς εφαρμογής των παρόντων όρων χρήσης νοούνται ως:<br />α) Ομάδες πολιτών: κάθε ένωση κατοίκων του Δήμου Αθηναίων - με ή χωρίς νομική προσωπικότητα - που δραστηριοποιείται έμπρακτα για την βελτίωση της ποιότητας ζωής στην πόλη.<br />β) Δράση ομάδας πολιτών: προγραμματισμένη συλλογική ενέργεια που διοργανώνεται από ομάδα πολιτών σε συγκεκριμένα καθοριζόμενο χρόνο και τόπο ελεύθερα προσβάσιμη σε όλους, αποσκοπώντας στην βελτίωση της ποιότητας ζωής στην πόλη, με σεβασμό της κείμενης νομοθεσίας και χωρίς διακρίσεις λόγω ηλικίας, φύλου, εθνικής φυλετικής καταγωγής, θρησκευτικών ή άλλων πεποιθήσεων, πολιτικών φρονημάτων, υγείας, σεξουαλικού προσανατολισμού, ταυτότητας φύλου.</p>\r\n<p><strong>Παροχή Υπηρεσιών Κοινωνίας της Πληροφορίας.</strong><br />Μέσω του εν λόγω διαδικτυακού τόπου, ο Φορέας παρέχει “Υπηρεσίες Κοινωνίας της Πληροφορίας”, κατά τον ορισμό που προβλέπεται για τον όρο αυτόν από το π.δ. 131/2003 (“Προσαρμογή στην Οδηγία 2000/31 του Ευρωπαϊκού Κοινοβουλίου και του Συμβουλίου σχετικά με ορισμένες νομικές πτυχές των υπηρεσιών κοινωνίας της πληροφορίας, ιδίως του ηλεκτρονικού εμπορίου, στην εσωτερική αγορά (Οδηγία για το ηλεκτρονικό εμπόριο)”, ΦΕΚ 116/Α/16.5.2003), επιτρέποντας την ελεύθερη κυκλοφορία των εν λόγω υπηρεσιών στο έδαφος της Ευρωπαϊκής Ένωσης όπως επιβάλλει ο νόμος. «Αποδέκτες των υπηρεσιών» αυτών είναι κάθε φυσικό ή νομικό πρόσωπο το οποίο τις χρησιμοποιεί, ιδίως για να αναζητήσει πληροφορίες ή για να προσφέρει πρόσβαση σε αυτές. Συγκεκριμένα παρέχονται στους αποδέκτες υπηρεσίες φιλοξενίας και απλής μετάδοσης συνισταμένων στην αποθήκευση και τη μετάδοση πληροφοριών παρεχομένων από τους αποδέκτες της υπηρεσίας σχετικά με την καλλιτεχνική δραστηριότητά τους.<br />Σύμφωνα με το άρθρο 11 (“Απλή μετάδοση”) του π.δ. 31/2003, σε περίπτωση παροχής μιας υπηρεσίας της κοινωνίας της πληροφορίας συνισταμένης στη μετάδοση πληροφοριών που παρέχει ο αποδέκτης της υπηρεσίας σε ένα δίκτυο επικοινωνιών ή στην παροχή πρόσβασης στο δίκτυο επικοινωνιών, δεν υφίσταται ευθύνη του Φορέα παροχής υπηρεσιών όσον αφορά τις μεταδιδόμενες πληροφορίες, υπό τους όρους ότι ο Φορέας παροχής υπηρεσιών:<br />α) δεν αποτελεί την αφετηρία της μετάδοσης των πληροφοριών,<br />β) δεν επιλέγει τον αποδέκτη της μετάδοσης και<br />γ) δεν επιλέγει και δεν τροποποιεί τις μεταδιδόμενες πληροφορίες.<br />Οι δραστηριότητες μετάδοσης και παροχής πρόσβασης που αναφέρονται στην παράγραφο 1 περιλαμβάνουν την αυτόματη, ενδιάμεση και προσωρινή αποθήκευση των μεταδιδομένων πληροφοριών, στο βαθμό που η αποθήκευση εξυπηρετεί αποκλειστικά την πραγματοποίηση της μετάδοσης στο δίκτυο επικοινωνιών και η διάρκειά της δεν υπερβαίνει το χρόνο που είναι ευλόγως απαραίτητος για τη μετάδοση.<br />Δεν θίγεται δε η δυνατότητα να επιβληθεί δικαστικά ή διοικητικά στον φορέα παροχής υπηρεσιών η παύση ή η πρόληψη της παράβασης.<br />Επιπλέον, σύμφωνα με το άρθρο 13 (“Φιλοξενία”) του ιδίου π.δ. ορίζεται ότι σε περίπτωση παροχής µιας υπηρεσίας της κοινωνίας της πληροφορίας συνισταµένης στην αποθήκευση πληροφοριών παρεχοµένων από ένα αποδέκτη υπηρεσίας, δεν υφίσταται ευθύνη του φορέα παροχής της υπηρεσίας για τις πληροφορίες που αποθηκεύονται µετά από αίτηση αποδέκτη της υπηρεσίας, υπό τους όρους ότι:<br />(α) ο Φορέας παροχής της υπηρεσίας δεν γνωρίζει πραγµατικά ότι πρόκειται για παράνοµη δραστηριότητα ή πληροφορία και ότι, σε ό,τι αφορά αξιώσεις αποζηµιώσεως, δεν γνωρίζει τα γεγονότα ή τις περιστάσεις από τις οποίες προκύπτει η παράνοµη δραστηριότητα ή πληροφορία, ή<br />(β) ο Φορέας παροχής της υπηρεσίας, µόλις αντιληφθεί τα προαναφερθέντα, αποσύρει ταχέως τις πληροφορίες ή καθιστά την πρόσβαση σε αυτές αδύνατη.<br />Τέλος, το άρθρο 14 (“Απουσία γενικής υποχρέωσης ελέγχου”) του π.δ. 131/2003 ανακεφαλαιώνει ορίζοντας ότι οι φορείς παροχής υπηρεσιών δεν έχουν, για την παροχή υπηρεσιών που αναφέρονται στα άρθρα 10, 11 και 12 του παρόντος, γενική υποχρέωση ελέγχου των πληροφοριών που µεταδίδουν ή αποθηκεύουν, ούτε γενική υποχρέωση δραστήριας αναζήτησης γεγονότων ή περιστάσεων που δείχνουν ότι πρόκειται για παράνοµες δραστηριότητες.<br />Ως εκ τούτου, ο Φορέας διαχείρισης του διαδικτυακού τόπου δεν φέρει ευθύνη για το περιεχόμενο των πληροφοριών που είναι αποθηκευμένες στους αντίστοιχους εξυπηρετητές (servers) και μεταδίδονται στην ιστοσελίδα, μέσω της οποίας είναι προσβάσιμη η υπηρεσία του στο κοινό, εκτός εάν λάβει μια συγκεκριμένη και ορισμένη ειδοποίηση για παράνομο περιεχόμενο, κατά τους όρους που ειδικότερα προβλέπονται παρακάτω, οπότε στην περίπτωση αυτή είναι υποχρεωμένος να αποσύρει το παράνομο περιεχόμενο. Κάθε χρήστης ο οποίος διαπιστώνει την ανάρτηση παρανόμου περιεχομένου στον εν λόγω διαδικτυακό τόπο οφείλει να επικοινωνεί με τους διαχειριστές αποστέλλοντας μήνυμα ηλεκτρονικού ταχυδρομείου στη διεύθυνση synathina@cityofathens.gr<br />Στο πλαίσιο της παροχής των παραπάνω υπηρεσιών, ο Φορέας και οι Διαχειριστές (moderators) που ο ίδιος θα καθορίσει με σχετική απόφαση του υπεύθυνου συντονισμού ομάδων πολιτών του Δήμου Αθηναίων, έχουν την δυνατότητα να αποστέλλουν μηνύματα ηλεκτρονικού ταχυδρομείου σε χρήστες στη διεύθυνση την οποία έχουν δηλώσει κατά την εγγραφή τους στις υπηρεσίες του διαδικτυακού τόπου.<br />Για την χρήση των υπηρεσιών απαιτείται η λειτουργία προγραμμάτων ηλεκτρονικού υπολογιστή δηλαδή λογισμικού. Ο Φορέας δεν έχει καμία ευθύνη για τυχόν προβλήματα που μπορεί να προκύψουν από την λειτουργία του εκάστοτε λογισμικού που χρησιμοποιεί ο χρήστης για την πρόσβαση στις παρεχόμενες υπηρεσίες.<br />Ευθύνη για τα σχόλια<br />Ο Φορέας παρέχει τη δυνατότητα στους χρήστες να αναρτούν σχόλια, για τα οποία είναι απολύτως υπεύθυνοι οι ίδιοι. Ωστόσο, ο Φορέας διατηρεί το δικαίωμα της διαγραφής των σχολίων σε περίπτωση που οι σχολιαστές δεν τηρούν τους παρακάτω όρους χρήσης.<br />Όταν χρησιμοποιείται χώρος του διαδικτυακού τόπου για τη μετάδοση ειδήσεων, δηλαδή πληροφοριών (“περιεχόμενο”) για πραγματικά περιστατικά που αφορούν ένα ευρύτερο σύνολο αναγνωστών, πρέπει να τηρούνται οι παρακάτω αρχές:<br />α) η δημοσιοποίηση πρέπει να αφορά όλη την αλήθεια, χωρίς διαστρέβλωση, αλλοίωση ή παρουσίαση επιλεκτικών στοιχείων από την μεταδιδόμενη είδηση,</p>\r\n<p>β) η ακρίβεια της είδησης πρέπει να ελέγχεται πριν την μετάδοση, με κάθε πρόσφορο μέσο, όπως η διασταύρωση των πληροφοριών με την συλλογή των στοιχείων από τουλάχιστον δύο διαφορετικές, ανεξάρτητες μεταξύ τους, πηγές,</p>\r\n<p>γ) όταν η είδηση ενδέχεται να έχει αρνητικές επιπτώσεις στην υπόληψη ενός προσώπου, τη μετάδοσή της θα πρέπει να συνοδεύει πλήρης παράθεση των αποδεικτικών στοιχείων που θεμελιώνουν την ακρίβειά της, υπό την προϋπόθεση ότι έχουν συλλεχθεί με θεμιτά και νόμιμα μέσα – διαφορετικά η δημοσιοποίηση της είδησης πρέπει να αποφεύγεται,</p>\r\n<p>δ) η είδηση (πληροφορία για πραγματικό περιστατικό) πρέπει να διακρίνεται με σαφήνεια από το σχόλιο του ιστολόγου (ερμηνείες, εκτιμήσεις, κριτικές, χαρακτηρισμοί),</p>\r\n<p>ε) ο τίτλος του κειμένου πρέπει να αντιστοιχεί με το περιεχόμενο του (αρχή της σχετικότητας τίτλου – είδησης)</p>\r\n<p>στ) η χρήση φωτογραφιών, εικόνων, γραφικών απεικονίσεων ή άλλων παραστάσεων να γίνεται με ακρίβεια, αναφορά στην πηγή –εφόσον τα δεδομένα δεν έχουν χορηγηθεί υπό τον όρο της εμπιστευτικότητας- και μνεία στις επιστημονικές μεθόδους με τις οποίες εκπονήθηκαν.</p>\r\n<p>ζ) η είδηση πρέπει να μεταδίδεται ανεπηρέαστα από προσωπικές πολιτικές, κοινωνικές, θρησκευτικές, φυλετικές, φιλοσοφικές και πολιτισμικές απόψεις ή πεποιθήσεις του χρήστη – αυτές τις εκφράζει στο πλαίσιο του σχολιασμού ή της κριτικής του,</p>\r\n<p>η) εφόσον υπάρχουν περισσότερες εκδοχές ή απόψεις για ένα πραγματικό περιστατικό, πρέπει να εκτίθενται όλες ή έστω οι πιο αντιπροσωπευτικές από αυτές, για την πληρότητα της κάλυψης.</p>\r\n<p>Όταν χρησιμοποιείται χώρος του διαδικτυακού τόπου για σχολιασμό και κριτική γεγονότων, προϊόντων οι χρήστες και οι σχολιαστές θα πρέπει να σέβονται:</p>\r\n<p>α) το τεκμήριο της αθωότητας, δηλαδή την μη ενοχοποίηση πριν την αμετάκλητη καταδίκη κάποιου για ένα αδίκημα που τιμωρείται από το νόμο,</p>\r\n<p>β) τους ανήλικους, τους ηλικιωμένους, τα πρόσωπα με ειδικές ανάγκες και με σοβαρά προβλήματα υγείας, εφόσον αυτές οι ιδιότητες είναι γνωστές στο σχολιαστή,</p>\r\n<p>γ) τα άτομα που βρίσκονται σε κατάσταση πένθους, ψυχικού κλονισμού και οδύνης.</p>\r\n<p>2.8.3. Η ελευθερία της έκφρασης επιτρέπει την οξεία κριτική και την ειρωνεία, όχι όμως και την εξύβριση, την δυσφήμηση, την συκοφαντική δυσφήμηση και την προσβολή της προσωπικότητας του άλλου. Η χρήση έργων λόγου και τέχνης τρίτων προσώπων (“περιεχόμενο”) επιτρέπεται εφόσον γίνεται για λόγους ενημέρωσης, τεκμηρίωσης ή σχολιασμού επί των ίδιων των έργων. Η χρήση τέτοιων έργων (“περιεχομένου”) πρέπει πάντα να γίνεται με απόλυτο σεβασμό των όρων που προβλέπονται σε τυχόν άδειες ανοικτού κώδικα που συνοδεύουν το έργο και σε κάθε περίπτωση, η χρήση πρέπει να :</p>\r\n<p>α) συνοδεύεται από μνεία στον δημιουργό και τον παραγωγό του έργου και αν αυτοί δεν είναι γνωστοί με link στην πηγή από όπου ο ιστολόγος εντόπισε το έργο,</p>\r\n<p>β) να μην παρακωλύει την κανονική εμπορική ή άλλη εκμετάλλευση του έργου εκ μέρους του δημιουργού ή του παραγωγού,</p>\r\n<p>γ) να μην αλλοιώνει την ακεραιότητα του έργου, δημιουργώντας εσφαλμένη εντύπωση για το περιεχόμενο ή την ποιότητά του.</p>\r\n<p>2.8.4. Ψευδώνυμα, domain names, σήματα, τίτλοι, επωνυμίες και διακριτικά γνωρίσματα</p>\r\n<p>Οι χρήστες δεν πρέπει να χρησιμοποιούν τα ψευδώνυμα, domain names, σήματα, τίτλους, επωνυμίες και διακριτικά γνωρίσματα τρίτων με τρόπο που να οδηγεί σε παραπλάνηση των αναγνωστών ή σε εκμετάλλευση της φήμης αυτών των γνωρισμάτων για την άγρα αναγνωστών.</p>\r\n<p>2.8.5. Ανωνυμία<br />Η ανωνυμία είναι δικαίωμα των χρηστών του διαδικτύου το οποίο διασφαλίζει περιβάλλον προωθημένης ελευθερίας έκφρασης, αλλά, σε κάθε περίπτωση, η χρήση της για την αποποίηση ευθύνης για παράνομες πράξεις είναι καταχρηστική. Η άρση της ανωνυμίας, ωστόσο, επιτρέπεται μόνο ύστερα από επέμβαση αρμόδιων κρατικών αρχών. Η ανωνυμία πρέπει να είναι απολύτως σεβαστή ως επιλογή ενός γράφοντος και δεν πρέπει να αποτελεί αντικείμενο αρνητικής κριτικής από τους επωνύμως συμμετέχοντες, σε καμία περίπτωση. H αποκάλυψη πληροφοριών από τις οποίες μπορεί να προσδιοριστεί η ταυτότητα ενός προσώπου (π.χ. επάγγελμα, διεύθυνση, χαρακτηριστικά, οικογενειακή κατάσταση, παλαιότερο ή παράλληλο ψευδώνυμο, θρησκευτικές ή πολιτικές πεποιθήσεις, σεξουαλικός προσανατολισμός, καταγωγή κλπ) αποτελεί παραβίαση της επιλογής του για ανωνυμία και είναι εξίσου κατακριτέα με την αποκάλυψη του ονόματός του.</p>\r\n<p>2.8.6. Απόρρητο της επικοινωνίας<br />Η πλοήγηση στο Διαδίκτυο, η αποστολή και λήψη ηλεκτρονικού ταχυδρομείου και η ανάρτηση σχολίων και κειμένων, εφόσον γίνεται: α) με πρόθεση μυστικότητας και β) έχουν ληφθεί μέτρα για τη διασφάλιση της μυστικότητας, καλύπτονται από το απόρρητο της επικοινωνίας. Τα δεδομένα που ανταλλάσσονται κατά τη διάρκεια μιας τέτοιας επικοινωνίας καλύπτονται επίσης από το απόρρητο και η διαχείρισή τους επιτρέπεται σύμφωνα με τους όρους χρήσης προσωπικών δεδομένων.</p>\r\n<p>Ευθύνη για τους υπερσυνδέσμους (hypertext links).<br />Οι χρήστες μπορούν να τοποθετούν σε αυτά υπερσυνδέσμους προς άλλες ιστοσελίδες στις οποίες περιέρχεται ο χρήστης εφόσον τις επιλέξει, απομακρυνόμενος από τον παρόντα διαδικτυακό τόπο. H τοποθέτηση τέτοιων συνδέσμων που παραπέμπουν σε άλλες ιστοσελίδες, όπου ενδεχομένως είναι τοποθετημένα προστατευόμενα μουσικά ή οπτικοακουστικά έργα, σύμφωνα με την τρέχουσα διεθνή νομολογία, δεν αποτελεί αναπαραγωγή, ούτε παρουσίαση του έργο στο κοινό, ούτε καθίσταται με αυτόν τον τρόπο το έργο προσιτό στο κοινό. Συνεπώς δεν αποτελεί από μόνη της πράξη που διέπεται από τις διατάξεις του Ν.2121/1993, καθώς εμπίπτει στο πεδίο εφαρμογής της ελευθερίας της έκφρασης, όπως αυτή κατοχυρώνεται από συνταγματικές διατάξεις και από το ευρωπαϊκό και διεθνές δίκαιο. Επομένως ο υπερσύνδεσμος αποτελεί αποκλειστικά και μόνο μία πληροφορία, η οποία παρέχεται, μεταξύ άλλων, από τους δημιουργούς του κάθε προφίλ και ουδεμία ευθύνη του Φορέα υπάρχει για το περιεχόμενο των τρίτων παραπεμπόμενων ιστοσελίδων.<br />3. Τα δικαιώματα των χρηστών<br />3.1. Οι χρήστες έχουν άδεια χρήσης των παρεχόμενων υπηρεσιών κοινωνίας της πληροφορίας, απολαμβάνοντας τις παρεχόμενες υπηρεσίες αποκλειστικά και μόνον για: α) σκοπούς προώθησης των μη κερδοσκοπικών δράσεων των ομάδων πολιτών και β) για ενημέρωσή τους σχετικά με τις εν λόγω δράσεις. Οι χρήστες που εκπροσωπούν ομάδες πολιτών έχουν δικαίωμα να αποκτήσουν λογαριασμό ομάδας πολιτών ύστερα από την καταχώριση μίας (1) τουλάχιστον “δράσης ομάδας πολιτών”, κατά τον ορισμό του άρθρου 1 των παρόντων όρων χρήσης.<br />3.2. Οι χρήστες έχουν δικαίωμα να αναρτούν περιεχόμενο μόνον εφόσον δεν παραβιάζονται δικαιώματα πνευματικής ιδιοκτησίας τρίτων κι εφόσον το περιεχόμενο δεν είναι προσβλητικό, συκοφαντικό, δυσφημιστικό ή πορνογραφικό. Δεν έχουν δικαίωμα να αναρτούν περιεχόμενο εφόσον δεν διαθέτουν εξουσία ανάρτησής του στο Διαδίκτυο και σε τέτοιες περιπτώσεις φέρουν ακέραιη την ευθύνη, σε περίπτωση που ο θιγόμενος κινήσει διαδικασίες εναντίον τους, με την επιφύλαξη των υποχρεώσεων του Φορέα για συμμόρφωση σε περίπτωση που υποβληθεί καταγγελία, σύμφωνα με τους παρόντες όρους χρήσης. Η ενεργός συμμετοχή χρήστη με την ανάρτηση υλικού προϋποθέτει απόλυτο σεβασμό του παρόντος κανονισμού λειτουργίας και ειδικώς του παρόντος όρου.<br />3.3. Ο Φορέας διατηρεί το δικαίωμα να χρησιμοποιεί το περιεχόμενο που θα ανεβάζουν οι χρήστες ελεύθερα και χωρίς άλλη διατύπωση, για σκοπούς προώθησης του διαδικτυακού τόπου.<br />3.4. Οι χρήστες έχουν δικαίωμα προστασίας του απορρήτου των επικοινωνιών τους, όπως προβλέπεται από το άρθρο 19 του Συντάγματος και την σχετική εθνική και ευρωπαϊκή νομοθεσία (Ν.2225/1994 κλπ).<br />3.5. Οι χρήστες έχουν τα δικαιώματα προστασίας προσωπικών δεδομένων που προβλέπονται από το άρθρο 7 του παρόντος κανονισμού λειτουργίας.<br />4. Οι υποχρεώσεις των χρηστών<br />4.1. Η υπηρεσία της απλής πλοήγησης στον διαδικτυακό τόπο προσφέρεται σε κάθε χρήστη, τηρουμένων των παρόντων όρων χρήσης.<br />4.2. Η υπηρεσία καταχώρησης “δράσης ομάδας πολιτών”, κατά την ανωτέρω έννοια, παρέχεται μόνο στους λογαριασμούς των ομάδων πολιτών, οι οποίες οφείλουν κατά την υποβολή αίτησης καταχώρησης να δηλώσουν ότι δεσμεύονται να τηρούν τους παρόντες όρους χρήσης.<br />4.3. Η εγγραφή των ομάδων πολιτών γίνεται με συμπλήρωση των στοιχείων τους στα σχετικά πεδία του διαδικτυακού τόπου. Στη συνέχεια πραγματοποιείται αποστολή ενός κωδικού πρόσβασης στην ηλεκτρονική διεύθυνση που έχουν δηλώσει. Οι ομάδες πολιτών υποχρεούνται να γνωστοποιούν άμεσα στο Φορέα οποιαδήποτε χρήση του κωδικού τους από τρίτο πρόσωπο χωρίς άδεια του δικαιούχου ή κάθε άλλη παραβίαση του λογαριασμού τους. Παράλληλα οφείλουν να διασφαλίζουν την έξοδό τους από το λογαριασμό τους στο τέλος κάθε χρήσης του διαδικτυακού τόπου.<br />4.4. Οι ομάδες πολιτών είναι απολύτως υπεύθυνες για την ακρίβεια των στοιχείων που παραθέτουν ως προς τις δράσεις που αναρτούν, καθώς και για την έκβαση των δράσεων αυτών. Ο Φορέας παρέχει μόνο την φιλοξενία των στοιχείων που αναρτούν οι ομάδες πολιτών, χωρίς να φέρει ευθύνη για την ακρίβεια των στοιχείων ή για την ομαλή ή αναμενόμενη ή επιτυχή έκβαση των δράσεων.<br />5. Διαδικασία αναφοράς για κακή χρήση του διαδικτυακού τόπου<br />5.1. Κάθε χρήστης του διαδικτυακού τόπου μπορεί να αναφέρει τυχόν προβλήματα σχετικά με την κακή χρήση του διαδικτυακού τόπου, όπως λ.χ. ανακριβή στοιχεία για δράσεις, παράβαση των παρόντων όρων χρήσης κλπ με μήνυμα ηλεκτρονικού ταχυδρομείου στη διεύθυνση synathina@cityofathens.gr. Στην έννοια της κακής χρήσης του διαδικτυακού τόπου δεν περιλαμβάνονται τυχόν προβλήματα που προέκυψαν κατά τη διοργάνωση κάποιας δράσης ή άλλες ενστάσεις για την ίδια την λειτουργία της εκάστοτε ομάδας πολιτών.<br />5.2. Ο Φορέας δεν διαθέτει προληπτική ευθύνη για το περιεχόμενο του διαδικτυακού τόπου, ούτε υποχρέωση ενεργητικής αναζήτησης τυχόν ανακριβών πληροφοριών ή άλλων περιπτώσεων κακής χρήσης του διαδικτυακού τόπου. Εφόσον όμως λάβει μια αναφορά για κακή χρήση του διαδικτυακού τόπου, έχει την υποχρέωση να εξετάσει το πρόβλημα και, κατά περίπτωση, να αναλάβει μέτρα για την αποκατάστασή του, εφόσον υπάρχει η σχετική πρακτική δυνατότητα.<br />5.3. Η αναφορά για κακή χρήση του διαδικτυακού τόπου πρέπει να περιέχει σαφή στοιχεία για το πρόβλημα και ιδίως να υποδεικνύει την ακριβή ιστοθέση που αυτό παρουσιάζεται. Ανώνυμες αναφορές δεν λαμβάνονται υπόψη.<br />5.4. Σε περίπτωση που ο Φορέας διαπιστώσει σημαντικό αριθμό βάσιμων αναφορών εναντίον χρήστη του διαδικτυακού τόπου, διατηρεί το δικαίωμα να διαγράψει τον λογαριασμό του χρήστη, αφού πρώτα τον καλέσει να εκθέσει τις απόψεις του σχετικά με τα καταγγελλόμενα.<br />5.5. Η τήρηση της παραπάνω διαδικασίας αποτελεί δεσμευτικό συμβατικό όρο πριν από κάθε περαιτέρω ενέργεια ενώπιον δημόσιας αρχής ή δικαστηρίου και η προδικασία αυτή αφορά τόσο τους απλούς χρήστες όσο και τους χρήστες – εκπροσώπους ομάδων πολιτών, οι οποίοι εισερχόμενοι στην ιστοσελίδα αποδέχονται τη δεσμευτικότητά της.<br />Τα δικαιώματα του Φορέα<br />Δικαιώματα επί διακριτικών τίτλων, ονομάτων χώρου και επωνυμιών<br />Οι διακριτικοί τίτλοι, τα σήματα και τα ονόματα χώρου αποτελούν περιουσιακά αγαθά του Φορέα, ο οποίος επιφυλάσσεται να κινήσει αστικές, διοικητικές και ποινικές νομικές ενέργειες εναντίον κάθε παραβάτη των σχετικών όρων που αφορούν την χρήση επί των ανωτέρω περιουσιακών αγαθών του.<br />Δικαιώματα επί της βάσης δεδομένων<br />Το σύνολο των γραφικών διασχηματισμών, προγραμμάτων ηλεκτρονικού υπολογιστή (εκτός από λογισμικό τρίτων φορέων), πηγαίου κώδικα, κειμένων, εικονιδίων, καθώς και η διάταξη του συνόλου της ιστοσελίδας αποτελεί περιουσιακό αγαθό του Φορέα. Ως προς τη βάση δεδομένων του διαδικτυακού τόπου, ο Φορέας αποτελεί “κατασκευαστή βάσης δεδομένων” με τα δικαιώματα ειδικής φύσης του άρθρου 45Α του Ν.2121/1993 και του σχετικού ευρωπαϊκού κοινοτικού θεσμικού πλαισίου. Στο πλαίσιο αυτό, απαγορεύεται η εξαγωγή ή/και επαναχρησιμοποίηση του συνόλου ή ουσιώδους μέρους του περιεχομένου της βάσης δεδομένων, ανεξάρτητα από την προστασία της βάσης σύμφωνα με τις γενικές διατάξεις για την πνευματική ιδιοκτησία. Επιτρέπεται ωστόσο η περαιτέρω χρήση των πληροφοριών (περιεχομένου) της βάσης δεδομένων, στο πλαίσιο του Ν.3448/2006 και της Οδηγίας (ΕΚ) 2003/98 για την περαιτέρω χρήση πληροφοριών του δημόσιου τομέα.<br />Δικαιώματα διαγραφής λογαριασμού<br />Ο Φορέας διατηρεί το δικαίωμα να διακόψει με κάθε θεμιτό και πρόσφορο τεχνικά μέσο την παροχή των υπηρεσιών προς κάθε πρόσωπο που παραβιάζει τους παρόντες όρους λειτουργίας και χρήσης της ιστοσελίδας. Δεν έχει όμως αντίστοιχη υποχρέωση διακοπής, καθώς δεν προβλέπεται κανόνας εκ των προτέρων διαρκούς επιτήρησης του περιεχομένου της ιστοσελίδας, αλλά ex post facto επέμβασης σε περιπτώσεις αναφοράς, κατά τους όρους της παρ. 5. Σε κάθε περίπτωση, πριν την διαγραφή λογαριασμού ακολουθείται η υποχρέωση κλήσης του χρήστη σε προηγούμενη έκθεση των απόψεών του.<br />Ο χρήστης που επιθυμεί τη διαγραφή του λογαριασμού του, αποστέλλει σχετικό e-mail στο synathina@cityofathens.gr με θέμα «Διαγραφή λογαριασμού» από το mail που έχει δηλώσει κατά την διάρκεια της εγγραφής και οι διαχειριστές (moderators) διαγράφουν τον λογαριασμό μέσα σε 3 εργάσιμες ημέρες.<br />7. Προστασία προσωπικών δεδομένων<br />7.1. Η πλατφόρμα υποστηρίζει την προώθηση και προβολή των δράσεων ομάδων πολιτών και ως εκ τούτου δεν αποσκοπεί στην συλλογή δεδομένων που αφορούν φυσικά πρόσωπα (“προσωπικά δεδομένα”). Ωστόσο, ο Φορέας ενδέχεται να επεξεργάζεται όσα δεδομένα προσωπικού χαρακτήρα είναι απαραίτητα για την παροχή των υπηρεσιών του καθώς και όσα οι ενδιαφερόμενοι αναρτούν στο διαδίκτυο μέσω των υπηρεσιών του. Στον διαδικτυακό τόπο χρησιμοποιείται η τεχνολογία των cookies. Η απενεργοποίηση των cookies θα καταστήσει αδύνατη την είσοδο και την ορθή περιήγηση στην ιστοσελίδα και οι χρήστες αποδέχονται εξ αρχής αυτή την επέμβαση. Κατά την επίσκεψη της ιστοσελίδας για πρώτη φορά θα οριστεί ένα μόνιμο «cookie» (ένα μικρό αρχείο κειμένου) που θα αποθηκευτεί στον σκληρό δίσκο του υπολογιστή του χρήστη. Τα cookies χρησιμοποιούνται κατά τη διάρκεια των διαδοχικών επισκέψεων του χρήστη στην ιστοσελίδα για την προσωποποίηση αυτής. Υπάρχει η δυνατότητα επίσκεψης του διαδικτυακού τόπου και χωρίς τα cookies, αλλά πιθανώς με μειωμένη δυνατότητα χρήσης των υπηρεσιών της ιστοσελίδας. Για την μεταβολή των ρυθμίσεων cookies, ο χρήστης μπορεί να ανατρέξει στο μενού «Βοήθεια» του προγράμματος περιήγησης (browser).<br />7.2. Κάθε επεξεργασία δεδομένων προσωπικού χαρακτήρα της παρ. 7.1. διεξάγεται αποκλειστικά και μόνο από πρόσωπα που τελούν υπό τον έλεγχο του Φορέα. Για τη διεξαγωγή της επεξεργασίας ο Φορέας έχει επιλέξει πρόσωπα με αντίστοιχα επαγγελματικά προσόντα που παρέχουν επαρκείς εγγυήσεις από πλευράς τεχνικών γνώσεων και προσωπικής ακεραιότητας για την τήρηση του απορρήτου. Ο Φορέας έχει λάβει τα κατάλληλα οργανωτικά και τεχνικά μέτρα για την ασφάλεια των δεδομένων και την προστασία τους από τυχαία ή αθέμιτη καταστροφή, τυχαία απώλεια, αλλοίωση, απαγορευμένη διάδοση ή πρόσβαση και κάθε άλλη μορφή αθέμιτης επεξεργασίας. Αυτά τα μέτρα εξασφαλίζουν επίπεδο ασφαλείας ανάλογο προς τους κινδύνους που συνεπάγεται η επεξεργασία και η φύση των δεδομένων που είναι αντικείμενο της επεξεργασίας.<br />7.3. Καθένας έχει δικαίωμα να γνωρίζει εάν δεδομένα προσωπικού χαρακτήρα που τον αφορούν αποτελούν ή αποτέλεσαν αντικείμενο επεξεργασίας από τον Φορέα. Προς τούτο, ο Φορέας έχει υποχρέωση να του απαντήσει εγγράφως. Το υποκείμενο των δεδομένων έχει δικαίωμα να ζητεί και να λαμβάνει από τον υπεύθυνο επεξεργασίας, χωρίς καθυστέρηση και κατά τρόπο εύληπτο και σαφή, τις ακόλουθες πληροφορίες:<br />α) Όλα τα δεδομένα προσωπικού χαρακτήρα που το αφορούν, καθώς και την προέλευσή τους.<br />β) Τους σκοπούς της επεξεργασίας, τους αποδέκτες ή τις κατηγορίες αποδεκτών.<br />γ) Την εξέλιξη της επεξεργασίας για το χρονικό διάστημα από την προηγούμενη ενημέρωση ή πληροφόρησή του.<br />δ) Τη λογική της αυτοματοποιημένης επεξεργασίας.<br />ε) κατά περίπτωση, τη διόρθωση, τη διαγραφή ή τη δέσμευση (κλείδωμα) των δεδομένων των οποίων η επεξεργασία δεν είναι σύμφωνη προς τις διατάξεις του Ν.2472/1997, ιδίως λόγω του ελλιπούς ή ανακριβούς χαρακτήρα των δεδομένων, και<br />στ) την κοινοποίηση σε τρίτους, στους οποίους έχουν ανακοινωθεί τα δεδομένα, κάθε διόρθωσης, διαγραφής ή δέσμευσης (κλειδώματος) που διενεργείται σύμφωνα με την περίπτωση εφόσον τούτο δεν είναι αδύνατον ή δεν προϋποθέτει δυσανάλογες προσπάθειες. Το δικαίωμα πρόσβασης μπορεί να ασκείται από το υποκείμενο των δεδομένων και με τη συνδρομή ειδικού. Ο Φορέας απαντά σε αιτήματα πρόσβασης εντός δεκαπέντε (15) ημερών, σύμφωνα με τα οριζόμενα στο άρθρο 12 του Ν.2472/1997.<br />7.4. Το υποκείμενο των δεδομένων έχει δικαίωμα να προβάλλει οποτεδήποτε αντιρρήσεις για την επεξεργασία δεδομένων που το αφορούν. Οι αντιρρήσεις απευθύνονται εγγράφως στον Φορέα με e-mail και πρέπει να περιέχουν απόδειξη της ταυτότητας του αιτούντος, καθώς και αίτημα για συγκεκριμένη ενέργεια, όπως διόρθωση, προσωρινή μη χρησιμοποίηση, δέσμευση, μη διαβίβαση ή διαγραφή. Ο Φορέας απαντά εγγράφως επί των αντιρρήσεων μέσα σε αποκλειστική προθεσμία δεκαπέντε (15) ημερών. Στην απάντησή του ενημερώνει το υποκείμενο για τις ενέργειες στις οποίες προέβη ή, ενδεχομένως, για τους λόγους που δεν ικανοποίησε το αίτημα. Η απάντηση σε περίπτωση απόρριψης των αντιρρήσεων κοινοποιείται από τον Φορέα στην Αρχή Προστασίας Δεδομένων Προσωπικού Χαρακτήρα.<br />7.5. Για την ενάσκηση των δικαιωμάτων των όρων 7.3. και 7.4. το υποκείμενο των δεδομένων ή ο νόμιμος εκπρόσωπός του να υποβάλλει μέσω e-mail synathina@cityofathens.g στον Φορέα καταγγελία στην οποία να αναφέρει: (α) την ταυτότητά του, προσκομίζοντας σχετικό αποδεικτικό δημόσιας αρχής, (β) τα ειδικότερα προσωπικά δεδομένα που αφορά η καταγγελία του, επισημαίνοντας και την ιστοθέση που βρίσκονται αυτά αναρτημένο, (γ) στοιχεία επικοινωνίας του (τηλέφωνο, διεύθυνση ηλεκτρονικού ταχυδρομείου, διεύθυνση κατοικίας του).<br />7.6. Η τήρηση της παραπάνω διαδικασίας αποτελεί δεσμευτικό συμβατικό όρο πριν από κάθε περαιτέρω ενέργεια ενώπιον δημόσιας αρχής ή δικαστηρίου και η προδικασία αυτή αφορά τόσο τους συνδρομητές όσο και τους απλούς χρήστες, οι οποίοι εισερχόμενοι στην ιστοσελίδα αποδέχονται τη δεσμευτικότητά της.<br />8. Εφαρμοστέο δίκαιο και διαδικασία απόπειρας εξωδικαστικής επίλυσης τυχόν διαφοράς<br />8.1. Για κάθε διαφορά που απορρέει από την χρήση των υπηρεσιών ή και για κάθε άλλο λόγο ανάμεσα στον χρήστη/συνδρομητή και τον Φορέα, εφαρμοστέο είναι το ελληνικό δίκαιο και αρμόδια τα δικαστήρια της Αθήνας.<br />8.2. Σε περίπτωση που ανακύψει διαφορά ως προς τους παρόντες όρους χρήσης, ανάμεσα σε χρήστη/συνδρομητή και τον Φορέα, ο πρώτος υποχρεούται, πριν κινήσει οιαδήποτε δικαστική ενέργεια, να επικοινωνήσει με το Φορέα εντός 15 ημερών από την επέλευση των σχετικών γεγονότων με αποστολή μηνύματος ηλεκτρονικού ταχυδρομείου ή με άλλο γραπτό μέσο. Η παράλειψη τήρησης αυτού του όρου συνιστά παράβαση ουσιώδους συμβατικού όρου που έχει συναφθεί ανάμεσα στον χρήστη/συνδρομητή και τον Φορέα.<br />8.3. Εναλλακτικά, κάθε τυχόν άμεσα θιγόμενος από τις υπηρεσίες του Φορέα διαθέτει το δικαίωμα υποβολής καταγγελίας στον Συμπαραστάτη του Δημότη και της Επιχείρησης, ο οποίος διαμεσολαβεί για την επίλυση του σχετικού προβλήματος. Σχετική καταγγελία μπορεί να σταλεί στην ηλεκτρονική διεύθυνση symparastatis@cityofathens.gr<br />8.4. Για κάθε πληροφορία, ερώτημα και υποβολή παραπόνου μπορείτε να αποστείλετε το αίτημά σας μέσω ταχυδρομείου στη διεύθυνση: synathina@cityofathens.gr<br />9. 1. Το σύνολο των κειμένων που περιλαμβάνονται στις κατηγορίες \"Αbout\" και \"Βlog\" αποτελεί προϊόν διανοίας των συντακτών της ομάδας των διαχειριστών του συνΑθηνά. Τα κείμενα αυτά είναι ελεύθερα αναδημοσιεύσιμα υπό την προϋπόθεση ότι κάθε φορά που αναδημοσιεύονται γίνεται αναφορά του τόπου προέλευσης. δηλαδή παραπομπή στο www.synathina,gr.<br />9.2. Τα κείμενα που περιλαμβάνονται στις κατηγορίες \"Ομάδες\" και \"Δράσεις\" αποτελούν προϊόν διανοίας των χρηστών της ιστοσελίδας του συνΑθηνά. Για την αναδημοσίευσή τους προτείνεται η προηγούμενη επαφή με την εκάστοτε ομάδα που προέβη στη σχετική δημοσίευση. Τα στοιχεία επικοινωνίας των χρηστών βρίσκονται καταχωρημένα στην κατηγορία \"Οι ομάδες\".</p>','',1,2,'2016-03-28 14:39:29',233,'','2018-05-22 14:28:16',233,0,'0000-00-00 00:00:00','2016-03-28 14:39:29','0000-00-00 00:00:00','{\"image_intro\":\"\",\"float_intro\":\"\",\"image_intro_alt\":\"\",\"image_intro_caption\":\"\",\"image_fulltext\":\"\",\"float_fulltext\":\"\",\"image_fulltext_alt\":\"\",\"image_fulltext_caption\":\"\"}','{\"urla\":false,\"urlatext\":\"\",\"targeta\":\"\",\"urlb\":false,\"urlbtext\":\"\",\"targetb\":\"\",\"urlc\":false,\"urlctext\":\"\",\"targetc\":\"\"}','{\"opencall_date\":\"\",\"news_subtitle\":\"\",\"article_video\":\"\",\"show_title\":\"\",\"link_titles\":\"\",\"show_tags\":\"\",\"show_intro\":\"\",\"info_block_position\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_vote\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',4,98,'','',1,2161,'{\"robots\":\"\",\"author\":\"\",\"rights\":\"\",\"xreference\":\"\"}',0,'*',''),(7,68,'Title press article linkable','title-press-article','<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis id lorem est. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Vivamus venenatis dolor ac odio rhoncus, non lacinia orci posuere. Proin sagittis velit iaculis aliquam tincidunt. Nullam sodales laoreet orci, ac ullamcorper nisl venenatis vitae. Etiam mollis, dolor quis pellentesque varius, enim risus porta leo, eget mattis diam libero nec eros. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi blandit fermentum tortor in convallis. Mauris id metus eget massa efficitur semper nec sit amet lorem. Sed cursus mi sit amet dolor pulvinar finibus.</p>\r\n<p>Morbi ornare vestibulum sem. In et lobortis est. Donec vitae purus elementum, rhoncus lorem quis, suscipit magna. Curabitur nunc ligula, dignissim sed luctus vitae, fringilla at purus. Nullam sollicitudin rutrum lectus, a pretium tellus. Aliquam ut ultricies nunc, in feugiat magna. Proin ultricies nisl nec magna aliquam, molestie cursus purus varius. Donec ultricies finibus ipsum non sagittis. Cras sed nisi commodo, efficitur leo ut, mattis magna. Praesent pharetra dictum odio a tempus. Curabitur porttitor tortor elementum odio eleifend condimentum.</p>\r\n<p>Suspendisse eu dapibus leo, tempor dictum nulla. Fusce egestas porttitor enim et malesuada. Quisque cursus imperdiet nisl ac gravida. Suspendisse potenti. Curabitur tincidunt neque non metus tempor, sed fermentum enim condimentum. Phasellus sodales arcu non vehicula euismod. In eget turpis ante. Quisque bibendum sit amet dolor at mattis.</p>\r\n<p>In hac habitasse platea dictumst. Integer eu mi commodo, mollis lorem vel, viverra lorem. In venenatis nulla vitae euismod pellentesque. Donec vulputate tristique enim, ac finibus lacus tristique ac. Morbi sapien neque, condimentum vel convallis vitae, ultricies ac massa. Integer vitae lectus auctor, egestas nisi non, ultrices diam. Suspendisse vestibulum ligula ac lorem pretium, ac cursus augue consectetur. Nunc a faucibus augue. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Etiam rutrum velit nisl. Nullam sed mauris vitae dui lacinia feugiat lobortis eu orci. Cras varius tincidunt nulla, eget lacinia massa dictum quis.</p>\r\n<p>Pellentesque at fermentum orci, sit amet elementum enim. Fusce mi ipsum, auctor ac enim sed, eleifend cursus dui. Morbi hendrerit justo a nisi convallis efficitur. Ut in neque quis velit sollicitudin pulvinar non ut diam. Etiam leo ligula, scelerisque ultrices imperdiet quis, rutrum ac nisl. Ut sit amet dapibus ligula. Aliquam pharetra hendrerit accumsan. Phasellus et semper dui. Vestibulum condimentum justo faucibus lorem tristique, ut pulvinar velit laoreet. Phasellus turpis justo, rutrum ac erat lobortis, rhoncus feugiat metus. Sed id eros id enim consectetur posuere a id lectus. Suspendisse in pulvinar erat.</p>','',1,9,'2016-04-12 15:10:00',233,'','2016-04-12 11:26:19',233,0,'0000-00-00 00:00:00','2016-03-28 15:10:33','0000-00-00 00:00:00','{\"image_intro\":\"\",\"float_intro\":\"\",\"image_intro_alt\":\"\",\"image_intro_caption\":\"\",\"image_fulltext\":\"\",\"float_fulltext\":\"\",\"image_fulltext_alt\":\"\",\"image_fulltext_caption\":\"\"}','{\"urla\":false,\"urlatext\":\"\",\"targeta\":\"\",\"urlb\":false,\"urlbtext\":\"\",\"targetb\":\"\",\"urlc\":false,\"urlctext\":\"\",\"targetc\":\"\"}','{\"news_subtitle\":\"\",\"article_video\":\"\",\"show_title\":\"\",\"link_titles\":\"\",\"show_tags\":\"\",\"show_intro\":\"\",\"info_block_position\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_vote\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',6,4,'','',1,2306,'{\"robots\":\"\",\"author\":\"\",\"rights\":\"\",\"xreference\":\"\"}',0,'*',''),(8,69,'Title press article (2)','title-press-article-2','','',1,9,'2016-03-23 16:10:27',233,'','2016-03-28 15:46:56',233,0,'0000-00-00 00:00:00','2016-03-28 15:10:33','0000-00-00 00:00:00','{\"image_intro\":\"\",\"float_intro\":\"\",\"image_intro_alt\":\"\",\"image_intro_caption\":\"\",\"image_fulltext\":\"\",\"float_fulltext\":\"\",\"image_fulltext_alt\":\"\",\"image_fulltext_caption\":\"\"}','{\"urla\":false,\"urlatext\":\"\",\"targeta\":\"\",\"urlb\":false,\"urlbtext\":\"\",\"targetb\":\"\",\"urlc\":false,\"urlctext\":\"\",\"targetc\":\"\"}','{\"news_subtitle\":\"\",\"show_title\":\"\",\"link_titles\":\"\",\"show_tags\":\"\",\"show_intro\":\"\",\"info_block_position\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_vote\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',3,3,'','',1,628,'{\"robots\":\"\",\"author\":\"\",\"rights\":\"\",\"xreference\":\"\"}',0,'*',''),(9,70,'Title press article (3)','title-press-article-3','','',1,9,'2016-03-23 16:10:27',233,'','2016-03-28 15:47:05',233,0,'0000-00-00 00:00:00','2016-03-28 15:10:33','0000-00-00 00:00:00','{\"image_intro\":\"\",\"float_intro\":\"\",\"image_intro_alt\":\"\",\"image_intro_caption\":\"\",\"image_fulltext\":\"\",\"float_fulltext\":\"\",\"image_fulltext_alt\":\"\",\"image_fulltext_caption\":\"\"}','{\"urla\":false,\"urlatext\":\"\",\"targeta\":\"\",\"urlb\":false,\"urlbtext\":\"\",\"targetb\":\"\",\"urlc\":false,\"urlctext\":\"\",\"targetc\":\"\"}','{\"news_subtitle\":\"\",\"show_title\":\"\",\"link_titles\":\"\",\"show_tags\":\"\",\"show_intro\":\"\",\"info_block_position\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_vote\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',3,2,'','',1,1493,'{\"robots\":\"\",\"author\":\"\",\"rights\":\"\",\"xreference\":\"\"}',0,'*',''),(10,72,'Title press article (4)','title-press-article-4','','',1,9,'2016-03-23 16:10:27',233,'','2016-03-28 15:47:14',233,0,'0000-00-00 00:00:00','2016-03-28 15:10:33','0000-00-00 00:00:00','{\"image_intro\":\"\",\"float_intro\":\"\",\"image_intro_alt\":\"\",\"image_intro_caption\":\"\",\"image_fulltext\":\"\",\"float_fulltext\":\"\",\"image_fulltext_alt\":\"\",\"image_fulltext_caption\":\"\"}','{\"urla\":false,\"urlatext\":\"\",\"targeta\":\"\",\"urlb\":false,\"urlbtext\":\"\",\"targetb\":\"\",\"urlc\":false,\"urlctext\":\"\",\"targetc\":\"\"}','{\"news_subtitle\":\"\",\"show_title\":\"\",\"link_titles\":\"\",\"show_tags\":\"\",\"show_intro\":\"\",\"info_block_position\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_vote\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',3,1,'','',1,1070,'{\"robots\":\"\",\"author\":\"\",\"rights\":\"\",\"xreference\":\"\"}',0,'*',''),(11,74,'Τι έκαναν οι πολίτες αυτήν την εβδομάδα; (5)','τι-έκαναν-οι-πολίτες-αυτήν-την-εβδομάδα-5','<p>Μια εβδομάδα γεμάτη δράσεις για τον πολιτισμό, την καλλιτεχνική έκφραση, το περιβάλλον και την υγεία ολοκληρώθηκε! δράσεις για την Αθήνα. Η ομάδα του...</p>\r\n','\r\n<p>&nbsp;</p>\r\n<p>Μια εβδομάδα γεμάτη δράσεις για τον πολιτισμό, την καλλιτεχνική έκφραση, το περιβάλλον και την υγεία ολοκληρώθηκε! δράσεις για την Αθήνα. Η ομάδα του...Μια εβδομάδα γεμάτη δράσεις για τον πολιτισμό, την καλλιτεχνική έκφραση, το περιβάλλον και την υγεία ολοκληρώθηκε! δράσεις για την Αθήνα. Η ομάδα του...Μια εβδομάδα γεμάτη δράσεις για τον πολιτισμό, την καλλιτεχνική έκφραση, το περιβάλλον και την υγεία ολοκληρώθηκε! δράσεις για την Αθήνα. Η ομάδα του...Μια εβδομάδα γεμάτη δράσεις για τον πολιτισμό, την καλλιτεχνική έκφραση, το περιβάλλον και την υγεία ολοκληρώθηκε! δράσεις για την Αθήνα. Η ομάδα του...Μια εβδομάδα γεμάτη δράσεις για τον πολιτισμό, την καλλιτεχνική έκφραση, το περιβάλλον και την υγεία ολοκληρώθηκε! δράσεις για την Αθήνα. Η ομάδα του...</p>\r\n<p>Μια εβδομάδα γεμάτη δράσεις για τον πολιτισμό, την καλλιτεχνική έκφραση, το περιβάλλον και την υγεία ολοκληρώθηκε! δράσεις για την Αθήνα. Η ομάδα του...Μια εβδομάδα γεμάτη δράσεις για τον πολιτισμό, την καλλιτεχνική έκφραση, το περιβάλλον και την υγεία ολοκληρώθηκε! δράσεις για την Αθήνα. Η ομάδα του...Μια εβδομάδα γεμάτη δράσεις για τον πολιτισμό, την καλλιτεχνική έκφραση, το περιβάλλον και την υγεία ολοκληρώθηκε! δράσεις για την Αθήνα. Η ομάδα του...</p>',-2,8,'2015-12-02 13:40:00',233,'','2016-03-29 09:21:17',0,0,'0000-00-00 00:00:00','2016-03-28 12:40:32','0000-00-00 00:00:00','{\"image_intro\":\"images\\/news\\/new.jpg\",\"float_intro\":\"\",\"image_intro_alt\":\"\",\"image_intro_caption\":\"\",\"image_fulltext\":\"\",\"float_fulltext\":\"\",\"image_fulltext_alt\":\"\",\"image_fulltext_caption\":\"\"}','{\"urla\":false,\"urlatext\":\"\",\"targeta\":\"\",\"urlb\":false,\"urlbtext\":\"\",\"targetb\":\"\",\"urlc\":false,\"urlctext\":\"\",\"targetc\":\"\"}','{\"news_subtitle\":\"23 Νοεμβρίου - 30 Δεκεμβρίου\",\"show_title\":\"\",\"link_titles\":\"\",\"show_tags\":\"\",\"show_intro\":\"\",\"info_block_position\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_vote\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',1,54,'','',1,236,'{\"robots\":\"\",\"author\":\"\",\"rights\":\"\",\"xreference\":\"\"}',0,'*',''),(12,75,'Τι έκαναν οι πολίτες αυτήν την εβδομάδα; (6)','τι-έκαναν-οι-πολίτες-αυτήν-την-εβδομάδα-6','<p>Μια εβδομάδα γεμάτη δράσεις για τον πολιτισμό, την καλλιτεχνική έκφραση, το περιβάλλον και την υγεία ολοκληρώθηκε! δράσεις για την Αθήνα. Η ομάδα του...</p>\r\n','\r\n<p>&nbsp;</p>\r\n<p>Μια εβδομάδα γεμάτη δράσεις για τον πολιτισμό, την καλλιτεχνική έκφραση, το περιβάλλον και την υγεία ολοκληρώθηκε! δράσεις για την Αθήνα. Η ομάδα του...Μια εβδομάδα γεμάτη δράσεις για τον πολιτισμό, την καλλιτεχνική έκφραση, το περιβάλλον και την υγεία ολοκληρώθηκε! δράσεις για την Αθήνα. Η ομάδα του...Μια εβδομάδα γεμάτη δράσεις για τον πολιτισμό, την καλλιτεχνική έκφραση, το περιβάλλον και την υγεία ολοκληρώθηκε! δράσεις για την Αθήνα. Η ομάδα του...Μια εβδομάδα γεμάτη δράσεις για τον πολιτισμό, την καλλιτεχνική έκφραση, το περιβάλλον και την υγεία ολοκληρώθηκε! δράσεις για την Αθήνα. Η ομάδα του...Μια εβδομάδα γεμάτη δράσεις για τον πολιτισμό, την καλλιτεχνική έκφραση, το περιβάλλον και την υγεία ολοκληρώθηκε! δράσεις για την Αθήνα. Η ομάδα του...</p>\r\n<p>Μια εβδομάδα γεμάτη δράσεις για τον πολιτισμό, την καλλιτεχνική έκφραση, το περιβάλλον και την υγεία ολοκληρώθηκε! δράσεις για την Αθήνα. Η ομάδα του...Μια εβδομάδα γεμάτη δράσεις για τον πολιτισμό, την καλλιτεχνική έκφραση, το περιβάλλον και την υγεία ολοκληρώθηκε! δράσεις για την Αθήνα. Η ομάδα του...Μια εβδομάδα γεμάτη δράσεις για τον πολιτισμό, την καλλιτεχνική έκφραση, το περιβάλλον και την υγεία ολοκληρώθηκε! δράσεις για την Αθήνα. Η ομάδα του...</p>',-2,8,'2015-12-02 13:40:00',233,'','2016-03-29 09:21:20',0,0,'0000-00-00 00:00:00','2016-03-28 12:40:32','0000-00-00 00:00:00','{\"image_intro\":\"images\\/news\\/new.jpg\",\"float_intro\":\"\",\"image_intro_alt\":\"\",\"image_intro_caption\":\"\",\"image_fulltext\":\"\",\"float_fulltext\":\"\",\"image_fulltext_alt\":\"\",\"image_fulltext_caption\":\"\"}','{\"urla\":false,\"urlatext\":\"\",\"targeta\":\"\",\"urlb\":false,\"urlbtext\":\"\",\"targetb\":\"\",\"urlc\":false,\"urlctext\":\"\",\"targetc\":\"\"}','{\"news_subtitle\":\"23 Νοεμβρίου - 30 Δεκεμβρίου\",\"show_title\":\"\",\"link_titles\":\"\",\"show_tags\":\"\",\"show_intro\":\"\",\"info_block_position\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_vote\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',1,53,'','',1,1353,'{\"robots\":\"\",\"author\":\"\",\"rights\":\"\",\"xreference\":\"\"}',0,'*',''),(13,76,'Τι έκαναν οι πολίτες αυτήν την εβδομάδα; (7)','τι-έκαναν-οι-πολίτες-αυτήν-την-εβδομάδα-7','<p>Μια εβδομάδα γεμάτη δράσεις για τον πολιτισμό, την καλλιτεχνική έκφραση, το περιβάλλον και την υγεία ολοκληρώθηκε! δράσεις για την Αθήνα. Η ομάδα του...</p>\r\n','\r\n<p>&nbsp;</p>\r\n<p>Μια εβδομάδα γεμάτη δράσεις για τον πολιτισμό, την καλλιτεχνική έκφραση, το περιβάλλον και την υγεία ολοκληρώθηκε! δράσεις για την Αθήνα. Η ομάδα του...Μια εβδομάδα γεμάτη δράσεις για τον πολιτισμό, την καλλιτεχνική έκφραση, το περιβάλλον και την υγεία ολοκληρώθηκε! δράσεις για την Αθήνα. Η ομάδα του...Μια εβδομάδα γεμάτη δράσεις για τον πολιτισμό, την καλλιτεχνική έκφραση, το περιβάλλον και την υγεία ολοκληρώθηκε! δράσεις για την Αθήνα. Η ομάδα του...Μια εβδομάδα γεμάτη δράσεις για τον πολιτισμό, την καλλιτεχνική έκφραση, το περιβάλλον και την υγεία ολοκληρώθηκε! δράσεις για την Αθήνα. Η ομάδα του...Μια εβδομάδα γεμάτη δράσεις για τον πολιτισμό, την καλλιτεχνική έκφραση, το περιβάλλον και την υγεία ολοκληρώθηκε! δράσεις για την Αθήνα. Η ομάδα του...</p>\r\n<p>Μια εβδομάδα γεμάτη δράσεις για τον πολιτισμό, την καλλιτεχνική έκφραση, το περιβάλλον και την υγεία ολοκληρώθηκε! δράσεις για την Αθήνα. Η ομάδα του...Μια εβδομάδα γεμάτη δράσεις για τον πολιτισμό, την καλλιτεχνική έκφραση, το περιβάλλον και την υγεία ολοκληρώθηκε! δράσεις για την Αθήνα. Η ομάδα του...Μια εβδομάδα γεμάτη δράσεις για τον πολιτισμό, την καλλιτεχνική έκφραση, το περιβάλλον και την υγεία ολοκληρώθηκε! δράσεις για την Αθήνα. Η ομάδα του...</p>',-2,8,'2015-12-02 13:40:00',233,'','2016-03-29 09:21:23',0,0,'0000-00-00 00:00:00','2016-03-28 12:40:32','0000-00-00 00:00:00','{\"image_intro\":\"images\\/news\\/new.jpg\",\"float_intro\":\"\",\"image_intro_alt\":\"\",\"image_intro_caption\":\"\",\"image_fulltext\":\"\",\"float_fulltext\":\"\",\"image_fulltext_alt\":\"\",\"image_fulltext_caption\":\"\"}','{\"urla\":false,\"urlatext\":\"\",\"targeta\":\"\",\"urlb\":false,\"urlbtext\":\"\",\"targetb\":\"\",\"urlc\":false,\"urlctext\":\"\",\"targetc\":\"\"}','{\"news_subtitle\":\"23 Νοεμβρίου - 30 Δεκεμβρίου\",\"show_title\":\"\",\"link_titles\":\"\",\"show_tags\":\"\",\"show_intro\":\"\",\"info_block_position\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_vote\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',1,52,'','',1,2313,'{\"robots\":\"\",\"author\":\"\",\"rights\":\"\",\"xreference\":\"\"}',0,'*',''),(14,77,'Τι έκαναν οι πολίτες αυτήν την εβδομάδα; (8)','τι-έκαναν-οι-πολίτες-αυτήν-την-εβδομάδα-8','<p>Μια εβδομάδα γεμάτη δράσεις για τον πολιτισμό, την καλλιτεχνική έκφραση, το περιβάλλον και την υγεία ολοκληρώθηκε! δράσεις για την Αθήνα. Η ομάδα του...</p>\r\n','\r\n<p>&nbsp;</p>\r\n<p>Μια εβδομάδα γεμάτη δράσεις για τον πολιτισμό, την καλλιτεχνική έκφραση, το περιβάλλον και την υγεία ολοκληρώθηκε! δράσεις για την Αθήνα. Η ομάδα του...Μια εβδομάδα γεμάτη δράσεις για τον πολιτισμό, την καλλιτεχνική έκφραση, το περιβάλλον και την υγεία ολοκληρώθηκε! δράσεις για την Αθήνα. Η ομάδα του...Μια εβδομάδα γεμάτη δράσεις για τον πολιτισμό, την καλλιτεχνική έκφραση, το περιβάλλον και την υγεία ολοκληρώθηκε! δράσεις για την Αθήνα. Η ομάδα του...Μια εβδομάδα γεμάτη δράσεις για τον πολιτισμό, την καλλιτεχνική έκφραση, το περιβάλλον και την υγεία ολοκληρώθηκε! δράσεις για την Αθήνα. Η ομάδα του...Μια εβδομάδα γεμάτη δράσεις για τον πολιτισμό, την καλλιτεχνική έκφραση, το περιβάλλον και την υγεία ολοκληρώθηκε! δράσεις για την Αθήνα. Η ομάδα του...</p>\r\n<p>Μια εβδομάδα γεμάτη δράσεις για τον πολιτισμό, την καλλιτεχνική έκφραση, το περιβάλλον και την υγεία ολοκληρώθηκε! δράσεις για την Αθήνα. Η ομάδα του...Μια εβδομάδα γεμάτη δράσεις για τον πολιτισμό, την καλλιτεχνική έκφραση, το περιβάλλον και την υγεία ολοκληρώθηκε! δράσεις για την Αθήνα. Η ομάδα του...Μια εβδομάδα γεμάτη δράσεις για τον πολιτισμό, την καλλιτεχνική έκφραση, το περιβάλλον και την υγεία ολοκληρώθηκε! δράσεις για την Αθήνα. Η ομάδα του...</p>',-2,8,'2015-12-02 13:40:00',233,'','2016-03-29 09:21:25',0,0,'0000-00-00 00:00:00','2016-03-28 12:40:32','0000-00-00 00:00:00','{\"image_intro\":\"images\\/news\\/new.jpg\",\"float_intro\":\"\",\"image_intro_alt\":\"\",\"image_intro_caption\":\"\",\"image_fulltext\":\"\",\"float_fulltext\":\"\",\"image_fulltext_alt\":\"\",\"image_fulltext_caption\":\"\"}','{\"urla\":false,\"urlatext\":\"\",\"targeta\":\"\",\"urlb\":false,\"urlbtext\":\"\",\"targetb\":\"\",\"urlc\":false,\"urlctext\":\"\",\"targetc\":\"\"}','{\"news_subtitle\":\"23 Νοεμβρίου - 30 Δεκεμβρίου\",\"show_title\":\"\",\"link_titles\":\"\",\"show_tags\":\"\",\"show_intro\":\"\",\"info_block_position\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_vote\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',1,51,'','',1,989,'{\"robots\":\"\",\"author\":\"\",\"rights\":\"\",\"xreference\":\"\"}',0,'*',''),(15,78,'Τι έκαναν οι πολίτες αυτήν την εβδομάδα; (9)','τι-έκαναν-οι-πολίτες-αυτήν-την-εβδομάδα-9','<p>Μια εβδομάδα γεμάτη δράσεις για τον πολιτισμό, την καλλιτεχνική έκφραση, το περιβάλλον και την υγεία ολοκληρώθηκε! δράσεις για την Αθήνα. Η ομάδα του...</p>\r\n','\r\n<p>&nbsp;</p>\r\n<p>Μια εβδομάδα γεμάτη δράσεις για τον πολιτισμό, την καλλιτεχνική έκφραση, το περιβάλλον και την υγεία ολοκληρώθηκε! δράσεις για την Αθήνα. Η ομάδα του...Μια εβδομάδα γεμάτη δράσεις για τον πολιτισμό, την καλλιτεχνική έκφραση, το περιβάλλον και την υγεία ολοκληρώθηκε! δράσεις για την Αθήνα. Η ομάδα του...Μια εβδομάδα γεμάτη δράσεις για τον πολιτισμό, την καλλιτεχνική έκφραση, το περιβάλλον και την υγεία ολοκληρώθηκε! δράσεις για την Αθήνα. Η ομάδα του...Μια εβδομάδα γεμάτη δράσεις για τον πολιτισμό, την καλλιτεχνική έκφραση, το περιβάλλον και την υγεία ολοκληρώθηκε! δράσεις για την Αθήνα. Η ομάδα του...Μια εβδομάδα γεμάτη δράσεις για τον πολιτισμό, την καλλιτεχνική έκφραση, το περιβάλλον και την υγεία ολοκληρώθηκε! δράσεις για την Αθήνα. Η ομάδα του...</p>\r\n<p>Μια εβδομάδα γεμάτη δράσεις για τον πολιτισμό, την καλλιτεχνική έκφραση, το περιβάλλον και την υγεία ολοκληρώθηκε! δράσεις για την Αθήνα. Η ομάδα του...Μια εβδομάδα γεμάτη δράσεις για τον πολιτισμό, την καλλιτεχνική έκφραση, το περιβάλλον και την υγεία ολοκληρώθηκε! δράσεις για την Αθήνα. Η ομάδα του...Μια εβδομάδα γεμάτη δράσεις για τον πολιτισμό, την καλλιτεχνική έκφραση, το περιβάλλον και την υγεία ολοκληρώθηκε! δράσεις για την Αθήνα. Η ομάδα του...</p>',-2,8,'2015-12-02 13:40:00',233,'','2016-03-29 09:21:28',0,0,'0000-00-00 00:00:00','2016-03-28 12:40:32','0000-00-00 00:00:00','{\"image_intro\":\"images\\/news\\/new.jpg\",\"float_intro\":\"\",\"image_intro_alt\":\"\",\"image_intro_caption\":\"\",\"image_fulltext\":\"\",\"float_fulltext\":\"\",\"image_fulltext_alt\":\"\",\"image_fulltext_caption\":\"\"}','{\"urla\":false,\"urlatext\":\"\",\"targeta\":\"\",\"urlb\":false,\"urlbtext\":\"\",\"targetb\":\"\",\"urlc\":false,\"urlctext\":\"\",\"targetc\":\"\"}','{\"news_subtitle\":\"23 Νοεμβρίου - 30 Δεκεμβρίου\",\"show_title\":\"\",\"link_titles\":\"\",\"show_tags\":\"\",\"show_intro\":\"\",\"info_block_position\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_vote\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',1,50,'','',1,1968,'{\"robots\":\"\",\"author\":\"\",\"rights\":\"\",\"xreference\":\"\"}',0,'*',''),(16,79,'Τι έκαναν οι πολίτες αυτήν την εβδομάδα; (10)','τι-έκαναν-οι-πολίτες-αυτήν-την-εβδομάδα-10','<p>Μια εβδομάδα γεμάτη δράσεις για τον πολιτισμό, την καλλιτεχνική έκφραση, το περιβάλλον και την υγεία ολοκληρώθηκε! δράσεις για την Αθήνα. Η ομάδα του...</p>\r\n','\r\n<p>&nbsp;</p>\r\n<p>Μια εβδομάδα γεμάτη δράσεις για τον πολιτισμό, την καλλιτεχνική έκφραση, το περιβάλλον και την υγεία ολοκληρώθηκε! δράσεις για την Αθήνα. Η ομάδα του...Μια εβδομάδα γεμάτη δράσεις για τον πολιτισμό, την καλλιτεχνική έκφραση, το περιβάλλον και την υγεία ολοκληρώθηκε! δράσεις για την Αθήνα. Η ομάδα του...Μια εβδομάδα γεμάτη δράσεις για τον πολιτισμό, την καλλιτεχνική έκφραση, το περιβάλλον και την υγεία ολοκληρώθηκε! δράσεις για την Αθήνα. Η ομάδα του...Μια εβδομάδα γεμάτη δράσεις για τον πολιτισμό, την καλλιτεχνική έκφραση, το περιβάλλον και την υγεία ολοκληρώθηκε! δράσεις για την Αθήνα. Η ομάδα του...Μια εβδομάδα γεμάτη δράσεις για τον πολιτισμό, την καλλιτεχνική έκφραση, το περιβάλλον και την υγεία ολοκληρώθηκε! δράσεις για την Αθήνα. Η ομάδα του...</p>\r\n<p>Μια εβδομάδα γεμάτη δράσεις για τον πολιτισμό, την καλλιτεχνική έκφραση, το περιβάλλον και την υγεία ολοκληρώθηκε! δράσεις για την Αθήνα. Η ομάδα του...Μια εβδομάδα γεμάτη δράσεις για τον πολιτισμό, την καλλιτεχνική έκφραση, το περιβάλλον και την υγεία ολοκληρώθηκε! δράσεις για την Αθήνα. Η ομάδα του...Μια εβδομάδα γεμάτη δράσεις για τον πολιτισμό, την καλλιτεχνική έκφραση, το περιβάλλον και την υγεία ολοκληρώθηκε! δράσεις για την Αθήνα. Η ομάδα του...</p>',-2,8,'2015-12-02 13:40:00',233,'','2016-03-29 09:21:31',0,0,'0000-00-00 00:00:00','2016-03-28 12:40:32','0000-00-00 00:00:00','{\"image_intro\":\"images\\/news\\/new.jpg\",\"float_intro\":\"\",\"image_intro_alt\":\"\",\"image_intro_caption\":\"\",\"image_fulltext\":\"\",\"float_fulltext\":\"\",\"image_fulltext_alt\":\"\",\"image_fulltext_caption\":\"\"}','{\"urla\":false,\"urlatext\":\"\",\"targeta\":\"\",\"urlb\":false,\"urlbtext\":\"\",\"targetb\":\"\",\"urlc\":false,\"urlctext\":\"\",\"targetc\":\"\"}','{\"news_subtitle\":\"23 Νοεμβρίου - 30 Δεκεμβρίου\",\"show_title\":\"\",\"link_titles\":\"\",\"show_tags\":\"\",\"show_intro\":\"\",\"info_block_position\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_vote\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',1,49,'','',1,1185,'{\"robots\":\"\",\"author\":\"\",\"rights\":\"\",\"xreference\":\"\"}',0,'*',''),(26,108,'Οι αριθμοί μιλούν','οι-αριθμοί-μιλούν','<p>Από την έναρξη της λειτουργίας της, τον Ιούλιο του 2013, έως και σήμερα η ιστοσελίδα και η στέγη του συνΑθηνά έχουν φιλοξενήσει συνολικά <strong>{total_actions} δράσεις</strong> τις οποίες πραγματοποίησαν <strong>{total_teams} ομάδες</strong> πολιτών και φορείς σε συνεργασία με <strong>{total_donators} υποστηρικτές</strong>. Από τα στοιχεία που συλλέγουμε μέσα από τις δράσεις αντλούμε πολύτιμες πληροφορίες για τις προτεραιότητες των πολιτών.</p>','',-2,11,'2016-05-10 00:07:19',233,'','2017-04-27 12:52:12',233,0,'0000-00-00 00:00:00','2016-05-10 00:07:19','0000-00-00 00:00:00','{\"image_intro\":\"\",\"float_intro\":\"\",\"image_intro_alt\":\"\",\"image_intro_caption\":\"\",\"image_fulltext\":\"\",\"float_fulltext\":\"\",\"image_fulltext_alt\":\"\",\"image_fulltext_caption\":\"\"}','{\"urla\":false,\"urlatext\":\"\",\"targeta\":\"\",\"urlb\":false,\"urlbtext\":\"\",\"targetb\":\"\",\"urlc\":false,\"urlctext\":\"\",\"targetc\":\"\"}','{\"opencall_date\":\"\",\"news_image\":\"center\",\"news_subtitle\":\"\",\"show_title\":\"\",\"link_titles\":\"\",\"show_tags\":\"\",\"show_intro\":\"\",\"info_block_position\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_vote\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',8,3,'','',1,1507,'{\"robots\":\"\",\"author\":\"\",\"rights\":\"\",\"xreference\":\"\"}',0,'el-GR',''),(27,109,'Τα εργαλεία μας στη διάθεσή σας','τα-εργαλεία-μας-στη-διάθεσή-σας','<p>Η <strong>διαδικτυακή πλατφόρμα</strong> του συνΑθηνά δίνει στις ομάδες πολιτών τη δυνατότητα να ενισχύσουν σημαντικά την προβολή των δράσεών τους και να έρθουν σε επαφή με υποστηρικτές.</p>\r\n<p>Η <a href=\"index.php?option=com_content&amp;view=article&amp;id=37&amp;Itemid=145\">στέγη του συνΑθηνά</a> λειτουργεί ως φυσικό σημείο συνάντησης όπου οι ομάδες πολιτών οργανώνουν και υλοποιούν τις δράσεις τους και συνεργάζονται.</p>\r\n<p>Οι <strong>Ανοιχτές Δευτέρες</strong> και οι <strong>θεματικές συναντήσεις</strong> ενισχύουν το έργο της διασύνδεσης ανάμεσα σε ομάδες πολιτών με άλλες ομάδες, φορείς, χορηγούς και οργανισμούς.</p>','',1,11,'2016-05-10 00:07:40',233,'','2016-05-29 13:51:03',233,0,'0000-00-00 00:00:00','2016-05-10 00:07:40','0000-00-00 00:00:00','{\"image_intro\":\"\",\"float_intro\":\"\",\"image_intro_alt\":\"\",\"image_intro_caption\":\"\",\"image_fulltext\":\"\",\"float_fulltext\":\"\",\"image_fulltext_alt\":\"\",\"image_fulltext_caption\":\"\"}','{\"urla\":false,\"urlatext\":\"\",\"targeta\":\"\",\"urlb\":false,\"urlbtext\":\"\",\"targetb\":\"\",\"urlc\":false,\"urlctext\":\"\",\"targetc\":\"\"}','{\"news_subtitle\":\"\",\"article_video\":\"\",\"show_title\":\"\",\"link_titles\":\"\",\"show_tags\":\"\",\"show_intro\":\"\",\"info_block_position\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_vote\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',9,2,'','',1,683,'{\"robots\":\"\",\"author\":\"\",\"rights\":\"\",\"xreference\":\"\"}',0,'el-GR',''),(28,110,'To συνΑθηνά στην πράξη','to-συναθηνά-στην-πράξη','<div class=\"media\">\r\n<div class=\"media-left\"><i class=\"fill fill--collect\" style=\"background-image: url(\'images/synathina/synathina_infographics.png\');\"></i></div>\r\n<div class=\"media-body\">\r\n<h4 class=\"media-heading\">Συλλέγουμε</h4>\r\n<p>Συλλέγουμε τις δράσεις των πολιτών και μέσα από αυτές μαθαίνουμε ποιες είναι οι δικές τους προτεραιότητες για την πόλη.</p>\r\n</div>\r\n</div>\r\n<div class=\"media\">\r\n<div class=\"media-left\"><i class=\"fill fill--connect\" style=\"background-image: url(\'images/synathina/synathina_infographics.png\');\"></i></div>\r\n<div class=\"media-body\">\r\n<h4 class=\"media-heading\">Διασυνδέουμε</h4>\r\n<p>Διευκολύνουμε τις ομάδες και τους πολίτες στην πραγματοποίηση των δράσεών τους και ενθαρρύνουμε συνεργασίες με άλλες ομάδες, χορηγούς και φορείς.</p>\r\n</div>\r\n</div>\r\n<div class=\"media\">\r\n<div class=\"media-left\"><i class=\"fill fill--filter\" style=\"background-image: url(\'images/synathina/synathina_infographics.png\');\"></i></div>\r\n<div class=\"media-body\">\r\n<h4 class=\"media-heading\">Φιλτράρουμε</h4>\r\n<p>Ξεχωρίζουμε τις δράσεις με τη μεγαλύτερη επιρροή στην πόλη και ανιχνεύουμε τη δυνατότητα αξιοποίησής τους στην τοπική διακυβέρνηση.</p>\r\n</div>\r\n</div>\r\n<div class=\"media\">\r\n<div class=\"media-left\"><i class=\"fill fill--merge\" style=\"background-image: url(\'images/synathina/synathina_infographics.png\');\"></i></div>\r\n<div class=\"media-body\">\r\n<h4 class=\"media-heading\">Ενσωματώνουμε</h4>\r\n<p>Ενεργοποιούμε τα αντανακλαστικά του Δήμου έτσι ώστε να βελτιώνονται οι υπηρεσίες του σε σχέση με τις νέες ανάγκες των πολιτών. Οι δράσεις των πολιτών μπορούν να οδηγήσουν σε αλλαγή των πολιτικών προτεραιοτήτων του Δήμου, σε αναβάθμιση των κανονισμών και σε απλοποίηση των διαδικασιών.</p>\r\n</div>\r\n</div>','',1,11,'2016-05-10 00:09:47',233,'','2016-07-12 23:53:29',233,0,'0000-00-00 00:00:00','2016-05-10 00:09:47','0000-00-00 00:00:00','{\"image_intro\":\"\",\"float_intro\":\"\",\"image_intro_alt\":\"\",\"image_intro_caption\":\"\",\"image_fulltext\":\"\",\"float_fulltext\":\"\",\"image_fulltext_alt\":\"\",\"image_fulltext_caption\":\"\"}','{\"urla\":false,\"urlatext\":\"\",\"targeta\":\"\",\"urlb\":false,\"urlbtext\":\"\",\"targetb\":\"\",\"urlc\":false,\"urlctext\":\"\",\"targetc\":\"\"}','{\"opencall_date\":\"\",\"news_image\":\"center\",\"news_subtitle\":\"\",\"show_title\":\"\",\"link_titles\":\"\",\"show_tags\":\"\",\"show_intro\":\"\",\"info_block_position\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_vote\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',6,1,'','',1,1356,'{\"robots\":\"\",\"author\":\"\",\"rights\":\"\",\"xreference\":\"\"}',0,'el-GR',''),(29,111,'Λίγα λόγια για το συνΑθηνά και την αποστολή του','λίγα-λόγια-για-το-συναθηνά-και-την-αποστολή-του','<p>To συνΑθηνά είναι o κοινός τόπος συνάντησης, διευκόλυνσης και αξιοποίησης των ομάδων πολιτών που πραγματοποιούν δράσεις για τη βελτίωση της ποιότητας ζωής στην πόλη. Μέσα από τον συντονισμό του ανθρωπίνου κεφαλαίου των ομάδων πολιτών, ο δήμος Αθηναίων αφουγκράζεται τις ανάγκες της κοινωνίας και εκσυγχρονίζεται. Ενδυναμώνοντας τις δράσεις των πολιτών, ο δήμος διαμορφώνει μια νέα αντίληψη για τη σχέση της κοινωνίας των πολιτών με την τοπική αυτοδιοίκηση και καλλιεργεί μια αμφίδρομη και δυναμική μεταξύ τους σχέση. Το συνΑθηνά είναι μια πρωτοβουλία του δήμου Αθηναίων. Δημιουργήθηκε τον Ιούλιο του 2013 και υπάγεται σήμερα στην Αντιδημαρχία Κοινωνίας των Πολιτών και Καινοτομίας.</p>','',1,11,'2016-05-10 00:10:10',233,'','2017-05-29 14:00:22',233,0,'0000-00-00 00:00:00','2016-05-10 00:10:10','0000-00-00 00:00:00','{\"image_intro\":\"\",\"float_intro\":\"\",\"image_intro_alt\":\"\",\"image_intro_caption\":\"\",\"image_fulltext\":\"\",\"float_fulltext\":\"\",\"image_fulltext_alt\":\"\",\"image_fulltext_caption\":\"\"}','{\"urla\":false,\"urlatext\":\"\",\"targeta\":\"\",\"urlb\":false,\"urlbtext\":\"\",\"targetb\":\"\",\"urlc\":false,\"urlctext\":\"\",\"targetc\":\"\"}','{\"opencall_date\":\"\",\"news_image\":\"center\",\"news_subtitle\":\"\",\"show_title\":\"\",\"link_titles\":\"\",\"show_tags\":\"\",\"show_intro\":\"\",\"info_block_position\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_vote\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',4,0,'','',1,1898,'{\"robots\":\"\",\"author\":\"\",\"rights\":\"\",\"xreference\":\"\"}',0,'el-GR',''),(30,329,'Οι ομάδες','οι-ομάδες','<p>Ομάδες πολιτών με ή χωρίς νομική προσωπικότητα, σωματεία, σύλλογοι, κοινωνικές επιχειρήσεις, μη κερδροσκοπικοί οργανισμοί και όλοι όσοι υλοποιούν δράσεις προσανατολισμένες στο κοινό όφελος είναι ευπρόσδεκτοι στο συνΑθηνά. Πραγματοποιείς κι εσύ δράσεςι για τη βελτίωση της ποιότητας ζωής στην πόλη; Μπορείς τώρα να δημιουργήσεις το προφίλ της ομάδας σου στην ιστοσελίδα του συνΑθηνά και να συμμετάσχεις σε ένα οικοσύστημα που νοιάζεται για το καλό της πόλης. Σε περιμένουμε!</p>\r\n<p><br /><br /></p>\r\n<div id=\"_mcePaste\" class=\"mcePaste\" data-mce-bogus=\"1\" style=\"position: absolute; left: 0px; top: -25px; width: 10px; height: 10px; overflow: hidden;\"><span lang=\"EN-US\" style=\"font-size: 10.0pt; line-height: 107%; font-family: \'Arial\',sans-serif; mso-fareast-font-family: Calibri; mso-fareast-theme-font: minor-latin; color: #5d5d5d; mso-ansi-language: EN-US; mso-fareast-language: EN-US; mso-bidi-language: AR-SA;\">O</span><span style=\"font-size: 10.0pt; line-height: 107%; font-family: \'Arial\',sans-serif; mso-fareast-font-family: Calibri; mso-fareast-theme-font: minor-latin; color: #5d5d5d; mso-ansi-language: EL; mso-fareast-language: EN-US; mso-bidi-language: AR-SA;\">μάδες πολιτών με ή χωρίς νομική προσωπικότητα, σωματεία, σύλλογοι, κοινωνικές<br /> επιχειρήσεις, μη κερδοσκοπικοί οργανισμοί και όλοι όσοι υλοποιούν δράσεις προσανατολισμένες στο κοινό όφελος είναι ευπρόσδεκτοι στο συνΑθηνά. Πραγματοποιείς κι εσύ δράσεις για τη βελτίωση της ποιότητας ζωής στην πόλη; Μπορείς τώρα να δημιουργήσεις το προφίλ της ομάδας σου στην ιστοσελίδα του συνΑθηνά και να συμμετάσχεις σε ένα οικοσύστημα που νοιάζεται για το καλό της πόλης. Σε περιμένουμε!&nbsp;</span></div>','',1,12,'2016-05-12 12:20:38',233,'','2018-11-23 12:11:12',233,0,'0000-00-00 00:00:00','2016-05-12 12:20:38','0000-00-00 00:00:00','{\"image_intro\":\"\",\"float_intro\":\"\",\"image_intro_alt\":\"\",\"image_intro_caption\":\"\",\"image_fulltext\":\"\",\"float_fulltext\":\"\",\"image_fulltext_alt\":\"\",\"image_fulltext_caption\":\"\"}','{\"urla\":false,\"urlatext\":\"\",\"targeta\":\"\",\"urlb\":false,\"urlbtext\":\"\",\"targetb\":\"\",\"urlc\":false,\"urlctext\":\"\",\"targetc\":\"\"}','{\"homepage_text_color\":\"white\",\"opencall_date\":\"\",\"news_image\":\"center\",\"news_subtitle\":\"\",\"show_title\":\"\",\"link_titles\":\"\",\"show_tags\":\"\",\"show_intro\":\"\",\"info_block_position\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_vote\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',2,1,'','',1,1666,'{\"robots\":\"\",\"author\":\"\",\"rights\":\"\",\"xreference\":\"\"}',0,'el-GR',''),(31,330,'Οι υποστηρικτές','οι-υποστηρικτές','<p>Κάθε ιδιώτης, επιχείρηση ή οργανισμός που θέλει να ενισχύσει τις δράσεις των ενεργών πολιτών της Αθήνας προσφέροντας τεχνογνωσία, υλικά, χώρο, εθελοντές ή χρηματική χορηγία, μπορεί να δημιουργήσει προφίλ υποστηρικτή στην ιστοσελίδα μας. Η πλατφόρμα του συνΑθηνά δίνει επίσης τη δυνατότητα σε εθελοντές και δωρητές να προσφέρουν την υποστήριξή τους ανώνυμα.</p>\r\n<p>Κάθε φορά που μια ομάδα πολιτών αναζητά την ενίσχυση της δράσης της μέσω του συνΑθηνά, οι αντίστοιχοι υποστηρικτές ενημερώνονται γραπτά ώστε να ανταποκριθούν, εφόσον μπορούν, στο αίτημα για υποστήριξη.</p>\r\n<p>Θέλεις βοηθήσεις όσους κάνουν δράσεις για το καλό της πόλης; Σε περιμένουμε στο δίκτυο υποστηρικτών του συνΑθηνά.</p>','',1,22,'2016-05-12 12:20:53',233,'','2018-11-23 12:34:10',233,0,'0000-00-00 00:00:00','2016-05-12 12:20:53','0000-00-00 00:00:00','{\"image_intro\":\"\",\"float_intro\":\"\",\"image_intro_alt\":\"\",\"image_intro_caption\":\"\",\"image_fulltext\":\"\",\"float_fulltext\":\"\",\"image_fulltext_alt\":\"\",\"image_fulltext_caption\":\"\"}','{\"urla\":false,\"urlatext\":\"\",\"targeta\":\"\",\"urlb\":false,\"urlbtext\":\"\",\"targetb\":\"\",\"urlc\":false,\"urlctext\":\"\",\"targetc\":\"\"}','{\"homepage_text_color\":\"white\",\"opencall_date\":\"\",\"news_image\":\"center\",\"news_subtitle\":\"\",\"show_title\":\"\",\"link_titles\":\"\",\"show_tags\":\"\",\"show_intro\":\"\",\"info_block_position\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_vote\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',3,1,'','',1,1323,'{\"robots\":\"\",\"author\":\"\",\"rights\":\"\",\"xreference\":\"\"}',0,'el-GR',''),(32,331,'Διασύνδεση','διασύνδεση','<p>Όλοι όσοι συμμετέχουν στην ψηφιακή πλατφόρμα του συνΑθηνά έχουν τη δυνατότητα να αναζητήσουν την ενίσχυση των δράσεών τους μέσα από το δίκτυο υποστηρικτών κι εθελοντών που είναι επίσης εγγεγραμμένοι στην ιστοσελίδα του συνΑθηνά. Ανεβάζοντας τη δράση σου μπορείς να απευθύνεις το μήνυμά σου στους υποστηρικτές, να διασυνδεθείς με άλλες ομάδες αλλά και να ζητήσεις τη συμβολή των δημοτικών υπηρεσιών στη δράση του.</p>','',1,12,'2016-05-12 12:21:27',233,'','2018-11-23 12:30:33',233,0,'0000-00-00 00:00:00','2016-05-12 12:21:27','0000-00-00 00:00:00','{\"image_intro\":\"\",\"float_intro\":\"\",\"image_intro_alt\":\"\",\"image_intro_caption\":\"\",\"image_fulltext\":\"\",\"float_fulltext\":\"\",\"image_fulltext_alt\":\"\",\"image_fulltext_caption\":\"\"}','{\"urla\":false,\"urlatext\":\"\",\"targeta\":\"\",\"urlb\":false,\"urlbtext\":\"\",\"targetb\":\"\",\"urlc\":false,\"urlctext\":\"\",\"targetc\":\"\"}','{\"homepage_text_color\":\"white\",\"opencall_date\":\"\",\"news_image\":\"center\",\"news_subtitle\":\"\",\"show_title\":\"\",\"link_titles\":\"\",\"show_tags\":\"\",\"show_intro\":\"\",\"info_block_position\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_vote\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',6,3,'','',1,824,'{\"robots\":\"\",\"author\":\"\",\"rights\":\"\",\"xreference\":\"\"}',0,'el-GR',''),(33,1888,'Η σύνδεσή μας με το δίκτυο','η-σύνδεσή-μας-με-το-δίκτυο','<p>Μέσα από την ενεργή συμμετοχή σε διεθνή δίκτυα ανταλλαγής τεχνογνωσίας και εμπειριών, το συνΑθηνά διαδραματίζει πρωταγωνιστικό ρόλο σε έναν παγκόσμιο διάλογο για την καινοτομία και τη συμμετοχή των πολιτών στην τοπική αυτοδιοίκηση.</p>','',1,13,'2016-05-24 12:48:56',233,'','2017-01-25 10:30:52',233,233,'2018-12-03 12:42:08','2016-05-24 12:48:56','0000-00-00 00:00:00','{\"image_intro\":\"\",\"float_intro\":\"\",\"image_intro_alt\":\"\",\"image_intro_caption\":\"\",\"image_fulltext\":\"\",\"float_fulltext\":\"\",\"image_fulltext_alt\":\"\",\"image_fulltext_caption\":\"\"}','{\"urla\":false,\"urlatext\":\"\",\"targeta\":\"\",\"urlb\":false,\"urlbtext\":\"\",\"targetb\":\"\",\"urlc\":false,\"urlctext\":\"\",\"targetc\":\"\"}','{\"opencall_date\":\"\",\"news_image\":\"center\",\"news_subtitle\":\"\",\"show_title\":\"\",\"link_titles\":\"\",\"show_tags\":\"\",\"show_intro\":\"\",\"info_block_position\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_vote\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',2,1,'','',1,1646,'{\"robots\":\"\",\"author\":\"\",\"rights\":\"\",\"xreference\":\"\"}',0,'*',''),(34,1889,'Ομάδα εργασίας Creative Citizenship του δικτύου Eurocities','ομάδα-εργασίας-creative-citizenship-του-δικτύου-eurocities','<p>Η ομάδα εργασίας Creative Citizenship ιδρύθηκε τον Μάιο του 2015, με πρωτοβουλία του Δήμου Αθηναίων, στο πλαίσιο του δικτύου αιρετών εκπροσώπων των ευρωπαϊκών πόλεων Eurocities. Το Creative Citizenship αναζητά τους τρόπους με τους οποίους η τοπική αυτοδιοίκηση συνεργάζεται με την κοινωνία των πολιτών πάνω στις προκλήσεις των σύγχρονων πόλεων και διερευνά το πώς αυτή η συνεργασία ενθαρρύνει την καινοτομία, οδηγεί σε άμεσες λύσεις για την πόλη και αναβαθμίζει την τοπική αυτοδιοίκηση.</p>\r\n<p><a href=\"http://www.eurocities.eu\" target=\"_blank\">www.eurocities.eu</a></p>\r\n<p><img src=\"images/articles/sponsor_logo.jpg\" alt=\"\" /></p>','',1,13,'2016-05-24 12:49:45',233,'','2016-06-29 13:18:28',233,0,'0000-00-00 00:00:00','2016-05-24 12:49:45','0000-00-00 00:00:00','{\"image_intro\":\"\",\"float_intro\":\"\",\"image_intro_alt\":\"\",\"image_intro_caption\":\"\",\"image_fulltext\":\"\",\"float_fulltext\":\"\",\"image_fulltext_alt\":\"\",\"image_fulltext_caption\":\"\"}','{\"urla\":false,\"urlatext\":\"\",\"targeta\":\"\",\"urlb\":false,\"urlbtext\":\"\",\"targetb\":\"\",\"urlc\":false,\"urlctext\":\"\",\"targetc\":\"\"}','{\"opencall_date\":\"\",\"news_subtitle\":\"\",\"article_video\":\"\",\"show_title\":\"\",\"link_titles\":\"\",\"show_tags\":\"\",\"show_intro\":\"\",\"info_block_position\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_vote\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',2,2,'','',1,1413,'{\"robots\":\"\",\"author\":\"\",\"rights\":\"\",\"xreference\":\"\"}',0,'*',''),(35,1890,'European City Makers','european-city-makers','<p>To συνΑθηνά εκπροσωπεί την Αθήνα στο δίκτυο European City Makers το οποίο συναποτελούν 28 πρωτεύουσες της Ευρωπαϊκής Ένωσης στο πλαίσιο της πρωτοβουλίας του Άμστερνταμ “New Europe”. Έργο του European City Makers είναι η ενδυνάμωση των ενεργών πολιτών, η διασύνδεσή τους με τους φορείς του ιδιωτικού τομέα, τα πανεπιστήμια και την τοπική αυτοδιοίκηση και η δημιουργία ενός δικτύου Ευρωπαίων πολιτών που αναζητούν μια νέα ευρωπαϊκή ταυτότητα.</p>\r\n<p><a href=\"http://www.citiesintransition.eu\" target=\"_blank\">www.citiesintransition.eu</a></p>\r\n<p><img src=\"images/articles/new_europe_logo.jpg\" alt=\"\" /></p>','',1,13,'2016-05-24 12:50:25',233,'','2016-06-29 13:18:49',233,0,'0000-00-00 00:00:00','2016-05-24 12:50:25','0000-00-00 00:00:00','{\"image_intro\":\"\",\"float_intro\":\"\",\"image_intro_alt\":\"\",\"image_intro_caption\":\"\",\"image_fulltext\":\"\",\"float_fulltext\":\"\",\"image_fulltext_alt\":\"\",\"image_fulltext_caption\":\"\"}','{\"urla\":false,\"urlatext\":\"\",\"targeta\":\"\",\"urlb\":false,\"urlbtext\":\"\",\"targetb\":\"\",\"urlc\":false,\"urlctext\":\"\",\"targetc\":\"\"}','{\"opencall_date\":\"\",\"news_subtitle\":\"\",\"article_video\":\"\",\"show_title\":\"\",\"link_titles\":\"\",\"show_tags\":\"\",\"show_intro\":\"\",\"info_block_position\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_vote\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',2,3,'','',1,2005,'{\"robots\":\"\",\"author\":\"\",\"rights\":\"\",\"xreference\":\"\"}',0,'*',''),(36,1891,'Bloomberg Philanthropies Mayor\'s Challenge','bloomberg-philanthropies-mayor-s-challenge','<p>Τον Ιούνιο του 2014, το συνΑθηνά συμμετείχε στο διαγωνισμό Mayor\'s Challenge του ιδρύματος Bloomberg Philanthropies, για την ανάπτυξη καινοτόμων ιδεών γύρω από την επίλυση των προβλημάτων στις σύγχρονες πόλεις και την αύξηση της αποτελεσματικότητας της τοπικής αυτοδιοίκησης. Η Αθήνα διακρίθηκε ανάμεσα στις πέντε κορυφαίες συμμετοχές (από τις 155 συνολικά) και βραβεύτηκε με το ποσό του 1 εκατομμυρίου ευρώ για την πρόταση του συνΑθηνά να εξελιχθεί σε δυναμικό μηχανισμό αναβάθμισης της τοπικής αυτοδιοίκησης, μέσα από τη συνεργασία του με τις ομάδες πολιτών.</p>\r\n<p><a href=\"http://www.bloomberg.org\" target=\"_blank\">www.bloomberg.org</a></p>\r\n<p><img src=\"images/articles/bloomberg_purple_logo.png\" alt=\"\" />&nbsp; &nbsp; &nbsp;&nbsp;<img src=\"images/articles/mayor_challenge_logo.png\" alt=\"\" /></p>','',1,13,'2016-05-24 12:51:28',233,'','2018-03-28 16:01:13',233,0,'0000-00-00 00:00:00','2016-05-24 12:51:28','0000-00-00 00:00:00','{\"image_intro\":\"\",\"float_intro\":\"\",\"image_intro_alt\":\"\",\"image_intro_caption\":\"\",\"image_fulltext\":\"\",\"float_fulltext\":\"\",\"image_fulltext_alt\":\"\",\"image_fulltext_caption\":\"\"}','{\"urla\":false,\"urlatext\":\"\",\"targeta\":\"\",\"urlb\":false,\"urlbtext\":\"\",\"targetb\":\"\",\"urlc\":false,\"urlctext\":\"\",\"targetc\":\"\"}','{\"opencall_date\":\"\",\"news_image\":\"center\",\"news_subtitle\":\"\",\"show_title\":\"\",\"link_titles\":\"\",\"show_tags\":\"\",\"show_intro\":\"\",\"info_block_position\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_vote\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',5,4,'','',1,1457,'{\"robots\":\"\",\"author\":\"\",\"rights\":\"\",\"xreference\":\"\"}',0,'*',''),(37,1906,'Η στέγη του συνΑθηνά','η-στέγη-μας','<p>Κάθε ομάδα πολιτών μπορεί να χρησιμοποιήσει δωρεάν τη στέγη του συνΑθηνά 365 μέρες τον χρόνο, 24 ώρες το 24ωρο. Η στέγη του συνΑθηνά βρίσκεται ακριβώς απέναντι από τη Βαρβάκειο Αγορά, στην οδό Αθηνάς 55, εκτείνεται σε έναν βιοκλιματικό χώρο 30 τ.μ. ενώ διαθέτει και υπαίθριο χώρο. Εδώ, ομάδες και φορείς οργανώνουν και υλοποιούν τις δράσεις τους, ανταλλάσσουν εμπειρίες και τεχνογνωσία μεταξύ τους, συναντούν τους πολίτες και τους ενημερώνουν γι\' αυτό που κάνουν.&nbsp;</p>\r\n<h4 class=\"module-title--subtitle\">Πώς κάνω κράτηση της στέγης για τις ανάγκες της ομάδας μου:</h4>\r\n<ol>\r\n<li>Κάνω εγγραφή στο site του συνΑθηνά.</li>\r\n<li>Ελέγχω τις διαθέσιμες μέρες και ώρες στο ηλεκτρονικό ημερολόγιο της στέγης.</li>\r\n<li>Συμπληρώνω την αντίστοιχη φόρμα και εντός 24 ωρών λαμβάνω επιβεβαίωση για την αποδοχή του αιτήματός μου.</li>\r\n</ol>','',1,2,'2016-05-26 12:31:31',233,'','2018-05-22 14:28:16',233,0,'0000-00-00 00:00:00','2016-05-26 12:31:31','0000-00-00 00:00:00','{\"image_intro\":\"\",\"float_intro\":\"\",\"image_intro_alt\":\"\",\"image_intro_caption\":\"\",\"image_fulltext\":\"\",\"float_fulltext\":\"\",\"image_fulltext_alt\":\"\",\"image_fulltext_caption\":\"\"}','{\"urla\":false,\"urlatext\":\"\",\"targeta\":\"\",\"urlb\":false,\"urlbtext\":\"\",\"targetb\":\"\",\"urlc\":false,\"urlctext\":\"\",\"targetc\":\"\"}','{\"opencall_date\":\"\",\"news_image\":\"center\",\"news_subtitle\":\"\",\"show_title\":\"\",\"link_titles\":\"\",\"show_tags\":\"\",\"show_intro\":\"\",\"info_block_position\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_vote\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',6,97,'','',1,13263,'{\"robots\":\"\",\"author\":\"\",\"rights\":\"\",\"xreference\":\"\"}',0,'*',''),(38,1909,'2016','2016','','',1,14,'2016-05-28 08:09:05',233,'','2016-05-28 08:09:53',233,0,'0000-00-00 00:00:00','2016-05-28 08:09:05','0000-00-00 00:00:00','{\"image_intro\":\"\",\"float_intro\":\"\",\"image_intro_alt\":\"\",\"image_intro_caption\":\"\",\"image_fulltext\":\"\",\"float_fulltext\":\"\",\"image_fulltext_alt\":\"\",\"image_fulltext_caption\":\"\"}','{\"urla\":false,\"urlatext\":\"\",\"targeta\":\"\",\"urlb\":false,\"urlbtext\":\"\",\"targetb\":\"\",\"urlc\":false,\"urlctext\":\"\",\"targetc\":\"\"}','{\"news_subtitle\":\"\",\"article_video\":\"\",\"show_title\":\"\",\"link_titles\":\"\",\"show_tags\":\"\",\"show_intro\":\"\",\"info_block_position\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_vote\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',2,1,'','',1,1263,'{\"robots\":\"\",\"author\":\"\",\"rights\":\"\",\"xreference\":\"\"}',0,'*',''),(39,1910,'2015','2015','','',1,14,'2016-05-28 08:09:49',233,'','2016-05-28 10:32:39',233,0,'0000-00-00 00:00:00','2016-05-28 08:09:49','0000-00-00 00:00:00','{\"image_intro\":\"\",\"float_intro\":\"\",\"image_intro_alt\":\"\",\"image_intro_caption\":\"\",\"image_fulltext\":\"\",\"float_fulltext\":\"\",\"image_fulltext_alt\":\"\",\"image_fulltext_caption\":\"\"}','{\"urla\":false,\"urlatext\":\"\",\"targeta\":\"\",\"urlb\":false,\"urlbtext\":\"\",\"targetb\":\"\",\"urlc\":false,\"urlctext\":\"\",\"targetc\":\"\"}','{\"news_subtitle\":\"\",\"article_video\":\"\",\"show_title\":\"\",\"link_titles\":\"\",\"show_tags\":\"\",\"show_intro\":\"\",\"info_block_position\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_vote\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',3,2,'','',1,1765,'{\"robots\":\"\",\"author\":\"\",\"rights\":\"\",\"xreference\":\"\"}',0,'*',''),(40,1914,'The groups','the-groups','<p>SynAthina welcomes anyone who organizes and/or supports activities for socially beneficial purposes. Engaged citizens and citizens’ groups can sign up, quickly and easily, and register their activities and support. They can create their profile on the synAthina website, post their logo, describe the way their group operates, and make their activities public. Do you also organize activities about life in the city? We are waiting to hear from you.</p>','',1,16,'2016-05-29 12:50:09',233,'','2018-05-14 19:19:36',233,0,'0000-00-00 00:00:00','2016-05-29 12:50:09','0000-00-00 00:00:00','{\"image_intro\":\"\",\"float_intro\":\"\",\"image_intro_alt\":\"\",\"image_intro_caption\":\"\",\"image_fulltext\":\"\",\"float_fulltext\":\"\",\"image_fulltext_alt\":\"\",\"image_fulltext_caption\":\"\"}','{\"urla\":false,\"urlatext\":\"\",\"targeta\":\"\",\"urlb\":false,\"urlbtext\":\"\",\"targetb\":\"\",\"urlc\":false,\"urlctext\":\"\",\"targetc\":\"\"}','{\"news_subtitle\":\"\",\"article_video\":\"\",\"show_title\":\"\",\"link_titles\":\"\",\"show_tags\":\"\",\"show_intro\":\"\",\"info_block_position\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_vote\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',1,1,'','',1,1145,'{\"robots\":\"\",\"author\":\"\",\"rights\":\"\",\"xreference\":\"\"}',0,'en-GB',''),(41,1915,'The sponsors','the-sponsors','<p>Every individual, business or organization that can support the activities of citizens’ groups by offering knowledge, technical equipment or financial donation, is a sponsor. All the sponsors need to do is to create a new profile on the website of synAthina so as to come into contact with the citizens’ groups.</p>','',1,23,'2016-05-29 12:51:18',233,'','2018-05-14 19:20:30',233,0,'0000-00-00 00:00:00','2016-05-29 12:51:18','0000-00-00 00:00:00','{\"image_intro\":\"\",\"float_intro\":\"\",\"image_intro_alt\":\"\",\"image_intro_caption\":\"\",\"image_fulltext\":\"\",\"float_fulltext\":\"\",\"image_fulltext_alt\":\"\",\"image_fulltext_caption\":\"\"}','{\"urla\":false,\"urlatext\":\"\",\"targeta\":\"\",\"urlb\":false,\"urlbtext\":\"\",\"targetb\":\"\",\"urlc\":false,\"urlctext\":\"\",\"targetc\":\"\"}','{\"homepage_text_color\":\"white\",\"opencall_date\":\"\",\"news_image\":\"center\",\"news_subtitle\":\"\",\"show_title\":\"\",\"link_titles\":\"\",\"show_tags\":\"\",\"show_intro\":\"\",\"info_block_position\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_vote\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',2,1,'','',1,1732,'{\"robots\":\"\",\"author\":\"\",\"rights\":\"\",\"xreference\":\"\"}',0,'en-GB',''),(42,1916,'Connectivity','connectivity','<p>The ability to bring the groups of citizens and the groups of sponsors into contact is an invaluable tool. Based on the data stored on the synAthina platform, different groups can locate and utilize the available support of their sponsors and thus aid their activities. In addition, via the synAthina connectivity tool, the groups can communicate with each other and exchange knowledge and human resources.</p>','',1,16,'2016-05-29 12:52:00',233,'','2016-05-29 12:52:00',0,0,'0000-00-00 00:00:00','2016-05-29 12:52:00','0000-00-00 00:00:00','{\"image_intro\":\"\",\"float_intro\":\"\",\"image_intro_alt\":\"\",\"image_intro_caption\":\"\",\"image_fulltext\":\"\",\"float_fulltext\":\"\",\"image_fulltext_alt\":\"\",\"image_fulltext_caption\":\"\"}','{\"urla\":false,\"urlatext\":\"\",\"targeta\":\"\",\"urlb\":false,\"urlbtext\":\"\",\"targetb\":\"\",\"urlc\":false,\"urlctext\":\"\",\"targetc\":\"\"}','{\"news_subtitle\":\"\",\"article_video\":\"\",\"show_title\":\"\",\"link_titles\":\"\",\"show_tags\":\"\",\"show_intro\":\"\",\"info_block_position\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_vote\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',1,2,'','',1,1351,'{\"robots\":\"\",\"author\":\"\",\"rights\":\"\",\"xreference\":\"\"}',0,'en-GB',''),(43,1923,'What the numbers say','what-the-numbers-say','<p>From when it was launched, in July 2013, up to this day, the webpage and the kiosk of synAthina have hosted <strong>{total_actions} activities</strong>&nbsp;which have been realized by <strong>{total_teams} groups</strong> of citizens and institutions in cooperation with <strong>{total_donators} sponsors</strong>. Based on the data we collect from the activities, we gather valuable information about the citizens’ priorities regarding their city.</p>','',-2,19,'2016-05-10 00:07:19',233,'','2017-04-27 12:55:22',233,0,'0000-00-00 00:00:00','2016-05-10 00:07:19','0000-00-00 00:00:00','{\"image_intro\":\"\",\"float_intro\":\"\",\"image_intro_alt\":\"\",\"image_intro_caption\":\"\",\"image_fulltext\":\"\",\"float_fulltext\":\"\",\"image_fulltext_alt\":\"\",\"image_fulltext_caption\":\"\"}','{\"urla\":false,\"urlatext\":\"\",\"targeta\":\"\",\"urlb\":false,\"urlbtext\":\"\",\"targetb\":\"\",\"urlc\":false,\"urlctext\":\"\",\"targetc\":\"\"}','{\"opencall_date\":\"\",\"news_image\":\"center\",\"news_subtitle\":\"\",\"show_title\":\"\",\"link_titles\":\"\",\"show_tags\":\"\",\"show_intro\":\"\",\"info_block_position\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_vote\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',9,3,'','',1,1812,'{\"robots\":\"\",\"author\":\"\",\"rights\":\"\",\"xreference\":\"\"}',0,'en-GB',''),(44,1924,'Our tools at your disposal','our-tools-at-your-disposal','<p>The <strong>digital platform</strong> of synAthina offers citizens’ groups the ability to significantly enhance the prominence of their activities and to contact possible sponsors.<br />The <a href=\"index.php?option=com_content&amp;view=article&amp;id=37&amp;Itemid=156&amp;lang=en\">synAthina kiosk</a> functions as an actual meeting point where groups of citizens organize and actualize their activities and collaborate.<br /><strong>Open Mondays</strong> and<strong> thematic meetings</strong> reinforce the connectivity among different groups of citizens, institutions, sponsors and organizations.</p>','',1,19,'2016-05-10 00:07:40',233,'','2016-05-29 13:50:33',233,0,'0000-00-00 00:00:00','2016-05-10 00:07:40','0000-00-00 00:00:00','{\"image_intro\":\"\",\"float_intro\":\"\",\"image_intro_alt\":\"\",\"image_intro_caption\":\"\",\"image_fulltext\":\"\",\"float_fulltext\":\"\",\"image_fulltext_alt\":\"\",\"image_fulltext_caption\":\"\"}','{\"urla\":false,\"urlatext\":\"\",\"targeta\":\"\",\"urlb\":false,\"urlbtext\":\"\",\"targetb\":\"\",\"urlc\":false,\"urlctext\":\"\",\"targetc\":\"\"}','{\"news_subtitle\":\"\",\"article_video\":\"\",\"show_title\":\"\",\"link_titles\":\"\",\"show_tags\":\"\",\"show_intro\":\"\",\"info_block_position\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_vote\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',11,2,'','',1,1352,'{\"robots\":\"\",\"author\":\"\",\"rights\":\"\",\"xreference\":\"\"}',0,'en-GB',''),(45,1925,'SynAthina in action','synathina-in-action','<div class=\"media\">\r\n<div class=\"media-left\"> <i class=\"fill fill--collect\" style=\"background-image: url(\'images/synathina/synathina_infographics.png\');\"></i> </div>\r\n<div class=\"media-body\">\r\n<h4 class=\"media-heading\">Collecting</h4>\r\n<p>We collect the activities of citizens and through them we learn what their priorities are for the city.</p>\r\n</div>\r\n</div>\r\n<div class=\"media\">\r\n<div class=\"media-left\"> <i class=\"fill fill--connect\" style=\"background-image: url(\'images/synathina/synathina_infographics.png\');\"></i> </div>\r\n<div class=\"media-body\">\r\n<h4 class=\"media-heading\">Connecting</h4>\r\n<p>We enable the groups and the citizens to actualize their activities and we encourage them to cooperate with other groups, sponsors, and institutions.</p>\r\n</div>\r\n</div>\r\n<div class=\"media\">\r\n<div class=\"media-left\"> <i class=\"fill fill--filter\" style=\"background-image: url(\'images/synathina/synathina_infographics.png\');\"></i> </div>\r\n<div class=\"media-body\">\r\n<h4 class=\"media-heading\">Sieving</h4>\r\n<p>We pick out those activities which have a greater impact on the city and we explore their potential for use in local governance.</p>\r\n</div>\r\n</div>\r\n<div class=\"media\">\r\n<div class=\"media-left\"> <i class=\"fill fill--merge\" style=\"background-image: url(\'images/synathina/synathina_infographics.png\');\"></i> </div>\r\n<div class=\"media-body\">\r\n<h4 class=\"media-heading\">Incorporating</h4>\r\n<p>We activate the City’s reflexes so that its services can be improved in relation to the current needs of its citizens. The citizens’ activities can lead to changes in the City’s political priorities, to an upgrading of the regulations and to a simplification of procedures.</p>\r\n</div>\r\n</div>','',1,19,'2016-05-10 00:09:47',233,'','2016-07-12 23:53:44',233,0,'0000-00-00 00:00:00','2016-05-10 00:09:47','0000-00-00 00:00:00','{\"image_intro\":\"\",\"float_intro\":\"\",\"image_intro_alt\":\"\",\"image_intro_caption\":\"\",\"image_fulltext\":\"\",\"float_fulltext\":\"\",\"image_fulltext_alt\":\"\",\"image_fulltext_caption\":\"\"}','{\"urla\":false,\"urlatext\":\"\",\"targeta\":\"\",\"urlb\":false,\"urlbtext\":\"\",\"targetb\":\"\",\"urlc\":false,\"urlctext\":\"\",\"targetc\":\"\"}','{\"opencall_date\":\"\",\"news_image\":\"center\",\"news_subtitle\":\"\",\"show_title\":\"\",\"link_titles\":\"\",\"show_tags\":\"\",\"show_intro\":\"\",\"info_block_position\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_vote\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',7,1,'','',1,2053,'{\"robots\":\"\",\"author\":\"\",\"rights\":\"\",\"xreference\":\"\"}',0,'en-GB',''),(46,1926,'A few words about synAthina and its mission','a-few-words-about-synathina-and-its-mission','<p>SynAthina is the common space which brings together, supports and facilitates citizens’ groups engaged in improving the quality of life in the city. By coordinating the invaluable resource of citizens’ groups, the City of Athens actively listens to the needs of its people and is thus revitalized. By supporting the activities of the citizens the City creates a new perception about the relationship between civic society and local governance and cultivates their dynamic, bidirectional bond.<br />SynAthina is an initiative of the City of Athens. It was created in July 2013 and today comes under the Vice Mayoral Office for Civil Society and Innovation.</p>','',1,19,'2016-05-10 00:10:10',233,'','2018-11-23 12:14:04',233,0,'0000-00-00 00:00:00','2016-05-10 00:10:10','0000-00-00 00:00:00','{\"image_intro\":\"\",\"float_intro\":\"\",\"image_intro_alt\":\"\",\"image_intro_caption\":\"\",\"image_fulltext\":\"\",\"float_fulltext\":\"\",\"image_fulltext_alt\":\"\",\"image_fulltext_caption\":\"\"}','{\"urla\":false,\"urlatext\":\"\",\"targeta\":\"\",\"urlb\":false,\"urlbtext\":\"\",\"targetb\":\"\",\"urlc\":false,\"urlctext\":\"\",\"targetc\":\"\"}','{\"homepage_text_color\":\"white\",\"opencall_date\":\"\",\"news_image\":\"center\",\"news_subtitle\":\"\",\"show_title\":\"\",\"link_titles\":\"\",\"show_tags\":\"\",\"show_intro\":\"\",\"info_block_position\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_vote\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',4,0,'','',1,822,'{\"robots\":\"\",\"author\":\"\",\"rights\":\"\",\"xreference\":\"\"}',0,'en-GB',''),(47,1928,'Our connection with the Network','our-connection-with-the-network','<p>SynAthina actively participates in international networks which exchange experience and knowledge, thus playing a leading part in a worldwide dialogue about innovation and the participation of citizens in local governance.</p>','',1,18,'2016-05-24 12:48:56',233,'','2017-01-25 11:07:11',233,0,'0000-00-00 00:00:00','2016-05-24 12:48:56','0000-00-00 00:00:00','{\"image_intro\":\"\",\"float_intro\":\"\",\"image_intro_alt\":\"\",\"image_intro_caption\":\"\",\"image_fulltext\":\"\",\"float_fulltext\":\"\",\"image_fulltext_alt\":\"\",\"image_fulltext_caption\":\"\"}','{\"urla\":false,\"urlatext\":\"\",\"targeta\":\"\",\"urlb\":false,\"urlbtext\":\"\",\"targetb\":\"\",\"urlc\":false,\"urlctext\":\"\",\"targetc\":\"\"}','{\"opencall_date\":\"\",\"news_image\":\"center\",\"news_subtitle\":\"\",\"show_title\":\"\",\"link_titles\":\"\",\"show_tags\":\"\",\"show_intro\":\"\",\"info_block_position\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_vote\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',3,1,'','',1,2188,'{\"robots\":\"\",\"author\":\"\",\"rights\":\"\",\"xreference\":\"\"}',0,'en-GB',''),(48,1929,'Creative Citizenship working group of the Eurocities Network','creative-citizenship-working-group-of-the-eurocities-network','<p>The Creative Citizenship working group was formed in May 2015 by an initiative of the City of Athens, as part of the network of elected representatives of European cities, Eurocities. Creative Citizenship is looking for ways for local governance to collaborate with citizens’ groups in order to face the challenges of modern cities. It explores how this collaboration encourages innovation, leads to immediate solutions for the city and upgrades local governance.</p>\r\n<p><a href=\"http://www.eurocities.eu\" target=\"_blank\">www.eurocities.eu</a></p>\r\n<p><img src=\"images/articles/sponsor_logo.jpg\" alt=\"\" /></p>','',1,18,'2016-05-24 12:49:45',233,'','2016-06-29 13:16:18',233,0,'0000-00-00 00:00:00','2016-05-24 12:49:45','0000-00-00 00:00:00','{\"image_intro\":\"\",\"float_intro\":\"\",\"image_intro_alt\":\"\",\"image_intro_caption\":\"\",\"image_fulltext\":\"\",\"float_fulltext\":\"\",\"image_fulltext_alt\":\"\",\"image_fulltext_caption\":\"\"}','{\"urla\":false,\"urlatext\":\"\",\"targeta\":\"\",\"urlb\":false,\"urlbtext\":\"\",\"targetb\":\"\",\"urlc\":false,\"urlctext\":\"\",\"targetc\":\"\"}','{\"opencall_date\":\"\",\"news_subtitle\":\"\",\"article_video\":\"\",\"show_title\":\"\",\"link_titles\":\"\",\"show_tags\":\"\",\"show_intro\":\"\",\"info_block_position\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_vote\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',4,2,'','',1,1202,'{\"robots\":\"\",\"author\":\"\",\"rights\":\"\",\"xreference\":\"\"}',0,'en-GB',''),(49,1930,'European City Makers','european-city-makers','<p>SynAthina represents Athens in the network European City Makers which is constituted by 28 capital cities of the European Union, as part of the Amsterdam initiative “New Europe”. The purpose of European City Makers is to reinforce engaged citizens, to facilitate their connection with the private sector, universities and local governance and to create a network of European citizens in search of a new European identity.</p>\r\n<p><a href=\"https://citiesintransition.eu\" target=\"_blank\">www.citiesintransition.eu</a></p>\r\n<p><img src=\"images/articles/new_europe_logo.jpg\" alt=\"\" /></p>','',1,18,'2016-05-24 12:50:25',233,'','2016-06-29 13:16:37',233,0,'0000-00-00 00:00:00','2016-05-24 12:50:25','0000-00-00 00:00:00','{\"image_intro\":\"\",\"float_intro\":\"\",\"image_intro_alt\":\"\",\"image_intro_caption\":\"\",\"image_fulltext\":\"\",\"float_fulltext\":\"\",\"image_fulltext_alt\":\"\",\"image_fulltext_caption\":\"\"}','{\"urla\":false,\"urlatext\":\"\",\"targeta\":\"\",\"urlb\":false,\"urlbtext\":\"\",\"targetb\":\"\",\"urlc\":false,\"urlctext\":\"\",\"targetc\":\"\"}','{\"opencall_date\":\"\",\"news_subtitle\":\"\",\"article_video\":\"\",\"show_title\":\"\",\"link_titles\":\"\",\"show_tags\":\"\",\"show_intro\":\"\",\"info_block_position\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_vote\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',4,3,'','',1,2244,'{\"robots\":\"\",\"author\":\"\",\"rights\":\"\",\"xreference\":\"\"}',0,'en-GB',''),(50,1931,'Bloomberg Philanthropies Mayor\'s Challenge','bloomberg-philanthropies-mayor-s-challenge','<p>In June 2014, synAthina participated in the Bloomberg Philanthropies foundation\'s Mayor’s Challenge contest on the development of innovative ideas to face the challenges of modern cities and to make local governance more effective. Athens was among the top five participants (out of155) and was rewarded with the amount of 1 million Euros for the proposal of synAthina to evolve into a dynamic system of upgrading local governance by collaborating with citizens’ groups.</p>\r\n<p><a href=\"http://www.bloomberg.org\" target=\"_blank\">www.bloomberg.org</a></p>\r\n<p><img src=\"images/articles/bloomberg_purple_logo.png\" alt=\"\" />&nbsp; &nbsp; &nbsp;&nbsp;<img src=\"images/articles/mayor_challenge_logo.png\" alt=\"\" /></p>','',1,18,'2016-05-24 12:51:28',233,'','2016-07-25 11:29:37',233,0,'0000-00-00 00:00:00','2016-05-24 12:51:28','0000-00-00 00:00:00','{\"image_intro\":\"\",\"float_intro\":\"\",\"image_intro_alt\":\"\",\"image_intro_caption\":\"\",\"image_fulltext\":\"\",\"float_fulltext\":\"\",\"image_fulltext_alt\":\"\",\"image_fulltext_caption\":\"\"}','{\"urla\":false,\"urlatext\":\"\",\"targeta\":\"\",\"urlb\":false,\"urlbtext\":\"\",\"targetb\":\"\",\"urlc\":false,\"urlctext\":\"\",\"targetc\":\"\"}','{\"opencall_date\":\"\",\"news_image\":\"center\",\"news_subtitle\":\"\",\"show_title\":\"\",\"link_titles\":\"\",\"show_tags\":\"\",\"show_intro\":\"\",\"info_block_position\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_vote\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',6,4,'','',1,1366,'{\"robots\":\"\",\"author\":\"\",\"rights\":\"\",\"xreference\":\"\"}',0,'en-GB',''),(51,1932,'Social Dynamo','social-dynamo','<p>Social Dynamo is the fruit of the common vision of the Bodosakis Foundation and the City of Athens, via synAthina, for a dynamic civic society which will reinforce democratic institutions, promote participatory governance, and develop solidarity. Social Dynamo highlights and develops the potential of Non Governmental Organizations and engaged citizens’ groups, by providing them with knowledge and opportunities for collaboration and networking via a creative space, both actual and digital.</p>\r\n<p><a href=\"http://www.socialdynamo.gr\">www.socialdynamo.gr</a><a href=\"http://www.socialdynamo.gr\" target=\"_blank\"></a></p>\r\n<p><img src=\"images/articles/social_dynamo.jpg\" alt=\"social dynamo\" /></p>','',1,18,'2016-05-29 13:58:39',233,'','2016-07-11 14:47:32',233,0,'0000-00-00 00:00:00','2016-05-29 13:58:39','0000-00-00 00:00:00','{\"image_intro\":\"\",\"float_intro\":\"\",\"image_intro_alt\":\"\",\"image_intro_caption\":\"\",\"image_fulltext\":\"\",\"float_fulltext\":\"\",\"image_fulltext_alt\":\"\",\"image_fulltext_caption\":\"\"}','{\"urla\":false,\"urlatext\":\"\",\"targeta\":\"\",\"urlb\":false,\"urlbtext\":\"\",\"targetb\":\"\",\"urlc\":false,\"urlctext\":\"\",\"targetc\":\"\"}','{\"opencall_date\":\"\",\"news_image\":\"center\",\"news_subtitle\":\"\",\"show_title\":\"\",\"link_titles\":\"\",\"show_tags\":\"\",\"show_intro\":\"\",\"info_block_position\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_vote\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',3,5,'','',1,1745,'{\"robots\":\"\",\"author\":\"\",\"rights\":\"\",\"xreference\":\"\"}',0,'en-GB',''),(52,1933,'The kiosk','our-kiosk','<p>Every citizens’ group can make use of the synAthina kiosk for free, 365 days per year, 24 hours per day. The synAthina kiosk is located opposite the Varvakeios Market, at 55 Athinas Street, and is stretched on a bioclimatic area of 30 m², while it also provides outdoors space. Here, groups and institutions can organize and implement their activities, exchange experiences and knowledge, and meet other citizens to inform them about their projects.</p>\r\n<h4 class=\"module-title--subtitle\">How can I book the synAthina kiosk for my group’s needs?</h4>\r\n<ol>\r\n<li>I sign up on the website of synAthina.</li>\r\n<li>I check the availability of dates and times on the kiosk’s digital calendar and fill in the appropriate form.</li>\r\n<li>Ι receive confirmation of my request and the terms of use of the kiosk via e-mail.</li>\r\n</ol>','',1,2,'2016-05-26 12:31:31',233,'','2018-05-22 14:28:16',233,0,'0000-00-00 00:00:00','2016-05-26 12:31:31','0000-00-00 00:00:00','{\"image_intro\":\"\",\"float_intro\":\"\",\"image_intro_alt\":\"\",\"image_intro_caption\":\"\",\"image_fulltext\":\"\",\"float_fulltext\":\"\",\"image_fulltext_alt\":\"\",\"image_fulltext_caption\":\"\"}','{\"urla\":false,\"urlatext\":\"\",\"targeta\":\"\",\"urlb\":false,\"urlbtext\":\"\",\"targetb\":\"\",\"urlc\":false,\"urlctext\":\"\",\"targetc\":\"\"}','{\"opencall_date\":\"\",\"news_image\":\"center\",\"news_subtitle\":\"\",\"show_title\":\"\",\"link_titles\":\"\",\"show_tags\":\"\",\"show_intro\":\"\",\"info_block_position\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_vote\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',4,93,'','',1,3508,'{\"robots\":\"\",\"author\":\"\",\"rights\":\"\",\"xreference\":\"\"}',0,'en-GB',''),(53,1935,'Terms of use','terms-of-use','<p>Terms of use</p>','',1,2,'2016-03-28 14:39:29',233,'','2018-05-22 14:28:16',233,0,'0000-00-00 00:00:00','2016-03-28 14:39:29','0000-00-00 00:00:00','{\"image_intro\":\"\",\"float_intro\":\"\",\"image_intro_alt\":\"\",\"image_intro_caption\":\"\",\"image_fulltext\":\"\",\"float_fulltext\":\"\",\"image_fulltext_alt\":\"\",\"image_fulltext_caption\":\"\"}','{\"urla\":false,\"urlatext\":\"\",\"targeta\":\"\",\"urlb\":false,\"urlbtext\":\"\",\"targetb\":\"\",\"urlc\":false,\"urlctext\":\"\",\"targetc\":\"\"}','{\"news_subtitle\":\"\",\"article_video\":\"\",\"show_title\":\"\",\"link_titles\":\"\",\"show_tags\":\"\",\"show_intro\":\"\",\"info_block_position\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_vote\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',2,94,'','',1,1509,'{\"robots\":\"\",\"author\":\"\",\"rights\":\"\",\"xreference\":\"\"}',0,'*',''),(782,8615,'MIGRANTS\' INTEGRATION','ενταξη-μετανaστων-2','<p>Integra Fest 2018 is taking place from the 15th to the 18th of December in Athens.&nbsp;</p>','',1,2,'2018-12-07 14:13:09',233,'','2018-12-12 16:18:08',233,0,'0000-00-00 00:00:00','2018-12-07 14:13:09','0000-00-00 00:00:00','{\"image_intro\":\"images\\/integration.jpg\",\"float_intro\":\"\",\"image_intro_alt\":\"\",\"image_intro_caption\":\"\",\"image_fulltext\":\"\",\"float_fulltext\":\"\",\"image_fulltext_alt\":\"\",\"image_fulltext_caption\":\"\"}','{\"urla\":\"https:\\/\\/www.synathina.gr\\/el\\/%CE%B4%CF%81%CE%AC%CF%83%CE%B5%CE%B9%CF%82\\/action\\/6736-%CE%B9ntegra-fest-2018-%CE%AD%CE%BD%CE%B1%CF%82-%CE%AC%CE%BB%CE%BB%CE%BF%CF%82-%CE%B4%CF%81%CF%8C%CE%BC%CE%BF%CF%82-%CE%B3%CE%B9%CE%B1-%CF%84%CE%B7%CE%BD-%CE%AD%CE%BD%CF%84%CE%B1%CE%BE%CE%B7-15-%CE%B4%CE%B5%CE%BA%CE%B5%CE%BC%CE%B2%CF%81%CE%B9%CE%BF%CF%85-2018.html\",\"urlatext\":\"\",\"targeta\":\"\",\"urlb\":false,\"urlbtext\":\"\",\"targetb\":\"\",\"urlc\":false,\"urlctext\":\"\",\"targetc\":\"\"}','{\"homepage_text_color\":\"white\",\"opencall_date\":\"\",\"news_image\":\"center\",\"news_subtitle\":\"\",\"show_title\":\"\",\"link_titles\":\"\",\"show_tags\":\"\",\"show_intro\":\"\",\"info_block_position\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_vote\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"alternative_readmore\":\"\",\"article_layout\":\"\",\"show_publishing_options\":\"\",\"show_article_options\":\"\",\"show_urls_images_backend\":\"\",\"show_urls_images_frontend\":\"\"}',2,18,'','',1,27,'{\"robots\":\"\",\"author\":\"\",\"rights\":\"\",\"xreference\":\"\"}',1,'en-GB','');
/*!40000 ALTER TABLE `prefi_content` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prefi_content_frontpage`
--

DROP TABLE IF EXISTS `prefi_content_frontpage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `prefi_content_frontpage` (
  `content_id` int(11) NOT NULL DEFAULT '0',
  `ordering` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`content_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prefi_content_frontpage`
--

LOCK TABLES `prefi_content_frontpage` WRITE;
/*!40000 ALTER TABLE `prefi_content_frontpage` DISABLE KEYS */;
INSERT INTO `prefi_content_frontpage` VALUES (636,29),(642,30),(670,25),(671,27),(672,28),(697,26),(708,24),(709,21),(710,23),(711,20),(718,18),(719,19),(720,22),(724,17),(747,13),(749,16),(761,14),(763,15),(779,8),(780,12),(781,11),(782,10),(783,9),(789,4),(794,7),(803,5),(805,3),(808,6),(810,1),(812,2);
/*!40000 ALTER TABLE `prefi_content_frontpage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prefi_content_rating`
--

DROP TABLE IF EXISTS `prefi_content_rating`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `prefi_content_rating` (
  `content_id` int(11) NOT NULL DEFAULT '0',
  `rating_sum` int(10) unsigned NOT NULL DEFAULT '0',
  `rating_count` int(10) unsigned NOT NULL DEFAULT '0',
  `lastip` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`content_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prefi_content_rating`
--

LOCK TABLES `prefi_content_rating` WRITE;
/*!40000 ALTER TABLE `prefi_content_rating` DISABLE KEYS */;
/*!40000 ALTER TABLE `prefi_content_rating` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prefi_content_types`
--

DROP TABLE IF EXISTS `prefi_content_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `prefi_content_types` (
  `type_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type_title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `type_alias` varchar(400) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `table` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `rules` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `field_mappings` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `router` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `content_history_options` varchar(5120) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'JSON string for com_contenthistory options',
  PRIMARY KEY (`type_id`),
  KEY `idx_alias` (`type_alias`(100))
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prefi_content_types`
--

LOCK TABLES `prefi_content_types` WRITE;
/*!40000 ALTER TABLE `prefi_content_types` DISABLE KEYS */;
INSERT INTO `prefi_content_types` VALUES (1,'Article','com_content.article','{\"special\":{\"dbtable\":\"#__content\",\"key\":\"id\",\"type\":\"Content\",\"prefix\":\"JTable\",\"config\":\"array()\"},\"common\":{\"dbtable\":\"#__ucm_content\",\"key\":\"ucm_id\",\"type\":\"Corecontent\",\"prefix\":\"JTable\",\"config\":\"array()\"}}','','{\"common\":{\"core_content_item_id\":\"id\",\"core_title\":\"title\",\"core_state\":\"state\",\"core_alias\":\"alias\",\"core_created_time\":\"created\",\"core_modified_time\":\"modified\",\"core_body\":\"introtext\", \"core_hits\":\"hits\",\"core_publish_up\":\"publish_up\",\"core_publish_down\":\"publish_down\",\"core_access\":\"access\", \"core_params\":\"attribs\", \"core_featured\":\"featured\", \"core_metadata\":\"metadata\", \"core_language\":\"language\", \"core_images\":\"images\", \"core_urls\":\"urls\", \"core_version\":\"version\", \"core_ordering\":\"ordering\", \"core_metakey\":\"metakey\", \"core_metadesc\":\"metadesc\", \"core_catid\":\"catid\", \"core_xreference\":\"xreference\", \"asset_id\":\"asset_id\"}, \"special\":{\"fulltext\":\"fulltext\"}}','ContentHelperRoute::getArticleRoute','{\"formFile\":\"administrator\\/components\\/com_content\\/models\\/forms\\/article.xml\", \"hideFields\":[\"asset_id\",\"checked_out\",\"checked_out_time\",\"version\"],\"ignoreChanges\":[\"modified_by\", \"modified\", \"checked_out\", \"checked_out_time\", \"version\", \"hits\"],\"convertToInt\":[\"publish_up\", \"publish_down\", \"featured\", \"ordering\"],\"displayLookup\":[{\"sourceColumn\":\"catid\",\"targetTable\":\"#__categories\",\"targetColumn\":\"id\",\"displayColumn\":\"title\"},{\"sourceColumn\":\"created_by\",\"targetTable\":\"#__users\",\"targetColumn\":\"id\",\"displayColumn\":\"name\"},{\"sourceColumn\":\"access\",\"targetTable\":\"#__viewlevels\",\"targetColumn\":\"id\",\"displayColumn\":\"title\"},{\"sourceColumn\":\"modified_by\",\"targetTable\":\"#__users\",\"targetColumn\":\"id\",\"displayColumn\":\"name\"} ]}'),(2,'Contact','com_contact.contact','{\"special\":{\"dbtable\":\"#__contact_details\",\"key\":\"id\",\"type\":\"Contact\",\"prefix\":\"ContactTable\",\"config\":\"array()\"},\"common\":{\"dbtable\":\"#__ucm_content\",\"key\":\"ucm_id\",\"type\":\"Corecontent\",\"prefix\":\"JTable\",\"config\":\"array()\"}}','','{\"common\":{\"core_content_item_id\":\"id\",\"core_title\":\"name\",\"core_state\":\"published\",\"core_alias\":\"alias\",\"core_created_time\":\"created\",\"core_modified_time\":\"modified\",\"core_body\":\"address\", \"core_hits\":\"hits\",\"core_publish_up\":\"publish_up\",\"core_publish_down\":\"publish_down\",\"core_access\":\"access\", \"core_params\":\"params\", \"core_featured\":\"featured\", \"core_metadata\":\"metadata\", \"core_language\":\"language\", \"core_images\":\"image\", \"core_urls\":\"webpage\", \"core_version\":\"version\", \"core_ordering\":\"ordering\", \"core_metakey\":\"metakey\", \"core_metadesc\":\"metadesc\", \"core_catid\":\"catid\", \"core_xreference\":\"xreference\", \"asset_id\":\"null\"}, \"special\":{\"con_position\":\"con_position\",\"suburb\":\"suburb\",\"state\":\"state\",\"country\":\"country\",\"postcode\":\"postcode\",\"telephone\":\"telephone\",\"fax\":\"fax\",\"misc\":\"misc\",\"email_to\":\"email_to\",\"default_con\":\"default_con\",\"user_id\":\"user_id\",\"mobile\":\"mobile\",\"sortname1\":\"sortname1\",\"sortname2\":\"sortname2\",\"sortname3\":\"sortname3\"}}','ContactHelperRoute::getContactRoute','{\"formFile\":\"administrator\\/components\\/com_contact\\/models\\/forms\\/contact.xml\",\"hideFields\":[\"default_con\",\"checked_out\",\"checked_out_time\",\"version\",\"xreference\"],\"ignoreChanges\":[\"modified_by\", \"modified\", \"checked_out\", \"checked_out_time\", \"version\", \"hits\"],\"convertToInt\":[\"publish_up\", \"publish_down\", \"featured\", \"ordering\"], \"displayLookup\":[ {\"sourceColumn\":\"created_by\",\"targetTable\":\"#__users\",\"targetColumn\":\"id\",\"displayColumn\":\"name\"},{\"sourceColumn\":\"catid\",\"targetTable\":\"#__categories\",\"targetColumn\":\"id\",\"displayColumn\":\"title\"},{\"sourceColumn\":\"modified_by\",\"targetTable\":\"#__users\",\"targetColumn\":\"id\",\"displayColumn\":\"name\"},{\"sourceColumn\":\"access\",\"targetTable\":\"#__viewlevels\",\"targetColumn\":\"id\",\"displayColumn\":\"title\"},{\"sourceColumn\":\"user_id\",\"targetTable\":\"#__users\",\"targetColumn\":\"id\",\"displayColumn\":\"name\"} ] }'),(3,'Newsfeed','com_newsfeeds.newsfeed','{\"special\":{\"dbtable\":\"#__newsfeeds\",\"key\":\"id\",\"type\":\"Newsfeed\",\"prefix\":\"NewsfeedsTable\",\"config\":\"array()\"},\"common\":{\"dbtable\":\"#__ucm_content\",\"key\":\"ucm_id\",\"type\":\"Corecontent\",\"prefix\":\"JTable\",\"config\":\"array()\"}}','','{\"common\":{\"core_content_item_id\":\"id\",\"core_title\":\"name\",\"core_state\":\"published\",\"core_alias\":\"alias\",\"core_created_time\":\"created\",\"core_modified_time\":\"modified\",\"core_body\":\"description\", \"core_hits\":\"hits\",\"core_publish_up\":\"publish_up\",\"core_publish_down\":\"publish_down\",\"core_access\":\"access\", \"core_params\":\"params\", \"core_featured\":\"featured\", \"core_metadata\":\"metadata\", \"core_language\":\"language\", \"core_images\":\"images\", \"core_urls\":\"link\", \"core_version\":\"version\", \"core_ordering\":\"ordering\", \"core_metakey\":\"metakey\", \"core_metadesc\":\"metadesc\", \"core_catid\":\"catid\", \"core_xreference\":\"xreference\", \"asset_id\":\"null\"}, \"special\":{\"numarticles\":\"numarticles\",\"cache_time\":\"cache_time\",\"rtl\":\"rtl\"}}','NewsfeedsHelperRoute::getNewsfeedRoute','{\"formFile\":\"administrator\\/components\\/com_newsfeeds\\/models\\/forms\\/newsfeed.xml\",\"hideFields\":[\"asset_id\",\"checked_out\",\"checked_out_time\",\"version\"],\"ignoreChanges\":[\"modified_by\", \"modified\", \"checked_out\", \"checked_out_time\", \"version\", \"hits\"],\"convertToInt\":[\"publish_up\", \"publish_down\", \"featured\", \"ordering\"],\"displayLookup\":[{\"sourceColumn\":\"catid\",\"targetTable\":\"#__categories\",\"targetColumn\":\"id\",\"displayColumn\":\"title\"},{\"sourceColumn\":\"created_by\",\"targetTable\":\"#__users\",\"targetColumn\":\"id\",\"displayColumn\":\"name\"},{\"sourceColumn\":\"access\",\"targetTable\":\"#__viewlevels\",\"targetColumn\":\"id\",\"displayColumn\":\"title\"},{\"sourceColumn\":\"modified_by\",\"targetTable\":\"#__users\",\"targetColumn\":\"id\",\"displayColumn\":\"name\"} ]}'),(4,'User','com_users.user','{\"special\":{\"dbtable\":\"#__users\",\"key\":\"id\",\"type\":\"User\",\"prefix\":\"JTable\",\"config\":\"array()\"},\"common\":{\"dbtable\":\"#__ucm_content\",\"key\":\"ucm_id\",\"type\":\"Corecontent\",\"prefix\":\"JTable\",\"config\":\"array()\"}}','','{\"common\":{\"core_content_item_id\":\"id\",\"core_title\":\"name\",\"core_state\":\"null\",\"core_alias\":\"username\",\"core_created_time\":\"registerdate\",\"core_modified_time\":\"lastvisitDate\",\"core_body\":\"null\", \"core_hits\":\"null\",\"core_publish_up\":\"null\",\"core_publish_down\":\"null\",\"access\":\"null\", \"core_params\":\"params\", \"core_featured\":\"null\", \"core_metadata\":\"null\", \"core_language\":\"null\", \"core_images\":\"null\", \"core_urls\":\"null\", \"core_version\":\"null\", \"core_ordering\":\"null\", \"core_metakey\":\"null\", \"core_metadesc\":\"null\", \"core_catid\":\"null\", \"core_xreference\":\"null\", \"asset_id\":\"null\"}, \"special\":{}}','UsersHelperRoute::getUserRoute',''),(5,'Article Category','com_content.category','{\"special\":{\"dbtable\":\"#__categories\",\"key\":\"id\",\"type\":\"Category\",\"prefix\":\"JTable\",\"config\":\"array()\"},\"common\":{\"dbtable\":\"#__ucm_content\",\"key\":\"ucm_id\",\"type\":\"Corecontent\",\"prefix\":\"JTable\",\"config\":\"array()\"}}','','{\"common\":{\"core_content_item_id\":\"id\",\"core_title\":\"title\",\"core_state\":\"published\",\"core_alias\":\"alias\",\"core_created_time\":\"created_time\",\"core_modified_time\":\"modified_time\",\"core_body\":\"description\", \"core_hits\":\"hits\",\"core_publish_up\":\"null\",\"core_publish_down\":\"null\",\"core_access\":\"access\", \"core_params\":\"params\", \"core_featured\":\"null\", \"core_metadata\":\"metadata\", \"core_language\":\"language\", \"core_images\":\"null\", \"core_urls\":\"null\", \"core_version\":\"version\", \"core_ordering\":\"null\", \"core_metakey\":\"metakey\", \"core_metadesc\":\"metadesc\", \"core_catid\":\"parent_id\", \"core_xreference\":\"null\", \"asset_id\":\"asset_id\"}, \"special\":{\"parent_id\":\"parent_id\",\"lft\":\"lft\",\"rgt\":\"rgt\",\"level\":\"level\",\"path\":\"path\",\"extension\":\"extension\",\"note\":\"note\"}}','ContentHelperRoute::getCategoryRoute','{\"formFile\":\"administrator\\/components\\/com_categories\\/models\\/forms\\/category.xml\", \"hideFields\":[\"asset_id\",\"checked_out\",\"checked_out_time\",\"version\",\"lft\",\"rgt\",\"level\",\"path\",\"extension\"], \"ignoreChanges\":[\"modified_user_id\", \"modified_time\", \"checked_out\", \"checked_out_time\", \"version\", \"hits\", \"path\"],\"convertToInt\":[\"publish_up\", \"publish_down\"], \"displayLookup\":[{\"sourceColumn\":\"created_user_id\",\"targetTable\":\"#__users\",\"targetColumn\":\"id\",\"displayColumn\":\"name\"},{\"sourceColumn\":\"access\",\"targetTable\":\"#__viewlevels\",\"targetColumn\":\"id\",\"displayColumn\":\"title\"},{\"sourceColumn\":\"modified_user_id\",\"targetTable\":\"#__users\",\"targetColumn\":\"id\",\"displayColumn\":\"name\"},{\"sourceColumn\":\"parent_id\",\"targetTable\":\"#__categories\",\"targetColumn\":\"id\",\"displayColumn\":\"title\"}]}'),(6,'Contact Category','com_contact.category','{\"special\":{\"dbtable\":\"#__categories\",\"key\":\"id\",\"type\":\"Category\",\"prefix\":\"JTable\",\"config\":\"array()\"},\"common\":{\"dbtable\":\"#__ucm_content\",\"key\":\"ucm_id\",\"type\":\"Corecontent\",\"prefix\":\"JTable\",\"config\":\"array()\"}}','','{\"common\":{\"core_content_item_id\":\"id\",\"core_title\":\"title\",\"core_state\":\"published\",\"core_alias\":\"alias\",\"core_created_time\":\"created_time\",\"core_modified_time\":\"modified_time\",\"core_body\":\"description\", \"core_hits\":\"hits\",\"core_publish_up\":\"null\",\"core_publish_down\":\"null\",\"core_access\":\"access\", \"core_params\":\"params\", \"core_featured\":\"null\", \"core_metadata\":\"metadata\", \"core_language\":\"language\", \"core_images\":\"null\", \"core_urls\":\"null\", \"core_version\":\"version\", \"core_ordering\":\"null\", \"core_metakey\":\"metakey\", \"core_metadesc\":\"metadesc\", \"core_catid\":\"parent_id\", \"core_xreference\":\"null\", \"asset_id\":\"asset_id\"}, \"special\":{\"parent_id\":\"parent_id\",\"lft\":\"lft\",\"rgt\":\"rgt\",\"level\":\"level\",\"path\":\"path\",\"extension\":\"extension\",\"note\":\"note\"}}','ContactHelperRoute::getCategoryRoute','{\"formFile\":\"administrator\\/components\\/com_categories\\/models\\/forms\\/category.xml\", \"hideFields\":[\"asset_id\",\"checked_out\",\"checked_out_time\",\"version\",\"lft\",\"rgt\",\"level\",\"path\",\"extension\"], \"ignoreChanges\":[\"modified_user_id\", \"modified_time\", \"checked_out\", \"checked_out_time\", \"version\", \"hits\", \"path\"],\"convertToInt\":[\"publish_up\", \"publish_down\"], \"displayLookup\":[{\"sourceColumn\":\"created_user_id\",\"targetTable\":\"#__users\",\"targetColumn\":\"id\",\"displayColumn\":\"name\"},{\"sourceColumn\":\"access\",\"targetTable\":\"#__viewlevels\",\"targetColumn\":\"id\",\"displayColumn\":\"title\"},{\"sourceColumn\":\"modified_user_id\",\"targetTable\":\"#__users\",\"targetColumn\":\"id\",\"displayColumn\":\"name\"},{\"sourceColumn\":\"parent_id\",\"targetTable\":\"#__categories\",\"targetColumn\":\"id\",\"displayColumn\":\"title\"}]}'),(7,'Newsfeeds Category','com_newsfeeds.category','{\"special\":{\"dbtable\":\"#__categories\",\"key\":\"id\",\"type\":\"Category\",\"prefix\":\"JTable\",\"config\":\"array()\"},\"common\":{\"dbtable\":\"#__ucm_content\",\"key\":\"ucm_id\",\"type\":\"Corecontent\",\"prefix\":\"JTable\",\"config\":\"array()\"}}','','{\"common\":{\"core_content_item_id\":\"id\",\"core_title\":\"title\",\"core_state\":\"published\",\"core_alias\":\"alias\",\"core_created_time\":\"created_time\",\"core_modified_time\":\"modified_time\",\"core_body\":\"description\", \"core_hits\":\"hits\",\"core_publish_up\":\"null\",\"core_publish_down\":\"null\",\"core_access\":\"access\", \"core_params\":\"params\", \"core_featured\":\"null\", \"core_metadata\":\"metadata\", \"core_language\":\"language\", \"core_images\":\"null\", \"core_urls\":\"null\", \"core_version\":\"version\", \"core_ordering\":\"null\", \"core_metakey\":\"metakey\", \"core_metadesc\":\"metadesc\", \"core_catid\":\"parent_id\", \"core_xreference\":\"null\", \"asset_id\":\"asset_id\"}, \"special\":{\"parent_id\":\"parent_id\",\"lft\":\"lft\",\"rgt\":\"rgt\",\"level\":\"level\",\"path\":\"path\",\"extension\":\"extension\",\"note\":\"note\"}}','NewsfeedsHelperRoute::getCategoryRoute','{\"formFile\":\"administrator\\/components\\/com_categories\\/models\\/forms\\/category.xml\", \"hideFields\":[\"asset_id\",\"checked_out\",\"checked_out_time\",\"version\",\"lft\",\"rgt\",\"level\",\"path\",\"extension\"], \"ignoreChanges\":[\"modified_user_id\", \"modified_time\", \"checked_out\", \"checked_out_time\", \"version\", \"hits\", \"path\"],\"convertToInt\":[\"publish_up\", \"publish_down\"], \"displayLookup\":[{\"sourceColumn\":\"created_user_id\",\"targetTable\":\"#__users\",\"targetColumn\":\"id\",\"displayColumn\":\"name\"},{\"sourceColumn\":\"access\",\"targetTable\":\"#__viewlevels\",\"targetColumn\":\"id\",\"displayColumn\":\"title\"},{\"sourceColumn\":\"modified_user_id\",\"targetTable\":\"#__users\",\"targetColumn\":\"id\",\"displayColumn\":\"name\"},{\"sourceColumn\":\"parent_id\",\"targetTable\":\"#__categories\",\"targetColumn\":\"id\",\"displayColumn\":\"title\"}]}'),(8,'Tag','com_tags.tag','{\"special\":{\"dbtable\":\"#__tags\",\"key\":\"tag_id\",\"type\":\"Tag\",\"prefix\":\"TagsTable\",\"config\":\"array()\"},\"common\":{\"dbtable\":\"#__ucm_content\",\"key\":\"ucm_id\",\"type\":\"Corecontent\",\"prefix\":\"JTable\",\"config\":\"array()\"}}','','{\"common\":{\"core_content_item_id\":\"id\",\"core_title\":\"title\",\"core_state\":\"published\",\"core_alias\":\"alias\",\"core_created_time\":\"created_time\",\"core_modified_time\":\"modified_time\",\"core_body\":\"description\", \"core_hits\":\"hits\",\"core_publish_up\":\"null\",\"core_publish_down\":\"null\",\"core_access\":\"access\", \"core_params\":\"params\", \"core_featured\":\"featured\", \"core_metadata\":\"metadata\", \"core_language\":\"language\", \"core_images\":\"images\", \"core_urls\":\"urls\", \"core_version\":\"version\", \"core_ordering\":\"null\", \"core_metakey\":\"metakey\", \"core_metadesc\":\"metadesc\", \"core_catid\":\"null\", \"core_xreference\":\"null\", \"asset_id\":\"null\"}, \"special\":{\"parent_id\":\"parent_id\",\"lft\":\"lft\",\"rgt\":\"rgt\",\"level\":\"level\",\"path\":\"path\"}}','TagsHelperRoute::getTagRoute','{\"formFile\":\"administrator\\/components\\/com_tags\\/models\\/forms\\/tag.xml\", \"hideFields\":[\"checked_out\",\"checked_out_time\",\"version\", \"lft\", \"rgt\", \"level\", \"path\", \"urls\", \"publish_up\", \"publish_down\"],\"ignoreChanges\":[\"modified_user_id\", \"modified_time\", \"checked_out\", \"checked_out_time\", \"version\", \"hits\", \"path\"],\"convertToInt\":[\"publish_up\", \"publish_down\"], \"displayLookup\":[{\"sourceColumn\":\"created_user_id\",\"targetTable\":\"#__users\",\"targetColumn\":\"id\",\"displayColumn\":\"name\"}, {\"sourceColumn\":\"access\",\"targetTable\":\"#__viewlevels\",\"targetColumn\":\"id\",\"displayColumn\":\"title\"}, {\"sourceColumn\":\"modified_user_id\",\"targetTable\":\"#__users\",\"targetColumn\":\"id\",\"displayColumn\":\"name\"}]}'),(9,'Banner','com_banners.banner','{\"special\":{\"dbtable\":\"#__banners\",\"key\":\"id\",\"type\":\"Banner\",\"prefix\":\"BannersTable\",\"config\":\"array()\"},\"common\":{\"dbtable\":\"#__ucm_content\",\"key\":\"ucm_id\",\"type\":\"Corecontent\",\"prefix\":\"JTable\",\"config\":\"array()\"}}','','{\"common\":{\"core_content_item_id\":\"id\",\"core_title\":\"name\",\"core_state\":\"published\",\"core_alias\":\"alias\",\"core_created_time\":\"created\",\"core_modified_time\":\"modified\",\"core_body\":\"description\", \"core_hits\":\"null\",\"core_publish_up\":\"publish_up\",\"core_publish_down\":\"publish_down\",\"core_access\":\"access\", \"core_params\":\"params\", \"core_featured\":\"null\", \"core_metadata\":\"metadata\", \"core_language\":\"language\", \"core_images\":\"images\", \"core_urls\":\"link\", \"core_version\":\"version\", \"core_ordering\":\"ordering\", \"core_metakey\":\"metakey\", \"core_metadesc\":\"metadesc\", \"core_catid\":\"catid\", \"core_xreference\":\"null\", \"asset_id\":\"null\"}, \"special\":{\"imptotal\":\"imptotal\", \"impmade\":\"impmade\", \"clicks\":\"clicks\", \"clickurl\":\"clickurl\", \"custombannercode\":\"custombannercode\", \"cid\":\"cid\", \"purchase_type\":\"purchase_type\", \"track_impressions\":\"track_impressions\", \"track_clicks\":\"track_clicks\"}}','','{\"formFile\":\"administrator\\/components\\/com_banners\\/models\\/forms\\/banner.xml\", \"hideFields\":[\"checked_out\",\"checked_out_time\",\"version\", \"reset\"],\"ignoreChanges\":[\"modified_by\", \"modified\", \"checked_out\", \"checked_out_time\", \"version\", \"imptotal\", \"impmade\", \"reset\"], \"convertToInt\":[\"publish_up\", \"publish_down\", \"ordering\"], \"displayLookup\":[{\"sourceColumn\":\"catid\",\"targetTable\":\"#__categories\",\"targetColumn\":\"id\",\"displayColumn\":\"title\"}, {\"sourceColumn\":\"cid\",\"targetTable\":\"#__banner_clients\",\"targetColumn\":\"id\",\"displayColumn\":\"name\"}, {\"sourceColumn\":\"created_by\",\"targetTable\":\"#__users\",\"targetColumn\":\"id\",\"displayColumn\":\"name\"},{\"sourceColumn\":\"modified_by\",\"targetTable\":\"#__users\",\"targetColumn\":\"id\",\"displayColumn\":\"name\"} ]}'),(10,'Banners Category','com_banners.category','{\"special\":{\"dbtable\":\"#__categories\",\"key\":\"id\",\"type\":\"Category\",\"prefix\":\"JTable\",\"config\":\"array()\"},\"common\":{\"dbtable\":\"#__ucm_content\",\"key\":\"ucm_id\",\"type\":\"Corecontent\",\"prefix\":\"JTable\",\"config\":\"array()\"}}','','{\"common\":{\"core_content_item_id\":\"id\",\"core_title\":\"title\",\"core_state\":\"published\",\"core_alias\":\"alias\",\"core_created_time\":\"created_time\",\"core_modified_time\":\"modified_time\",\"core_body\":\"description\", \"core_hits\":\"hits\",\"core_publish_up\":\"null\",\"core_publish_down\":\"null\",\"core_access\":\"access\", \"core_params\":\"params\", \"core_featured\":\"null\", \"core_metadata\":\"metadata\", \"core_language\":\"language\", \"core_images\":\"null\", \"core_urls\":\"null\", \"core_version\":\"version\", \"core_ordering\":\"null\", \"core_metakey\":\"metakey\", \"core_metadesc\":\"metadesc\", \"core_catid\":\"parent_id\", \"core_xreference\":\"null\", \"asset_id\":\"asset_id\"}, \"special\": {\"parent_id\":\"parent_id\",\"lft\":\"lft\",\"rgt\":\"rgt\",\"level\":\"level\",\"path\":\"path\",\"extension\":\"extension\",\"note\":\"note\"}}','','{\"formFile\":\"administrator\\/components\\/com_categories\\/models\\/forms\\/category.xml\", \"hideFields\":[\"asset_id\",\"checked_out\",\"checked_out_time\",\"version\",\"lft\",\"rgt\",\"level\",\"path\",\"extension\"], \"ignoreChanges\":[\"modified_user_id\", \"modified_time\", \"checked_out\", \"checked_out_time\", \"version\", \"hits\", \"path\"], \"convertToInt\":[\"publish_up\", \"publish_down\"], \"displayLookup\":[{\"sourceColumn\":\"created_user_id\",\"targetTable\":\"#__users\",\"targetColumn\":\"id\",\"displayColumn\":\"name\"},{\"sourceColumn\":\"access\",\"targetTable\":\"#__viewlevels\",\"targetColumn\":\"id\",\"displayColumn\":\"title\"},{\"sourceColumn\":\"modified_user_id\",\"targetTable\":\"#__users\",\"targetColumn\":\"id\",\"displayColumn\":\"name\"},{\"sourceColumn\":\"parent_id\",\"targetTable\":\"#__categories\",\"targetColumn\":\"id\",\"displayColumn\":\"title\"}]}'),(11,'Banner Client','com_banners.client','{\"special\":{\"dbtable\":\"#__banner_clients\",\"key\":\"id\",\"type\":\"Client\",\"prefix\":\"BannersTable\"}}','','','','{\"formFile\":\"administrator\\/components\\/com_banners\\/models\\/forms\\/client.xml\", \"hideFields\":[\"checked_out\",\"checked_out_time\"], \"ignoreChanges\":[\"checked_out\", \"checked_out_time\"], \"convertToInt\":[], \"displayLookup\":[]}'),(12,'User Notes','com_users.note','{\"special\":{\"dbtable\":\"#__user_notes\",\"key\":\"id\",\"type\":\"Note\",\"prefix\":\"UsersTable\"}}','','','','{\"formFile\":\"administrator\\/components\\/com_users\\/models\\/forms\\/note.xml\", \"hideFields\":[\"checked_out\",\"checked_out_time\", \"publish_up\", \"publish_down\"],\"ignoreChanges\":[\"modified_user_id\", \"modified_time\", \"checked_out\", \"checked_out_time\"], \"convertToInt\":[\"publish_up\", \"publish_down\"],\"displayLookup\":[{\"sourceColumn\":\"catid\",\"targetTable\":\"#__categories\",\"targetColumn\":\"id\",\"displayColumn\":\"title\"}, {\"sourceColumn\":\"created_user_id\",\"targetTable\":\"#__users\",\"targetColumn\":\"id\",\"displayColumn\":\"name\"}, {\"sourceColumn\":\"user_id\",\"targetTable\":\"#__users\",\"targetColumn\":\"id\",\"displayColumn\":\"name\"}, {\"sourceColumn\":\"modified_user_id\",\"targetTable\":\"#__users\",\"targetColumn\":\"id\",\"displayColumn\":\"name\"}]}'),(13,'User Notes Category','com_users.category','{\"special\":{\"dbtable\":\"#__categories\",\"key\":\"id\",\"type\":\"Category\",\"prefix\":\"JTable\",\"config\":\"array()\"},\"common\":{\"dbtable\":\"#__ucm_content\",\"key\":\"ucm_id\",\"type\":\"Corecontent\",\"prefix\":\"JTable\",\"config\":\"array()\"}}','','{\"common\":{\"core_content_item_id\":\"id\",\"core_title\":\"title\",\"core_state\":\"published\",\"core_alias\":\"alias\",\"core_created_time\":\"created_time\",\"core_modified_time\":\"modified_time\",\"core_body\":\"description\", \"core_hits\":\"hits\",\"core_publish_up\":\"null\",\"core_publish_down\":\"null\",\"core_access\":\"access\", \"core_params\":\"params\", \"core_featured\":\"null\", \"core_metadata\":\"metadata\", \"core_language\":\"language\", \"core_images\":\"null\", \"core_urls\":\"null\", \"core_version\":\"version\", \"core_ordering\":\"null\", \"core_metakey\":\"metakey\", \"core_metadesc\":\"metadesc\", \"core_catid\":\"parent_id\", \"core_xreference\":\"null\", \"asset_id\":\"asset_id\"}, \"special\":{\"parent_id\":\"parent_id\",\"lft\":\"lft\",\"rgt\":\"rgt\",\"level\":\"level\",\"path\":\"path\",\"extension\":\"extension\",\"note\":\"note\"}}','','{\"formFile\":\"administrator\\/components\\/com_categories\\/models\\/forms\\/category.xml\", \"hideFields\":[\"checked_out\",\"checked_out_time\",\"version\",\"lft\",\"rgt\",\"level\",\"path\",\"extension\"], \"ignoreChanges\":[\"modified_user_id\", \"modified_time\", \"checked_out\", \"checked_out_time\", \"version\", \"hits\", \"path\"], \"convertToInt\":[\"publish_up\", \"publish_down\"], \"displayLookup\":[{\"sourceColumn\":\"created_user_id\",\"targetTable\":\"#__users\",\"targetColumn\":\"id\",\"displayColumn\":\"name\"}, {\"sourceColumn\":\"access\",\"targetTable\":\"#__viewlevels\",\"targetColumn\":\"id\",\"displayColumn\":\"title\"},{\"sourceColumn\":\"modified_user_id\",\"targetTable\":\"#__users\",\"targetColumn\":\"id\",\"displayColumn\":\"name\"},{\"sourceColumn\":\"parent_id\",\"targetTable\":\"#__categories\",\"targetColumn\":\"id\",\"displayColumn\":\"title\"}]}');
/*!40000 ALTER TABLE `prefi_content_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prefi_contentitem_tag_map`
--

DROP TABLE IF EXISTS `prefi_contentitem_tag_map`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `prefi_contentitem_tag_map` (
  `type_alias` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `core_content_id` int(10) unsigned NOT NULL COMMENT 'PK from the core content table',
  `content_item_id` int(11) NOT NULL COMMENT 'PK from the content type table',
  `tag_id` int(10) unsigned NOT NULL COMMENT 'PK from the tag table',
  `tag_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Date of most recent save for this tag-item',
  `type_id` mediumint(8) NOT NULL COMMENT 'PK from the content_type table',
  UNIQUE KEY `uc_ItemnameTagid` (`type_id`,`content_item_id`,`tag_id`),
  KEY `idx_tag_type` (`tag_id`,`type_id`),
  KEY `idx_date_id` (`tag_date`,`tag_id`),
  KEY `idx_core_content_id` (`core_content_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Maps items from content tables to tags';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prefi_contentitem_tag_map`
--

LOCK TABLES `prefi_contentitem_tag_map` WRITE;
/*!40000 ALTER TABLE `prefi_contentitem_tag_map` DISABLE KEYS */;
INSERT INTO `prefi_contentitem_tag_map` VALUES ('com_content.article',11,336,2,'2018-05-14 17:25:32',1),('com_content.article',11,336,35,'2018-05-14 17:25:32',1),('com_content.article',11,336,37,'2018-05-14 17:25:32',1),('com_content.article',11,336,38,'2018-05-14 17:25:32',1),('com_content.article',1,337,2,'2016-07-08 18:50:24',1),('com_content.article',1,337,3,'2016-07-08 18:50:24',1),('com_content.article',1,337,4,'2016-07-08 18:50:24',1),('com_content.article',1,337,5,'2016-07-08 18:50:24',1),('com_content.article',2,338,2,'2018-05-14 17:25:32',1),('com_content.article',2,338,3,'2018-05-14 17:25:32',1),('com_content.article',2,338,6,'2018-05-14 17:25:32',1),('com_content.article',2,338,7,'2018-05-14 17:25:32',1),('com_content.article',2,338,8,'2018-05-14 17:25:32',1),('com_content.article',2,338,9,'2018-05-14 17:25:32',1),('com_content.article',8,339,2,'2018-05-14 17:25:32',1),('com_content.article',8,339,30,'2018-05-14 17:25:32',1),('com_content.article',8,339,31,'2018-05-14 17:25:32',1),('com_content.article',8,339,32,'2018-05-14 17:25:32',1),('com_content.article',8,339,33,'2018-05-14 17:25:32',1),('com_content.article',3,341,2,'2018-05-14 17:25:31',1),('com_content.article',3,341,10,'2018-05-14 17:25:31',1),('com_content.article',3,341,11,'2018-05-14 17:25:31',1),('com_content.article',3,341,12,'2018-05-14 17:25:31',1),('com_content.article',3,341,13,'2018-05-14 17:25:31',1),('com_content.article',3,341,14,'2018-05-14 17:25:31',1),('com_content.article',3,341,15,'2018-05-14 17:25:31',1),('com_content.article',4,342,2,'2018-05-14 17:25:31',1),('com_content.article',4,342,16,'2018-05-14 17:25:31',1),('com_content.article',4,342,17,'2018-05-14 17:25:31',1),('com_content.article',5,344,2,'2016-07-08 21:00:55',1),('com_content.article',5,344,18,'2016-07-08 21:00:55',1),('com_content.article',5,344,19,'2016-07-08 21:00:55',1),('com_content.article',5,344,20,'2016-07-08 21:00:55',1),('com_content.article',5,344,21,'2016-07-08 21:00:55',1),('com_content.article',5,344,22,'2016-07-08 21:00:55',1),('com_content.article',5,344,23,'2016-07-08 21:00:55',1),('com_content.article',6,345,2,'2018-05-14 17:25:31',1),('com_content.article',6,345,13,'2018-05-14 17:25:31',1),('com_content.article',6,345,24,'2018-05-14 17:25:31',1),('com_content.article',6,345,25,'2018-05-14 17:25:31',1),('com_content.article',7,346,2,'2016-07-08 21:40:32',1),('com_content.article',7,346,20,'2016-07-08 21:40:32',1),('com_content.article',7,346,26,'2016-07-08 21:40:32',1),('com_content.article',7,346,27,'2016-07-08 21:40:32',1),('com_content.article',7,346,28,'2016-07-08 21:40:32',1),('com_content.article',7,346,29,'2016-07-08 21:40:32',1),('com_content.article',7,346,30,'2016-07-08 21:40:32',1),('com_content.article',9,348,2,'2018-05-14 17:25:31',1),('com_content.article',9,348,19,'2018-05-14 17:25:31',1),('com_content.article',9,348,20,'2018-05-14 17:25:31',1),('com_content.article',9,348,22,'2018-05-14 17:25:31',1),('com_content.article',9,348,34,'2018-05-14 17:25:31',1),('com_content.article',9,348,35,'2018-05-14 17:25:31',1),('com_content.article',10,352,2,'2016-07-12 22:38:26',1),('com_content.article',10,352,13,'2016-07-12 22:38:26',1),('com_content.article',10,352,36,'2016-07-12 22:38:26',1),('com_content.article',12,359,2,'2016-07-29 10:37:50',1),('com_content.article',12,359,39,'2016-07-29 10:37:50',1),('com_content.article',12,359,40,'2016-07-29 10:37:50',1),('com_content.article',13,360,2,'2018-05-14 17:25:30',1),('com_content.article',13,360,41,'2018-05-14 17:25:30',1),('com_content.article',13,360,42,'2018-05-14 17:25:30',1),('com_content.article',13,360,43,'2018-05-14 17:25:30',1),('com_content.article',13,360,44,'2018-05-14 17:25:30',1),('com_content.article',13,360,45,'2018-05-14 17:25:30',1),('com_content.article',13,360,46,'2018-05-14 17:25:30',1),('com_content.article',13,360,47,'2018-05-14 17:25:30',1),('com_content.article',14,361,2,'2018-05-14 17:25:30',1),('com_content.article',14,361,48,'2018-05-14 17:25:30',1),('com_content.article',15,373,2,'2016-09-21 09:31:23',1),('com_content.article',15,373,32,'2016-09-21 09:31:23',1),('com_content.article',16,374,2,'2016-09-28 12:35:57',1),('com_content.article',16,374,30,'2016-09-28 12:35:57',1),('com_content.article',16,374,49,'2016-09-28 12:35:57',1),('com_content.article',17,375,2,'2016-10-04 12:25:13',1),('com_content.article',17,375,50,'2016-10-04 12:25:13',1),('com_content.article',17,375,51,'2016-10-04 12:25:13',1),('com_content.article',18,377,2,'2016-10-05 14:16:51',1),('com_content.article',18,377,13,'2016-10-05 14:16:51',1),('com_content.article',18,377,52,'2016-10-05 14:16:51',1),('com_content.article',19,379,2,'2018-05-14 17:25:29',1),('com_content.article',19,379,53,'2018-05-14 17:25:29',1),('com_content.article',19,379,54,'2018-05-14 17:25:29',1),('com_content.article',19,379,55,'2018-05-14 17:25:29',1),('com_content.article',19,379,56,'2018-05-14 17:25:29',1),('com_content.article',19,379,57,'2018-05-14 17:25:29',1),('com_content.article',20,381,2,'2016-10-14 11:58:08',1),('com_content.article',20,381,32,'2016-10-14 11:58:08',1),('com_content.article',21,382,2,'2016-10-18 09:10:06',1),('com_content.article',21,382,50,'2016-10-18 09:10:06',1),('com_content.article',21,382,58,'2016-10-18 09:10:06',1),('com_content.article',21,382,59,'2016-10-18 09:10:06',1),('com_content.article',22,384,2,'2018-05-14 17:25:29',1),('com_content.article',22,384,3,'2018-05-14 17:25:29',1),('com_content.article',22,384,40,'2018-05-14 17:25:29',1),('com_content.article',22,384,60,'2018-05-14 17:25:29',1),('com_content.article',22,384,61,'2018-05-14 17:25:29',1),('com_content.article',22,384,62,'2018-05-14 17:25:29',1),('com_content.article',23,385,2,'2016-10-26 12:40:06',1),('com_content.article',23,385,13,'2016-10-26 12:40:06',1),('com_content.article',23,385,63,'2016-10-26 12:40:06',1),('com_content.article',24,387,2,'2018-05-14 17:25:29',1),('com_content.article',24,387,64,'2018-05-14 17:25:29',1),('com_content.article',24,387,65,'2018-05-14 17:25:29',1),('com_content.article',25,388,2,'2018-05-14 17:25:28',1),('com_content.article',25,388,66,'2018-05-14 17:25:28',1),('com_content.article',26,391,2,'2016-11-11 10:56:17',1),('com_content.article',26,391,6,'2016-11-11 10:56:17',1),('com_content.article',26,391,67,'2016-11-11 10:56:17',1),('com_content.article',27,392,2,'2016-11-11 14:49:26',1),('com_content.article',27,392,68,'2016-11-11 14:49:26',1),('com_content.article',27,392,69,'2016-11-11 14:49:26',1),('com_content.article',28,397,2,'2016-11-18 09:34:24',1),('com_content.article',28,397,60,'2016-11-18 09:34:24',1),('com_content.article',29,398,2,'2016-11-23 10:39:53',1),('com_content.article',29,398,70,'2016-11-23 10:39:53',1),('com_content.article',30,399,2,'2016-11-22 16:45:23',1),('com_content.article',30,399,13,'2016-11-22 16:45:23',1),('com_content.article',30,399,68,'2016-11-22 16:45:23',1),('com_content.article',30,399,71,'2016-11-22 16:45:23',1),('com_content.article',31,400,2,'2016-11-28 11:48:10',1),('com_content.article',31,400,13,'2016-11-28 11:48:10',1),('com_content.article',31,400,45,'2016-11-28 11:48:10',1),('com_content.article',32,401,2,'2016-12-04 10:17:14',1),('com_content.article',32,401,13,'2016-12-04 10:17:14',1),('com_content.article',32,401,72,'2016-12-04 10:17:14',1),('com_content.article',33,402,2,'2016-12-02 15:20:42',1),('com_content.article',33,402,52,'2016-12-02 15:20:42',1),('com_content.article',33,402,73,'2016-12-02 15:20:42',1),('com_content.article',34,403,2,'2018-05-14 17:25:28',1),('com_content.article',34,403,20,'2018-05-14 17:25:28',1),('com_content.article',34,403,22,'2018-05-14 17:25:28',1),('com_content.article',34,403,50,'2018-05-14 17:25:28',1),('com_content.article',34,403,74,'2018-05-14 17:25:28',1),('com_content.article',34,403,75,'2018-05-14 17:25:28',1);
/*!40000 ALTER TABLE `prefi_contentitem_tag_map` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prefi_core_log_searches`
--

DROP TABLE IF EXISTS `prefi_core_log_searches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `prefi_core_log_searches` (
  `search_term` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `hits` int(10) unsigned NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prefi_core_log_searches`
--

LOCK TABLES `prefi_core_log_searches` WRITE;
/*!40000 ALTER TABLE `prefi_core_log_searches` DISABLE KEYS */;
/*!40000 ALTER TABLE `prefi_core_log_searches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prefi_di_images`
--

DROP TABLE IF EXISTS `prefi_di_images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `prefi_di_images` (
  `object_image_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `object_id` double(10,0) DEFAULT NULL,
  `state` tinyint(1) NOT NULL DEFAULT '1',
  `filename` varchar(255) NOT NULL DEFAULT '',
  `title` varchar(255) DEFAULT NULL,
  `description` text,
  `featured` tinyint(1) DEFAULT '0',
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ordering` int(10) unsigned DEFAULT NULL,
  `link` text,
  `link_target` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`object_image_id`),
  KEY `object_id_x` (`object_id`),
  KEY `state_x` (`state`)
) ENGINE=InnoDB AUTO_INCREMENT=1629 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prefi_di_images`
--

LOCK TABLES `prefi_di_images` WRITE;
/*!40000 ALTER TABLE `prefi_di_images` DISABLE KEYS */;
/*!40000 ALTER TABLE `prefi_di_images` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prefi_di_images_sizes`
--

DROP TABLE IF EXISTS `prefi_di_images_sizes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `prefi_di_images_sizes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `template_id` varchar(150) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `indent` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
  `height` int(10) NOT NULL DEFAULT '0',
  `width` int(10) NOT NULL DEFAULT '0',
  `crop` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `template_id_x` (`template_id`),
  KEY `indent_x` (`indent`)
) ENGINE=InnoDB AUTO_INCREMENT=104 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prefi_di_images_sizes`
--

LOCK TABLES `prefi_di_images_sizes` WRITE;
/*!40000 ALTER TABLE `prefi_di_images_sizes` DISABLE KEYS */;
INSERT INTO `prefi_di_images_sizes` VALUES (101,'default','thumb',100,1000,0),(102,'default','regular',250,250,1),(103,'default','zoomed',0,800,1);
/*!40000 ALTER TABLE `prefi_di_images_sizes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prefi_donations_counter`
--

DROP TABLE IF EXISTS `prefi_donations_counter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `prefi_donations_counter` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `counter` varchar(20) NOT NULL,
  `donations` varchar(150) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prefi_donations_counter`
--

LOCK TABLES `prefi_donations_counter` WRITE;
/*!40000 ALTER TABLE `prefi_donations_counter` DISABLE KEYS */;
INSERT INTO `prefi_donations_counter` VALUES (1,'2018-03-06 21:46:25','2','36'),(2,'2018-03-19 09:45:35','61','27'),(3,'2018-03-26 15:31:45','7','5'),(4,'2018-03-29 12:00:34','15','28'),(5,'2018-04-11 14:12:30','29','20'),(6,'2018-04-11 14:12:42','15','28'),(7,'2018-04-11 14:12:48','7','32'),(8,'2018-04-11 14:54:02','13','3'),(9,'2018-04-11 14:54:08','3','13'),(10,'2018-04-11 14:54:09','22','19'),(11,'2018-04-11 14:54:18','29','20'),(12,'2018-04-11 14:54:30','15','28'),(13,'2018-04-11 14:54:37','2','36'),(14,'2018-04-29 19:31:11','9','4'),(15,'2018-04-29 19:31:15','16','6'),(16,'2018-04-29 19:31:21','22','7'),(17,'2018-04-29 19:31:30','18','10'),(18,'2018-04-29 19:31:37','10','11'),(19,'2018-04-29 19:31:41','13','12'),(20,'2018-04-29 19:31:46','70','27'),(21,'2018-04-29 19:32:14','17','28'),(22,'2018-04-29 19:32:20','5','35'),(23,'2018-04-29 19:32:22','3','36'),(24,'2018-05-11 23:06:31','16','28'),(25,'2018-05-22 14:48:16','7','22'),(26,'2018-05-22 14:48:19','6','26'),(27,'2018-05-22 14:48:21','16','28'),(28,'2018-05-23 16:09:48','16','28'),(29,'2018-06-05 13:41:19','8','9'),(30,'2018-09-18 12:14:44','10','11'),(31,'2018-09-18 12:14:49','4','13'),(32,'2018-09-18 12:14:51','23','19'),(33,'2018-09-18 12:15:01','8','22'),(34,'2018-09-18 12:15:04','68','27'),(35,'2018-09-18 12:15:38','16','28'),(36,'2018-09-27 14:04:53','16','28');
/*!40000 ALTER TABLE `prefi_donations_counter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prefi_emails`
--

DROP TABLE IF EXISTS `prefi_emails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `prefi_emails` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(100) NOT NULL,
  `from_name` varchar(100) NOT NULL,
  `from_email` varchar(200) NOT NULL,
  `to_email` varchar(300) NOT NULL,
  `subject` varchar(500) NOT NULL,
  `email_title` varchar(150) NOT NULL,
  `body` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prefi_emails`
--

LOCK TABLES `prefi_emails` WRITE;
/*!40000 ALTER TABLE `prefi_emails` DISABLE KEYS */;
INSERT INTO `prefi_emails` VALUES (1,'team_activate','','','','ενεργοποίηση ομάδας','','κείμενο ενεργοποίησης ομάδας'),(2,'open_call_user','Συναθηνά','info@synathina.gr','','To open call σας έχει καταχωριστεί στο www.synathina.gr','Open Call','<p>Το open call σας έχει καταχωριστεί με επιτυχία στην παρακάτω διεύθυνση:<br /><a href=\"%s1\">%s1</a></p>\r\n<p>Εάν θέλετε να επεξεργαστείτε το open call για να προσθέσετε ενεργούς συνδέσμους ή να αλλάξετε τα στοιχεία του, μπορείτε να κάνετε κλικ στο \"Επεξεργασία open calls\" που βρίσκεται στο \"O λογαριασμός μου\".</p>\r\n<p>Σας ευχαριστούμε που επιλέξατε την πλατφόρμα του συνΑθηνά για τη δημοσίευση του του open call σας.</p>\r\n<p>Η ομάδα του συνΑθηνά.</p>\r\n'),(3,'open_call_admin','Συναθηνά','info@synathina.gr','synathinaplatform@gmail.com','Νέο open call στο www.synathina.gr','Open Call','<p>Ένα νέο open call έχει καταχωριστεί στην ιστοσελίδα του συνΑθηνά.</p>\n<p><a href=\"%s1\">%s1</a></p>\n<p>Εάν θέλετε να κάνετε ανάκληση πιέστε <a href=\"%s2\">εδώ</a>.</p>'),(4,'body_head','','','','','','<body style=\"margin:0px auto; padding:0px; background-color:#FFFFFF; color:#5d5d5d; font-family:Arial; outline:none; font-size:12px;\" bgcolor=\"#FFFFFF\">\r\n								<div style=\"background-color:#FFFFFF;margin:0px auto; font-family:Arial;color:#5d5d5d;\">\r\n									<div style=\"margin:0px auto; width:640px; text-align:left; background-color:#ebebeb; font-family:Arial; padding:20px;color:#5d5d5d;\">\r\n									<div style=\"font-size: 18px;font-weight:bold; color:#05c0de;padding-bottom: 10px;\">Open Call</div>'),(5,'body_footer','','','','','','</div></div></body>'),(6,'team_created_user','','','','Το αίτημά σας για εγγραφή στο www.synathina.gr καταχωρίστηκε','Αίτημα Εγγραφής','<p>Το αίτημά σας για εγγραφή στην ιστοσελίδα του συνΑθηνά έχει καταχωριστεί. Εντός 48 ωρών θα ενημερωθείτε με νέο μήνυμα για την ενεργοποίηση του λογαριασμού σας.</p>\r\n<p>Σας ευχαριστούμε</p>\r\n<p>Η ομάδα του συνΑθηνά</p>\r\n'),(7,'team_created_admin','','','synathinaplatform@gmail.com','Nέος χρήστης στο www.synathina.gr','Αίτημα Εγγραφής','<p>Ελέγξτε το προφίλ του <a href=\"%s1\" target=\"_blank\">εδώ</a> και στη συνέχεια επιλέξτε δημοσίευση.</p>'),(8,'team_activated_user','','','','Καλώς ήρθατε στο www.synathina.gr!','Ο Λογαριασμός σας ενεργοποιήθηκε','<p>Ο λογαριασμός σας στην ιστοσελίδα του συνΑθηνά έχει ενεργοποιηθεί. Τώρα μπορείτε να δημοσιεύετε τις δράσεις σας, να διασυνδέεστε ηλεκτρονικά με άλλες ομάδες που συμμετέχουν στην ψηφιακή πλατφόρμα του συνΑθηνά, να κάνετε online κράτηση στη στέγη του συνΑθηνά και να ανεβάζετε ανοιχτές προσκλήσεις.</p><p>Για οποιαδήποτε διευκρίνιση είμαστε στη διάθεσή σας στο synathina@athens.gr ή τηλεφωνικά στο 210 5277523.</p>\r\n<p>Σας ευχαριστούμε</p>\r\n<p>Η ομάδα του συνΑθηνά</p>\r\n'),(9,'action_created_municipality','','','','Αίτημα προς το δήμο Αθηναίων από ομάδα - χρήστη του www.synathina.gr','Αίτημα από ομάδα - χρήστη του συνΑθηνά','<p>Η ομάδα πολιτών <a href=\"%s1\" target=\"_blank\">%s2</a> που συμμετέχει στην ψηφιακή πλατφόρμα του συνΑθηνά του δήμου Αθηναίων έχει υποβάλει το ακόλουθο αίτημα για:</p>\r\n<p>%s3</p>\r\n<p>\"%s4\"</p>\r\n<p>Περισσότερες πληροφορίες για τη δράση της ομάδας %s2 μπορείτε να διαβάσετε <a href=\"%s5\" target=\"_blank\">εδώ</a>. </p>\r\n<p>Για να κάνετε διευκρινιστικές ερωτήσεις ή για να ενημερώσετε τον χρήστη για την εξέλιξη του αιτήματός του χρησιμοποιήστε τα παρακάτω στοιχεία επικοινωνίας.</p>\r\n<p>%s6</p>\r\n<p>Για οποιαδήποτε άλλη πληροφορία, μπορείτε να επικοινωνήσετε με την ομάδα του συνΑθηνά στο synathina@athens.gr και στο 2103464738.</p>\r\n<p>Σας ευχαριστούμε για την προσοχή σας</p>\r\n<p>Η ομάδα του συνΑθηνά</p>'),(10,'action_created_supporters','','','','Αίτημα για υποστήριξη από ομάδα πολιτών που συμμετέχει στο συνΑθηνά','Παράκληση για υποστήριξη','<p>Σας ενημερώνουμε ότι η ομάδα <a href=\"%s1\" target=\"_blank\">%s2</a> έχει ζητήσει υποστήριξη για τη δράση της σε %s3.</p>\r\n<p>Αυτό είναι το μήνυμα της ομάδας προς τους υποστηρικτές:</p>\r\n<p>%s4</p>\r\n<p>Περισσότερες πληροφορίες για τη δράση της ομάδας %s2 μπορείτε να διαβάσετε εδώ <a href=\"%s5\" target=\"_blank\">%s6</a></p>\r\n<p>Εάν θέλετε να υποστηρίξετε τη συγκεκριμένη δράση, μπορείτε να επικοινωνήσετε με τον/την %s7 στο email %s8 και στο τηλέφωνο %s9.</p>\r\n<p>Σας ευχαριστούμε</p>'),(11,'action_created_user_confirmed','','','','Η δράση σας έχει καταχωριστεί στο www.synathina.gr','Επιτυχής καταχώριση δράσης','<p>Αγαπητέ χρήστη,</p><p>Η δράση σας έχει καταχωριστεί με επιτυχία στο www.synathina.gr. Μπορείτε να επεξεργαστείτε ξανά τα στοιχεία της δράσης σας από τον πίνακα ελέγχου του προφίλ σας.</p>\r\n%s1\r\n%s2\r\n%s3\r\n<p>Σας ευχαριστούμε</p>\r\n<p>Η ομάδα του συνΑθηνά</p>\r\n'),(12,'action_created_admin','','','synathinaplatform@gmail.com','Νέα δράση στο www.synathina.gr','Νέα Δράση','<p>Μια νέα δράση έχει υποβληθεί στο www.synathina.gr από την ομάδα %s1.</p>\r\n<p><a href=\"%s2\" target=\"_blank\">%s3</a></p>\r\n<p>Για να εγκρίνετε τη δράση συνδεθείτε ως διαχειριστής στο site και επεξεργαστείτε τη δράση από εδώ: <a href=\"%s4\" target=\"_blank\">εδώ</a>.</p>'),(13,'action_cancelled_user','','','','Έχει γίνει ανάκληση της δράσης σας στο www.synathina.gr','Ανάκληση δράσης','<p>H δράση σας με τίτλο \"%s1\" δεν εμφανίζεται πλέον στην ιστοσελίδα του συνΑθηνά.</p>\r\n<p>Παρακαλούμε επικοινωνήστε με την ομάδα του συνΑθηνά στο synathina@athens.gr ή τηλεφωνικά, στο 2105277521.</p>\r\n<p>Σας ευχαριστούμε</p>\r\n<p>Η ομάδα του συνΑθηνά</p>\r\n'),(14,'stegi_created_admin','','','synathinaplatform@gmail.com','Νέα συνάντηση στη στέγη του συνΑθηνά','Συνάντηση στη Στέγη του συνΑθηνά','Η ομάδα \"%s1\" έχει κλείσει τη στέγη του συνΑθηνά από την %s2 έως την %s3. '),(15,'stegi_action_created_admin','','','synathinaplatform@gmail.com','Νέα δράση στη στέγη του συνΑθηνά','Δράση στη στέγη του συνΑθηνά','Η ομάδα \"%s1\" έχει κλείσει τη στέγη του συνΑθηνά για τις ανάγκες της δράσης \"%s2\" την %s3 και ώρα από %s4 έως %s5. '),(16,'action_created_user_pending','','','','Η δράση σας έχει υποβληθεί για έγκριση στο www.synathina.gr','Υποβολή δράσης στο συνΑθηνά','<p>Αγαπητέ χρήστη,</p><p>Η δράση σας έχει υποβληθεί για έγκριση στο www.synathina.gr. Εντός 48 ωρών θα λάβετε ειδοποίηση για την δημοσίευση της δράσης σας.</p>\r\n<p>Σας ευχαριστούμε</p>\r\n<p>Η ομάδα του συνΑθηνά</p>\r\n'),(17,'action_created_user_from_root','','','','Η δράση σας αναρτήθηκε στο www.synathina.gr','Ανάρτηση δράσης στο συνΑθηνά','<p>Η δράση σας με τίτλο <a href=\"%s1\" target=\"_blank\">%s2</a> έχει αναρτηθεί στην ιστοσελίδα του συνΑθηνά.<br />\r\nΕάν θέλετε να επεξεργαστείτε τα στοιχεία της, μπορείτε να συνδεθείτε με τα στοιχεία του λογαριασμού σας στο www.synathina.gr και στη συνέχεια να επιλέξετε το link \"Επεξεργασία Δράσεων\" το οποίο βρίσκεται στη σελίδα \"Ο λογαριασμός μου\".</p>\r\n\r\n<p>Παραμένουμε στη διάθεσή σας για οποιαδήποτε διευκρίνιση.</p>\r\n<p>Με φιλικούς χαιρετισμούς</p>\r\n<p>Η ομάδα του συνΑθηνά</p>'),(18,'action_fail_admin','','','synathinaplatform@gmail.com','Πρόβλημα με καταχώριση δράσης στο www.synathina.gr','Πρόβλημα καταχώρισης δράσης','<p>Παρουσιάστηκε σφάλμα κατά την καταχώριση  δράσης με τίτλο \"%s1\" από την ομάδα \"%s2\".</p>'),(19,'stegi_created_user','','','','Νέα συνάντηση στη στέγη του συνΑθηνά','Κλείσατε τη στέγη του συνΑθηνά για τη συνάντησή σας','<p>Αγαπητέ χρήστη,</p><p>Έχετε κλείσει τη στέγη του συνΑθηνά για τις ανάγκες της ομάδας σας από την %s2 έως την %s3.<br />Στα συνημμένα μπορείτε να διαβάσετε τους όρους χρήσης της στέγης τους οποίους δηλώνετε ότι αποδέχεστε ανεπιφύλακτα.</p><p>Σας ευχαριστούμε,<br />Η ομάδα του συνΑθηνά.</p> ');
/*!40000 ALTER TABLE `prefi_emails` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prefi_extensions`
--

DROP TABLE IF EXISTS `prefi_extensions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `prefi_extensions` (
  `extension_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `element` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `folder` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `client_id` tinyint(3) NOT NULL,
  `enabled` tinyint(3) NOT NULL DEFAULT '1',
  `access` int(10) unsigned NOT NULL DEFAULT '1',
  `protected` tinyint(3) NOT NULL DEFAULT '0',
  `manifest_cache` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `params` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `custom_data` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `system_data` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ordering` int(11) DEFAULT '0',
  `state` int(11) DEFAULT '0',
  PRIMARY KEY (`extension_id`),
  KEY `element_clientid` (`element`,`client_id`),
  KEY `element_folder_clientid` (`element`,`folder`,`client_id`),
  KEY `extension` (`type`,`element`,`folder`,`client_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10060 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prefi_extensions`
--

LOCK TABLES `prefi_extensions` WRITE;
/*!40000 ALTER TABLE `prefi_extensions` DISABLE KEYS */;
INSERT INTO `prefi_extensions` VALUES (1,'com_mailto','component','com_mailto','',0,1,1,1,'{\"name\":\"com_mailto\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Core Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\\t\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_MAILTO_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mailto\"}','','','',0,'0000-00-00 00:00:00',0,0),(2,'com_wrapper','component','com_wrapper','',0,1,1,1,'{\"name\":\"com_wrapper\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Core Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\\n\\t\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_WRAPPER_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"wrapper\"}','','','',0,'0000-00-00 00:00:00',0,0),(3,'com_admin','component','com_admin','',1,1,1,1,'{\"name\":\"com_admin\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Core Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_ADMIN_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(4,'com_banners','component','com_banners','',1,1,1,0,'{\"name\":\"com_banners\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Core Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_BANNERS_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"banners\"}','{\"purchase_type\":\"3\",\"track_impressions\":\"0\",\"track_clicks\":\"0\",\"metakey_prefix\":\"\",\"save_history\":\"1\",\"history_limit\":10}','','',0,'0000-00-00 00:00:00',0,0),(5,'com_cache','component','com_cache','',1,1,1,1,'{\"name\":\"com_cache\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Core Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_CACHE_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(6,'com_categories','component','com_categories','',1,1,1,1,'{\"name\":\"com_categories\",\"type\":\"component\",\"creationDate\":\"December 2007\",\"author\":\"Core Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_CATEGORIES_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(7,'com_checkin','component','com_checkin','',1,1,1,1,'{\"name\":\"com_checkin\",\"type\":\"component\",\"creationDate\":\"Unknown\",\"author\":\"Core Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_CHECKIN_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(8,'com_contact','component','com_contact','',1,1,1,0,'{\"name\":\"com_contact\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Core Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_CONTACT_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"contact\"}','{\"show_contact_category\":\"hide\",\"save_history\":\"1\",\"history_limit\":10,\"show_contact_list\":\"0\",\"presentation_style\":\"sliders\",\"show_name\":\"1\",\"show_position\":\"1\",\"show_email\":\"0\",\"show_street_address\":\"1\",\"show_suburb\":\"1\",\"show_state\":\"1\",\"show_postcode\":\"1\",\"show_country\":\"1\",\"show_telephone\":\"1\",\"show_mobile\":\"1\",\"show_fax\":\"1\",\"show_webpage\":\"1\",\"show_misc\":\"1\",\"show_image\":\"1\",\"image\":\"\",\"allow_vcard\":\"0\",\"show_articles\":\"0\",\"show_profile\":\"0\",\"show_links\":\"0\",\"linka_name\":\"\",\"linkb_name\":\"\",\"linkc_name\":\"\",\"linkd_name\":\"\",\"linke_name\":\"\",\"contact_icons\":\"0\",\"icon_address\":\"\",\"icon_email\":\"\",\"icon_telephone\":\"\",\"icon_mobile\":\"\",\"icon_fax\":\"\",\"icon_misc\":\"\",\"show_headings\":\"1\",\"show_position_headings\":\"1\",\"show_email_headings\":\"0\",\"show_telephone_headings\":\"1\",\"show_mobile_headings\":\"0\",\"show_fax_headings\":\"0\",\"allow_vcard_headings\":\"0\",\"show_suburb_headings\":\"1\",\"show_state_headings\":\"1\",\"show_country_headings\":\"1\",\"show_email_form\":\"1\",\"show_email_copy\":\"1\",\"banned_email\":\"\",\"banned_subject\":\"\",\"banned_text\":\"\",\"validate_session\":\"1\",\"custom_reply\":\"0\",\"redirect\":\"\",\"show_category_crumb\":\"0\",\"metakey\":\"\",\"metadesc\":\"\",\"robots\":\"\",\"author\":\"\",\"rights\":\"\",\"xreference\":\"\"}','','',0,'0000-00-00 00:00:00',0,0),(9,'com_cpanel','component','com_cpanel','',1,1,1,1,'{\"name\":\"com_cpanel\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Core Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_CPANEL_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(10,'com_installer','component','com_installer','',1,1,1,1,'{\"name\":\"com_installer\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Core Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_INSTALLER_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(11,'com_languages','component','com_languages','',1,1,1,1,'{\"name\":\"com_languages\",\"type\":\"component\",\"creationDate\":\"2006\",\"author\":\"Core Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_LANGUAGES_XML_DESCRIPTION\",\"group\":\"\"}','{\"administrator\":\"el-GR\",\"site\":\"el-GR\"}','','',0,'0000-00-00 00:00:00',0,0),(12,'com_login','component','com_login','',1,1,1,1,'{\"name\":\"com_login\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Core Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_LOGIN_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(13,'com_media','component','com_media','',1,1,0,1,'{\"name\":\"com_media\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Core Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_MEDIA_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"media\"}','{\"upload_extensions\":\"bmp,csv,doc,gif,ico,jpg,jpeg,odg,odp,ods,odt,pdf,png,ppt,swf,txt,xcf,xls,BMP,CSV,DOC,GIF,ICO,JPG,JPEG,ODG,ODP,ODS,ODT,PDF,PNG,PPT,SWF,TXT,XCF,XLS\",\"upload_maxsize\":\"10\",\"file_path\":\"images\",\"image_path\":\"images\",\"restrict_uploads\":\"0\",\"check_mime\":\"0\",\"image_extensions\":\"bmp,gif,jpg,jpeg,png,pdf,doc,docx\",\"ignore_extensions\":\"\",\"upload_mime\":\"image\\/jpeg,image\\/gif,image\\/png,image\\/bmp,application\\/x-shockwave-flash,application\\/msword,application\\/excel,application\\/pdf,application\\/powerpoint,text\\/plain,application\\/x-zip\",\"upload_mime_illegal\":\"text\\/html\"}','','',0,'0000-00-00 00:00:00',0,0),(14,'com_menus','component','com_menus','',1,1,1,1,'{\"name\":\"com_menus\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Core Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_MENUS_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(15,'com_messages','component','com_messages','',1,1,1,1,'{\"name\":\"com_messages\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Core Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_MESSAGES_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(16,'com_modules','component','com_modules','',1,1,1,1,'{\"name\":\"com_modules\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Core Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_MODULES_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(17,'com_newsfeeds','component','com_newsfeeds','',1,1,1,0,'{\"name\":\"com_newsfeeds\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Core Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_NEWSFEEDS_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"newsfeeds\"}','{\"newsfeed_layout\":\"_:default\",\"save_history\":\"1\",\"history_limit\":5,\"show_feed_image\":\"1\",\"show_feed_description\":\"1\",\"show_item_description\":\"1\",\"feed_character_count\":\"0\",\"feed_display_order\":\"des\",\"float_first\":\"right\",\"float_second\":\"right\",\"show_tags\":\"1\",\"category_layout\":\"_:default\",\"show_category_title\":\"1\",\"show_description\":\"1\",\"show_description_image\":\"1\",\"maxLevel\":\"-1\",\"show_empty_categories\":\"0\",\"show_subcat_desc\":\"1\",\"show_cat_items\":\"1\",\"show_cat_tags\":\"1\",\"show_base_description\":\"1\",\"maxLevelcat\":\"-1\",\"show_empty_categories_cat\":\"0\",\"show_subcat_desc_cat\":\"1\",\"show_cat_items_cat\":\"1\",\"filter_field\":\"1\",\"show_pagination_limit\":\"1\",\"show_headings\":\"1\",\"show_articles\":\"0\",\"show_link\":\"1\",\"show_pagination\":\"1\",\"show_pagination_results\":\"1\"}','','',0,'0000-00-00 00:00:00',0,0),(18,'com_plugins','component','com_plugins','',1,1,1,1,'{\"name\":\"com_plugins\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Core Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_PLUGINS_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(19,'com_search','component','com_search','',1,1,1,0,'{\"name\":\"com_search\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Core Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_SEARCH_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"search\"}','{\"enabled\":\"0\",\"show_date\":\"1\"}','','',0,'0000-00-00 00:00:00',0,0),(20,'com_templates','component','com_templates','',1,1,1,1,'{\"name\":\"com_templates\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Core Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_TEMPLATES_XML_DESCRIPTION\",\"group\":\"\"}','{\"template_positions_display\":\"0\",\"upload_limit\":\"2\",\"image_formats\":\"gif,bmp,jpg,jpeg,png\",\"source_formats\":\"txt,less,ini,xml,js,php,css\",\"font_formats\":\"woff,ttf,otf\",\"compressed_formats\":\"zip\"}','','',0,'0000-00-00 00:00:00',0,0),(22,'com_content','component','com_content','',1,1,0,1,'{\"name\":\"com_content\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Core Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_CONTENT_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"content\"}','{\"article_layout\":\"_:default\",\"show_title\":\"1\",\"link_titles\":\"1\",\"show_intro\":\"1\",\"info_block_position\":\"0\",\"show_category\":\"0\",\"link_category\":\"0\",\"show_parent_category\":\"0\",\"link_parent_category\":\"0\",\"show_author\":\"0\",\"link_author\":\"0\",\"show_create_date\":\"0\",\"show_modify_date\":\"0\",\"show_publish_date\":\"1\",\"show_item_navigation\":\"0\",\"show_vote\":\"0\",\"show_readmore\":\"1\",\"show_readmore_title\":\"0\",\"readmore_limit\":\"100\",\"show_tags\":\"1\",\"show_icons\":\"0\",\"show_print_icon\":\"0\",\"show_email_icon\":\"0\",\"show_hits\":\"0\",\"show_noauth\":\"0\",\"urls_position\":\"0\",\"show_publishing_options\":\"1\",\"show_article_options\":\"1\",\"save_history\":\"1\",\"history_limit\":10,\"show_urls_images_frontend\":\"0\",\"show_urls_images_backend\":\"1\",\"targeta\":0,\"targetb\":0,\"targetc\":0,\"float_intro\":\"left\",\"float_fulltext\":\"left\",\"category_layout\":\"_:blog\",\"show_category_heading_title_text\":\"1\",\"show_category_title\":\"0\",\"show_description\":\"0\",\"show_description_image\":\"0\",\"maxLevel\":\"1\",\"show_empty_categories\":\"0\",\"show_no_articles\":\"1\",\"show_subcat_desc\":\"1\",\"show_cat_num_articles\":\"0\",\"show_cat_tags\":\"1\",\"show_base_description\":\"1\",\"maxLevelcat\":\"-1\",\"show_empty_categories_cat\":\"0\",\"show_subcat_desc_cat\":\"1\",\"show_cat_num_articles_cat\":\"1\",\"num_leading_articles\":\"0\",\"num_intro_articles\":\"3\",\"num_columns\":\"1\",\"num_links\":\"0\",\"multi_column_order\":\"0\",\"show_subcategory_content\":\"0\",\"show_pagination_limit\":\"1\",\"filter_field\":\"hide\",\"show_headings\":\"1\",\"list_show_date\":\"0\",\"date_format\":\"\",\"list_show_hits\":\"1\",\"list_show_author\":\"1\",\"orderby_pri\":\"order\",\"orderby_sec\":\"rdate\",\"order_date\":\"published\",\"show_pagination\":\"2\",\"show_pagination_results\":\"1\",\"show_featured\":\"show\",\"show_feed_link\":\"1\",\"feed_summary\":\"0\",\"feed_show_readmore\":\"0\"}','','',0,'0000-00-00 00:00:00',0,0),(23,'com_config','component','com_config','',1,1,0,1,'{\"name\":\"com_config\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Core Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_CONFIG_XML_DESCRIPTION\",\"group\":\"\"}','{\"filters\":{\"1\":{\"filter_type\":\"NONE\",\"filter_tags\":\"\",\"filter_attributes\":\"\"},\"9\":{\"filter_type\":\"BL\",\"filter_tags\":\"\",\"filter_attributes\":\"\"},\"6\":{\"filter_type\":\"BL\",\"filter_tags\":\"\",\"filter_attributes\":\"\"},\"7\":{\"filter_type\":\"NONE\",\"filter_tags\":\"\",\"filter_attributes\":\"\"},\"2\":{\"filter_type\":\"NH\",\"filter_tags\":\"\",\"filter_attributes\":\"\"},\"3\":{\"filter_type\":\"BL\",\"filter_tags\":\"\",\"filter_attributes\":\"\"},\"4\":{\"filter_type\":\"BL\",\"filter_tags\":\"\",\"filter_attributes\":\"\"},\"5\":{\"filter_type\":\"BL\",\"filter_tags\":\"\",\"filter_attributes\":\"\"},\"12\":{\"filter_type\":\"BL\",\"filter_tags\":\"\",\"filter_attributes\":\"\"},\"13\":{\"filter_type\":\"BL\",\"filter_tags\":\"\",\"filter_attributes\":\"\"},\"10\":{\"filter_type\":\"BL\",\"filter_tags\":\"\",\"filter_attributes\":\"\"},\"11\":{\"filter_type\":\"BL\",\"filter_tags\":\"\",\"filter_attributes\":\"\"},\"8\":{\"filter_type\":\"NONE\",\"filter_tags\":\"\",\"filter_attributes\":\"\"}}}','','',0,'0000-00-00 00:00:00',0,0),(24,'com_redirect','component','com_redirect','',1,1,0,1,'{\"name\":\"com_redirect\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Core Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_REDIRECT_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(25,'com_users','component','com_users','',1,1,0,1,'{\"name\":\"com_users\",\"type\":\"component\",\"creationDate\":\"April 2006\",\"author\":\"Core Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_USERS_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"users\"}','{\"allowUserRegistration\":\"1\",\"new_usertype\":\"2\",\"guest_usergroup\":\"9\",\"sendpassword\":\"0\",\"useractivation\":\"1\",\"mail_to_admin\":\"0\",\"captcha\":\"\",\"frontend_userparams\":\"0\",\"site_language\":\"0\",\"change_login_name\":\"1\",\"reset_count\":\"10\",\"reset_time\":\"1\",\"minimum_length\":\"4\",\"minimum_integers\":\"0\",\"minimum_symbols\":\"0\",\"minimum_uppercase\":\"0\",\"save_history\":\"1\",\"history_limit\":5,\"mailSubjectPrefix\":\"\",\"mailBodySuffix\":\"\"}','','',0,'0000-00-00 00:00:00',0,0),(27,'com_finder','component','com_finder','',1,1,0,0,'{\"name\":\"com_finder\",\"type\":\"component\",\"creationDate\":\"August 2011\",\"author\":\"Core Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_FINDER_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"finder\"}','{\"show_description\":\"1\",\"description_length\":255,\"allow_empty_query\":\"0\",\"show_url\":\"1\",\"show_advanced\":\"1\",\"expand_advanced\":\"0\",\"show_date_filters\":\"0\",\"highlight_terms\":\"1\",\"opensearch_name\":\"\",\"opensearch_description\":\"\",\"batch_size\":\"50\",\"memory_table_limit\":30000,\"title_multiplier\":\"1.7\",\"text_multiplier\":\"0.7\",\"meta_multiplier\":\"1.2\",\"path_multiplier\":\"2.0\",\"misc_multiplier\":\"0.3\",\"stemmer\":\"snowball\"}','','',0,'0000-00-00 00:00:00',0,0),(28,'com_joomlaupdate','component','com_joomlaupdate','',1,1,0,1,'{\"name\":\"com_joomlaupdate\",\"type\":\"component\",\"creationDate\":\"February 2012\",\"author\":\"Core Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"COM_JOOMLAUPDATE_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(29,'com_tags','component','com_tags','',1,1,1,1,'{\"name\":\"com_tags\",\"type\":\"component\",\"creationDate\":\"December 2013\",\"author\":\"Core Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.1.0\",\"description\":\"COM_TAGS_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"tags\"}','{\"tag_layout\":\"_:default\",\"save_history\":\"1\",\"history_limit\":5,\"show_tag_title\":\"0\",\"tag_list_show_tag_image\":\"0\",\"tag_list_show_tag_description\":\"0\",\"tag_list_image\":\"\",\"show_tag_num_items\":\"0\",\"tag_list_orderby\":\"title\",\"tag_list_orderby_direction\":\"ASC\",\"show_headings\":\"0\",\"tag_list_show_date\":\"0\",\"tag_list_show_item_image\":\"0\",\"tag_list_show_item_description\":\"0\",\"tag_list_item_maximum_characters\":0,\"return_any_or_all\":\"1\",\"include_children\":\"0\",\"maximum\":200,\"tag_list_language_filter\":\"all\",\"tags_layout\":\"_:default\",\"all_tags_orderby\":\"title\",\"all_tags_orderby_direction\":\"ASC\",\"all_tags_show_tag_image\":\"0\",\"all_tags_show_tag_descripion\":\"0\",\"all_tags_tag_maximum_characters\":20,\"all_tags_show_tag_hits\":\"0\",\"filter_field\":\"1\",\"show_pagination_limit\":\"1\",\"show_pagination\":\"2\",\"show_pagination_results\":\"1\",\"tag_field_ajax_mode\":\"1\",\"show_feed_link\":\"1\"}','','',0,'0000-00-00 00:00:00',0,0),(30,'com_contenthistory','component','com_contenthistory','',1,1,1,0,'{\"name\":\"com_contenthistory\",\"type\":\"component\",\"creationDate\":\"May 2013\",\"author\":\"Core Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.2.0\",\"description\":\"COM_CONTENTHISTORY_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"contenthistory\"}','','','',0,'0000-00-00 00:00:00',0,0),(31,'com_ajax','component','com_ajax','',1,1,1,0,'{\"name\":\"com_ajax\",\"type\":\"component\",\"creationDate\":\"August 2013\",\"author\":\"Core Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.2.0\",\"description\":\"COM_AJAX_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"ajax\"}','','','',0,'0000-00-00 00:00:00',0,0),(32,'com_postinstall','component','com_postinstall','',1,1,1,1,'{\"name\":\"com_postinstall\",\"type\":\"component\",\"creationDate\":\"September 2013\",\"author\":\"Core Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.2.0\",\"description\":\"COM_POSTINSTALL_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(101,'SimplePie','library','simplepie','',0,1,1,1,'{\"name\":\"SimplePie\",\"type\":\"library\",\"creationDate\":\"2004\",\"author\":\"SimplePie\",\"copyright\":\"Copyright (c) 2004-2009, Ryan Parman and Geoffrey Sneddon\",\"authorEmail\":\"\",\"authorUrl\":\"http:\\/\\/simplepie.org\\/\",\"version\":\"1.2\",\"description\":\"LIB_SIMPLEPIE_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"simplepie\"}','','','',0,'0000-00-00 00:00:00',0,0),(102,'phputf8','library','phputf8','',0,1,1,1,'{\"name\":\"phputf8\",\"type\":\"library\",\"creationDate\":\"2006\",\"author\":\"Harry Fuecks\",\"copyright\":\"Copyright various authors\",\"authorEmail\":\"hfuecks@gmail.com\",\"authorUrl\":\"http:\\/\\/sourceforge.net\\/projects\\/phputf8\",\"version\":\"0.5\",\"description\":\"LIB_PHPUTF8_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"phputf8\"}','','','',0,'0000-00-00 00:00:00',0,0),(103,'Core Platform','library','joomla','',0,1,1,1,'{\"name\":\"Core Platform\",\"type\":\"library\",\"creationDate\":\"2008\",\"author\":\"Core Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"https:\\/\\/www.joomla.org\",\"version\":\"13.1\",\"description\":\"LIB_JOOMLA_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"joomla\"}','{\"mediaversion\":\"104faa0c89732710606421afff76bc30\"}','','',0,'0000-00-00 00:00:00',0,0),(104,'IDNA Convert','library','idna_convert','',0,1,1,1,'{\"name\":\"IDNA Convert\",\"type\":\"library\",\"creationDate\":\"2004\",\"author\":\"phlyLabs\",\"copyright\":\"2004-2011 phlyLabs Berlin, http:\\/\\/phlylabs.de\",\"authorEmail\":\"phlymail@phlylabs.de\",\"authorUrl\":\"http:\\/\\/phlylabs.de\",\"version\":\"0.8.0\",\"description\":\"LIB_IDNA_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"idna_convert\"}','','','',0,'0000-00-00 00:00:00',0,0),(105,'FOF','library','fof','',0,1,1,1,'{\"name\":\"FOF\",\"type\":\"library\",\"creationDate\":\"2015-04-22 13:15:32\",\"author\":\"Nicholas K. Dionysopoulos \\/ Akeeba Ltd\",\"copyright\":\"(C)2011-2015 Nicholas K. Dionysopoulos\",\"authorEmail\":\"nicholas@akeebabackup.com\",\"authorUrl\":\"https:\\/\\/www.akeebabackup.com\",\"version\":\"2.4.3\",\"description\":\"LIB_FOF_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"fof\"}','','','',0,'0000-00-00 00:00:00',0,0),(106,'PHPass','library','phpass','',0,1,1,1,'{\"name\":\"PHPass\",\"type\":\"library\",\"creationDate\":\"2004-2006\",\"author\":\"Solar Designer\",\"copyright\":\"\",\"authorEmail\":\"solar@openwall.com\",\"authorUrl\":\"http:\\/\\/www.openwall.com\\/phpass\\/\",\"version\":\"0.3\",\"description\":\"LIB_PHPASS_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"phpass\"}','','','',0,'0000-00-00 00:00:00',0,0),(200,'mod_articles_archive','module','mod_articles_archive','',0,1,1,0,'{\"name\":\"mod_articles_archive\",\"type\":\"module\",\"creationDate\":\"July 2006\",\"author\":\"Core Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_ARTICLES_ARCHIVE_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_articles_archive\"}','','','',0,'0000-00-00 00:00:00',0,0),(201,'mod_articles_latest','module','mod_articles_latest','',0,1,1,0,'{\"name\":\"mod_articles_latest\",\"type\":\"module\",\"creationDate\":\"July 2004\",\"author\":\"Core Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_LATEST_NEWS_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_articles_latest\"}','','','',0,'0000-00-00 00:00:00',0,0),(202,'mod_articles_popular','module','mod_articles_popular','',0,1,1,0,'{\"name\":\"mod_articles_popular\",\"type\":\"module\",\"creationDate\":\"July 2006\",\"author\":\"Core Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_POPULAR_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_articles_popular\"}','','','',0,'0000-00-00 00:00:00',0,0),(203,'mod_banners','module','mod_banners','',0,1,1,0,'{\"name\":\"mod_banners\",\"type\":\"module\",\"creationDate\":\"July 2006\",\"author\":\"Core Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_BANNERS_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_banners\"}','','','',0,'0000-00-00 00:00:00',0,0),(204,'mod_breadcrumbs','module','mod_breadcrumbs','',0,1,1,1,'{\"name\":\"mod_breadcrumbs\",\"type\":\"module\",\"creationDate\":\"July 2006\",\"author\":\"Core Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_BREADCRUMBS_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_breadcrumbs\"}','','','',0,'0000-00-00 00:00:00',0,0),(205,'mod_custom','module','mod_custom','',0,1,1,1,'{\"name\":\"mod_custom\",\"type\":\"module\",\"creationDate\":\"July 2004\",\"author\":\"Core Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_CUSTOM_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_custom\"}','','','',0,'0000-00-00 00:00:00',0,0),(206,'mod_feed','module','mod_feed','',0,1,1,0,'{\"name\":\"mod_feed\",\"type\":\"module\",\"creationDate\":\"July 2005\",\"author\":\"Core Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_FEED_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_feed\"}','','','',0,'0000-00-00 00:00:00',0,0),(207,'mod_footer','module','mod_footer','',0,1,1,0,'{\"name\":\"mod_footer\",\"type\":\"module\",\"creationDate\":\"July 2006\",\"author\":\"Core Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_FOOTER_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_footer\"}','','','',0,'0000-00-00 00:00:00',0,0),(208,'mod_login','module','mod_login','',0,1,1,1,'{\"name\":\"mod_login\",\"type\":\"module\",\"creationDate\":\"July 2006\",\"author\":\"Core Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_LOGIN_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_login\"}','','','',0,'0000-00-00 00:00:00',0,0),(209,'mod_menu','module','mod_menu','',0,1,1,1,'{\"name\":\"mod_menu\",\"type\":\"module\",\"creationDate\":\"July 2004\",\"author\":\"Core Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_MENU_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_menu\"}','','','',0,'0000-00-00 00:00:00',0,0),(210,'mod_articles_news','module','mod_articles_news','',0,1,1,0,'{\"name\":\"mod_articles_news\",\"type\":\"module\",\"creationDate\":\"July 2006\",\"author\":\"Core Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_ARTICLES_NEWS_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_articles_news\"}','','','',0,'0000-00-00 00:00:00',0,0),(211,'mod_random_image','module','mod_random_image','',0,1,1,0,'{\"name\":\"mod_random_image\",\"type\":\"module\",\"creationDate\":\"July 2006\",\"author\":\"Core Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_RANDOM_IMAGE_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_random_image\"}','','','',0,'0000-00-00 00:00:00',0,0),(212,'mod_related_items','module','mod_related_items','',0,1,1,0,'{\"name\":\"mod_related_items\",\"type\":\"module\",\"creationDate\":\"July 2004\",\"author\":\"Core Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_RELATED_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_related_items\"}','','','',0,'0000-00-00 00:00:00',0,0),(213,'mod_search','module','mod_search','',0,1,1,0,'{\"name\":\"mod_search\",\"type\":\"module\",\"creationDate\":\"July 2004\",\"author\":\"Core Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_SEARCH_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_search\"}','','','',0,'0000-00-00 00:00:00',0,0),(214,'mod_stats','module','mod_stats','',0,1,1,0,'{\"name\":\"mod_stats\",\"type\":\"module\",\"creationDate\":\"July 2004\",\"author\":\"Core Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_STATS_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_stats\"}','','','',0,'0000-00-00 00:00:00',0,0),(215,'mod_syndicate','module','mod_syndicate','',0,1,1,1,'{\"name\":\"mod_syndicate\",\"type\":\"module\",\"creationDate\":\"May 2006\",\"author\":\"Core Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_SYNDICATE_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_syndicate\"}','','','',0,'0000-00-00 00:00:00',0,0),(216,'mod_users_latest','module','mod_users_latest','',0,1,1,0,'{\"name\":\"mod_users_latest\",\"type\":\"module\",\"creationDate\":\"December 2009\",\"author\":\"Core Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_USERS_LATEST_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_users_latest\"}','','','',0,'0000-00-00 00:00:00',0,0),(218,'mod_whosonline','module','mod_whosonline','',0,1,1,0,'{\"name\":\"mod_whosonline\",\"type\":\"module\",\"creationDate\":\"July 2004\",\"author\":\"Core Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_WHOSONLINE_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_whosonline\"}','','','',0,'0000-00-00 00:00:00',0,0),(219,'mod_wrapper','module','mod_wrapper','',0,1,1,0,'{\"name\":\"mod_wrapper\",\"type\":\"module\",\"creationDate\":\"October 2004\",\"author\":\"Core Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_WRAPPER_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_wrapper\"}','','','',0,'0000-00-00 00:00:00',0,0),(220,'mod_articles_category','module','mod_articles_category','',0,1,1,0,'{\"name\":\"mod_articles_category\",\"type\":\"module\",\"creationDate\":\"February 2010\",\"author\":\"Core Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_ARTICLES_CATEGORY_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_articles_category\"}','','','',0,'0000-00-00 00:00:00',0,0),(221,'mod_articles_categories','module','mod_articles_categories','',0,1,1,0,'{\"name\":\"mod_articles_categories\",\"type\":\"module\",\"creationDate\":\"February 2010\",\"author\":\"Core Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_ARTICLES_CATEGORIES_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_articles_categories\"}','','','',0,'0000-00-00 00:00:00',0,0),(222,'mod_languages','module','mod_languages','',0,1,1,1,'{\"name\":\"mod_languages\",\"type\":\"module\",\"creationDate\":\"February 2010\",\"author\":\"Core Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_LANGUAGES_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_languages\"}','','','',0,'0000-00-00 00:00:00',0,0),(223,'mod_finder','module','mod_finder','',0,1,0,0,'{\"name\":\"mod_finder\",\"type\":\"module\",\"creationDate\":\"August 2011\",\"author\":\"Core Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_FINDER_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_finder\"}','','','',0,'0000-00-00 00:00:00',0,0),(300,'mod_custom','module','mod_custom','',1,1,1,1,'{\"name\":\"mod_custom\",\"type\":\"module\",\"creationDate\":\"July 2004\",\"author\":\"Core Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_CUSTOM_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_custom\"}','','','',0,'0000-00-00 00:00:00',0,0),(301,'mod_feed','module','mod_feed','',1,1,1,0,'{\"name\":\"mod_feed\",\"type\":\"module\",\"creationDate\":\"July 2005\",\"author\":\"Core Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_FEED_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_feed\"}','','','',0,'0000-00-00 00:00:00',0,0),(302,'mod_latest','module','mod_latest','',1,1,1,0,'{\"name\":\"mod_latest\",\"type\":\"module\",\"creationDate\":\"July 2004\",\"author\":\"Core Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_LATEST_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_latest\"}','','','',0,'0000-00-00 00:00:00',0,0),(303,'mod_logged','module','mod_logged','',1,1,1,0,'{\"name\":\"mod_logged\",\"type\":\"module\",\"creationDate\":\"January 2005\",\"author\":\"Core Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_LOGGED_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_logged\"}','','','',0,'0000-00-00 00:00:00',0,0),(304,'mod_login','module','mod_login','',1,1,1,1,'{\"name\":\"mod_login\",\"type\":\"module\",\"creationDate\":\"March 2005\",\"author\":\"Core Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_LOGIN_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_login\"}','','','',0,'0000-00-00 00:00:00',0,0),(305,'mod_menu','module','mod_menu','',1,1,1,0,'{\"name\":\"mod_menu\",\"type\":\"module\",\"creationDate\":\"March 2006\",\"author\":\"Core Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_MENU_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_menu\"}','','','',0,'0000-00-00 00:00:00',0,0),(307,'mod_popular','module','mod_popular','',1,1,1,0,'{\"name\":\"mod_popular\",\"type\":\"module\",\"creationDate\":\"July 2004\",\"author\":\"Core Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_POPULAR_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_popular\"}','','','',0,'0000-00-00 00:00:00',0,0),(308,'mod_quickicon','module','mod_quickicon','',1,1,1,1,'{\"name\":\"mod_quickicon\",\"type\":\"module\",\"creationDate\":\"Nov 2005\",\"author\":\"Core Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_QUICKICON_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_quickicon\"}','','','',0,'0000-00-00 00:00:00',0,0),(309,'mod_status','module','mod_status','',1,1,1,0,'{\"name\":\"mod_status\",\"type\":\"module\",\"creationDate\":\"Feb 2006\",\"author\":\"Core Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_STATUS_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_status\"}','','','',0,'0000-00-00 00:00:00',0,0),(310,'mod_submenu','module','mod_submenu','',1,1,1,0,'{\"name\":\"mod_submenu\",\"type\":\"module\",\"creationDate\":\"Feb 2006\",\"author\":\"Core Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_SUBMENU_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_submenu\"}','','','',0,'0000-00-00 00:00:00',0,0),(311,'mod_title','module','mod_title','',1,1,1,0,'{\"name\":\"mod_title\",\"type\":\"module\",\"creationDate\":\"Nov 2005\",\"author\":\"Core Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_TITLE_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_title\"}','','','',0,'0000-00-00 00:00:00',0,0),(312,'mod_toolbar','module','mod_toolbar','',1,1,1,1,'{\"name\":\"mod_toolbar\",\"type\":\"module\",\"creationDate\":\"Nov 2005\",\"author\":\"Core Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_TOOLBAR_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_toolbar\"}','','','',0,'0000-00-00 00:00:00',0,0),(313,'mod_multilangstatus','module','mod_multilangstatus','',1,1,1,0,'{\"name\":\"mod_multilangstatus\",\"type\":\"module\",\"creationDate\":\"September 2011\",\"author\":\"Core Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_MULTILANGSTATUS_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_multilangstatus\"}','{\"cache\":\"0\"}','','',0,'0000-00-00 00:00:00',0,0),(314,'mod_version','module','mod_version','',1,1,1,0,'{\"name\":\"mod_version\",\"type\":\"module\",\"creationDate\":\"January 2012\",\"author\":\"Core Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_VERSION_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_version\"}','{\"format\":\"short\",\"product\":\"1\",\"cache\":\"0\"}','','',0,'0000-00-00 00:00:00',0,0),(315,'mod_stats_admin','module','mod_stats_admin','',1,1,1,0,'{\"name\":\"mod_stats_admin\",\"type\":\"module\",\"creationDate\":\"July 2004\",\"author\":\"Core Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"MOD_STATS_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_stats_admin\"}','{\"serverinfo\":\"0\",\"siteinfo\":\"0\",\"counter\":\"0\",\"increase\":\"0\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\"}','','',0,'0000-00-00 00:00:00',0,0),(316,'mod_tags_popular','module','mod_tags_popular','',0,1,1,0,'{\"name\":\"mod_tags_popular\",\"type\":\"module\",\"creationDate\":\"January 2013\",\"author\":\"Core Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.1.0\",\"description\":\"MOD_TAGS_POPULAR_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_tags_popular\"}','{\"maximum\":\"5\",\"timeframe\":\"alltime\",\"owncache\":\"1\"}','','',0,'0000-00-00 00:00:00',0,0),(317,'mod_tags_similar','module','mod_tags_similar','',0,1,1,0,'{\"name\":\"mod_tags_similar\",\"type\":\"module\",\"creationDate\":\"January 2013\",\"author\":\"Core Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.1.0\",\"description\":\"MOD_TAGS_SIMILAR_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_tags_similar\"}','{\"maximum\":\"5\",\"matchtype\":\"any\",\"owncache\":\"1\"}','','',0,'0000-00-00 00:00:00',0,0),(400,'plg_authentication_gmail','plugin','gmail','authentication',0,0,1,0,'{\"name\":\"plg_authentication_gmail\",\"type\":\"plugin\",\"creationDate\":\"February 2006\",\"author\":\"Core Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_GMAIL_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"gmail\"}','{\"applysuffix\":\"0\",\"suffix\":\"\",\"verifypeer\":\"1\",\"user_blacklist\":\"\"}','','',0,'0000-00-00 00:00:00',1,0),(401,'plg_authentication_joomla','plugin','joomla','authentication',0,1,1,1,'{\"name\":\"plg_authentication_joomla\",\"type\":\"plugin\",\"creationDate\":\"November 2005\",\"author\":\"Core Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_AUTH_JOOMLA_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"joomla\"}','','','',0,'0000-00-00 00:00:00',0,0),(402,'plg_authentication_ldap','plugin','ldap','authentication',0,0,1,0,'{\"name\":\"plg_authentication_ldap\",\"type\":\"plugin\",\"creationDate\":\"November 2005\",\"author\":\"Core Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_LDAP_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"ldap\"}','{\"host\":\"\",\"port\":\"389\",\"use_ldapV3\":\"0\",\"negotiate_tls\":\"0\",\"no_referrals\":\"0\",\"auth_method\":\"bind\",\"base_dn\":\"\",\"search_string\":\"\",\"users_dn\":\"\",\"username\":\"admin\",\"password\":\"bobby7\",\"ldap_fullname\":\"fullName\",\"ldap_email\":\"mail\",\"ldap_uid\":\"uid\"}','','',0,'0000-00-00 00:00:00',3,0),(403,'plg_content_contact','plugin','contact','content',0,1,1,0,'{\"name\":\"plg_content_contact\",\"type\":\"plugin\",\"creationDate\":\"January 2014\",\"author\":\"Core Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.2.2\",\"description\":\"PLG_CONTENT_CONTACT_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"contact\"}','','','',0,'0000-00-00 00:00:00',1,0),(404,'plg_content_emailcloak','plugin','emailcloak','content',0,1,1,0,'{\"name\":\"plg_content_emailcloak\",\"type\":\"plugin\",\"creationDate\":\"November 2005\",\"author\":\"Core Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_CONTENT_EMAILCLOAK_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"emailcloak\"}','{\"mode\":\"1\"}','','',0,'0000-00-00 00:00:00',1,0),(406,'plg_content_loadmodule','plugin','loadmodule','content',0,1,1,0,'{\"name\":\"plg_content_loadmodule\",\"type\":\"plugin\",\"creationDate\":\"November 2005\",\"author\":\"Core Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_LOADMODULE_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"loadmodule\"}','{\"style\":\"xhtml\"}','','',0,'2011-09-18 15:22:50',0,0),(407,'plg_content_pagebreak','plugin','pagebreak','content',0,1,1,0,'{\"name\":\"plg_content_pagebreak\",\"type\":\"plugin\",\"creationDate\":\"November 2005\",\"author\":\"Core Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_CONTENT_PAGEBREAK_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"pagebreak\"}','{\"title\":\"1\",\"multipage_toc\":\"1\",\"showall\":\"1\"}','','',0,'0000-00-00 00:00:00',4,0),(408,'plg_content_pagenavigation','plugin','pagenavigation','content',0,1,1,0,'{\"name\":\"plg_content_pagenavigation\",\"type\":\"plugin\",\"creationDate\":\"January 2006\",\"author\":\"Core Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_PAGENAVIGATION_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"pagenavigation\"}','{\"position\":\"1\"}','','',0,'0000-00-00 00:00:00',5,0),(409,'plg_content_vote','plugin','vote','content',0,1,1,0,'{\"name\":\"plg_content_vote\",\"type\":\"plugin\",\"creationDate\":\"November 2005\",\"author\":\"Core Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_VOTE_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"vote\"}','','','',0,'0000-00-00 00:00:00',6,0),(410,'plg_editors_codemirror','plugin','codemirror','editors',0,1,1,1,'{\"name\":\"plg_editors_codemirror\",\"type\":\"plugin\",\"creationDate\":\"28 March 2011\",\"author\":\"Marijn Haverbeke\",\"copyright\":\"Copyright (C) 2014 by Marijn Haverbeke <marijnh@gmail.com> and others\",\"authorEmail\":\"marijnh@gmail.com\",\"authorUrl\":\"http:\\/\\/codemirror.net\\/\",\"version\":\"5.12\",\"description\":\"PLG_CODEMIRROR_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"codemirror\"}','{\"lineNumbers\":\"1\",\"lineWrapping\":\"1\",\"matchTags\":\"1\",\"matchBrackets\":\"1\",\"marker-gutter\":\"1\",\"autoCloseTags\":\"1\",\"autoCloseBrackets\":\"1\",\"autoFocus\":\"1\",\"theme\":\"default\",\"tabmode\":\"indent\"}','','',0,'0000-00-00 00:00:00',1,0),(411,'plg_editors_none','plugin','none','editors',0,1,1,1,'{\"name\":\"plg_editors_none\",\"type\":\"plugin\",\"creationDate\":\"September 2005\",\"author\":\"Core Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_NONE_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"none\"}','','','',0,'0000-00-00 00:00:00',2,0),(412,'plg_editors_tinymce','plugin','tinymce','editors',0,1,1,0,'{\"name\":\"plg_editors_tinymce\",\"type\":\"plugin\",\"creationDate\":\"2005-2016\",\"author\":\"Ephox Corporation\",\"copyright\":\"Ephox Corporation\",\"authorEmail\":\"N\\/A\",\"authorUrl\":\"http:\\/\\/www.tinymce.com\",\"version\":\"4.3.3\",\"description\":\"PLG_TINY_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"tinymce\"}','{\"mode\":\"1\",\"skin\":\"0\",\"mobile\":\"0\",\"entity_encoding\":\"raw\",\"lang_mode\":\"1\",\"text_direction\":\"ltr\",\"content_css\":\"1\",\"content_css_custom\":\"\",\"relative_urls\":\"1\",\"newlines\":\"0\",\"invalid_elements\":\"script,applet,iframe\",\"extended_elements\":\"\",\"html_height\":\"550\",\"html_width\":\"750\",\"resizing\":\"1\",\"element_path\":\"1\",\"fonts\":\"1\",\"paste\":\"1\",\"searchreplace\":\"1\",\"insertdate\":\"1\",\"colors\":\"1\",\"table\":\"1\",\"smilies\":\"1\",\"hr\":\"1\",\"link\":\"1\",\"media\":\"1\",\"print\":\"1\",\"directionality\":\"1\",\"fullscreen\":\"1\",\"alignment\":\"1\",\"visualchars\":\"1\",\"visualblocks\":\"1\",\"nonbreaking\":\"1\",\"template\":\"1\",\"blockquote\":\"1\",\"wordcount\":\"1\",\"advlist\":\"1\",\"autosave\":\"1\",\"contextmenu\":\"1\",\"inlinepopups\":\"1\",\"custom_plugin\":\"\",\"custom_button\":\"\"}','','',0,'0000-00-00 00:00:00',3,0),(413,'plg_editors-xtd_article','plugin','article','editors-xtd',0,1,6,0,'{\"name\":\"plg_editors-xtd_article\",\"type\":\"plugin\",\"creationDate\":\"October 2009\",\"author\":\"Core Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_ARTICLE_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"article\"}','','','',0,'0000-00-00 00:00:00',1,0),(414,'plg_editors-xtd_image','plugin','image','editors-xtd',0,1,1,0,'{\"name\":\"plg_editors-xtd_image\",\"type\":\"plugin\",\"creationDate\":\"August 2004\",\"author\":\"Core Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_IMAGE_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"image\"}','','','',0,'0000-00-00 00:00:00',2,0),(415,'plg_editors-xtd_pagebreak','plugin','pagebreak','editors-xtd',0,1,6,0,'{\"name\":\"plg_editors-xtd_pagebreak\",\"type\":\"plugin\",\"creationDate\":\"August 2004\",\"author\":\"Core Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_EDITORSXTD_PAGEBREAK_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"pagebreak\"}','','','',0,'0000-00-00 00:00:00',3,0),(416,'plg_editors-xtd_readmore','plugin','readmore','editors-xtd',0,1,6,0,'{\"name\":\"plg_editors-xtd_readmore\",\"type\":\"plugin\",\"creationDate\":\"March 2006\",\"author\":\"Core Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_READMORE_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"readmore\"}','','','',0,'0000-00-00 00:00:00',4,0),(417,'plg_search_categories','plugin','categories','search',0,1,1,0,'{\"name\":\"plg_search_categories\",\"type\":\"plugin\",\"creationDate\":\"November 2005\",\"author\":\"Core Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_SEARCH_CATEGORIES_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"categories\"}','{\"search_limit\":\"50\",\"search_content\":\"1\",\"search_archived\":\"1\"}','','',0,'0000-00-00 00:00:00',0,0),(418,'plg_search_contacts','plugin','contacts','search',0,1,1,0,'{\"name\":\"plg_search_contacts\",\"type\":\"plugin\",\"creationDate\":\"November 2005\",\"author\":\"Core Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_SEARCH_CONTACTS_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"contacts\"}','{\"search_limit\":\"50\",\"search_content\":\"1\",\"search_archived\":\"1\"}','','',0,'0000-00-00 00:00:00',0,0),(419,'plg_search_content','plugin','content','search',0,1,1,0,'{\"name\":\"plg_search_content\",\"type\":\"plugin\",\"creationDate\":\"November 2005\",\"author\":\"Core Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_SEARCH_CONTENT_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"content\"}','{\"search_limit\":\"50\",\"search_content\":\"1\",\"search_archived\":\"1\"}','','',0,'0000-00-00 00:00:00',0,0),(420,'plg_search_newsfeeds','plugin','newsfeeds','search',0,1,1,0,'{\"name\":\"plg_search_newsfeeds\",\"type\":\"plugin\",\"creationDate\":\"November 2005\",\"author\":\"Core Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_SEARCH_NEWSFEEDS_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"newsfeeds\"}','{\"search_limit\":\"50\",\"search_content\":\"1\",\"search_archived\":\"1\"}','','',0,'0000-00-00 00:00:00',0,0),(422,'plg_system_languagefilter','plugin','languagefilter','system',0,1,1,1,'{\"name\":\"plg_system_languagefilter\",\"type\":\"plugin\",\"creationDate\":\"July 2010\",\"author\":\"Core Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_SYSTEM_LANGUAGEFILTER_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"languagefilter\"}','','','',0,'0000-00-00 00:00:00',1,0),(423,'plg_system_p3p','plugin','p3p','system',0,0,1,0,'{\"name\":\"plg_system_p3p\",\"type\":\"plugin\",\"creationDate\":\"September 2010\",\"author\":\"Core Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_P3P_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"p3p\"}','{\"headers\":\"NOI ADM DEV PSAi COM NAV OUR OTRo STP IND DEM\"}','','',0,'0000-00-00 00:00:00',2,0),(424,'plg_system_cache','plugin','cache','system',0,0,1,1,'{\"name\":\"plg_system_cache\",\"type\":\"plugin\",\"creationDate\":\"February 2007\",\"author\":\"Core Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_CACHE_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"cache\"}','{\"browsercache\":\"0\",\"cachetime\":\"15\"}','','',0,'0000-00-00 00:00:00',9,0),(425,'plg_system_debug','plugin','debug','system',0,1,1,0,'{\"name\":\"plg_system_debug\",\"type\":\"plugin\",\"creationDate\":\"December 2006\",\"author\":\"Core Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_DEBUG_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"debug\"}','{\"profile\":\"1\",\"queries\":\"1\",\"memory\":\"1\",\"language_files\":\"1\",\"language_strings\":\"1\",\"strip-first\":\"1\",\"strip-prefix\":\"\",\"strip-suffix\":\"\"}','','',0,'0000-00-00 00:00:00',4,0),(426,'plg_system_log','plugin','log','system',0,1,1,1,'{\"name\":\"plg_system_log\",\"type\":\"plugin\",\"creationDate\":\"April 2007\",\"author\":\"Core Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_LOG_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"log\"}','','','',0,'0000-00-00 00:00:00',5,0),(427,'plg_system_redirect','plugin','redirect','system',0,0,1,1,'{\"name\":\"plg_system_redirect\",\"type\":\"plugin\",\"creationDate\":\"April 2009\",\"author\":\"Core Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_SYSTEM_REDIRECT_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"redirect\"}','','','',0,'0000-00-00 00:00:00',6,0),(428,'plg_system_remember','plugin','remember','system',0,0,1,1,'{\"name\":\"plg_system_remember\",\"type\":\"plugin\",\"creationDate\":\"April 2007\",\"author\":\"Core Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_REMEMBER_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"remember\"}','','','',0,'0000-00-00 00:00:00',7,0),(429,'plg_system_sef','plugin','sef','system',0,1,1,0,'{\"name\":\"plg_system_sef\",\"type\":\"plugin\",\"creationDate\":\"December 2007\",\"author\":\"Core Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_SEF_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"sef\"}','','','',0,'0000-00-00 00:00:00',8,0),(430,'plg_system_logout','plugin','logout','system',0,1,1,1,'{\"name\":\"plg_system_logout\",\"type\":\"plugin\",\"creationDate\":\"April 2009\",\"author\":\"Core Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_SYSTEM_LOGOUT_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"logout\"}','','','',0,'0000-00-00 00:00:00',3,0),(431,'plg_user_contactcreator','plugin','contactcreator','user',0,0,1,0,'{\"name\":\"plg_user_contactcreator\",\"type\":\"plugin\",\"creationDate\":\"August 2009\",\"author\":\"Core Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_CONTACTCREATOR_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"contactcreator\"}','{\"autowebpage\":\"\",\"category\":\"34\",\"autopublish\":\"0\"}','','',0,'0000-00-00 00:00:00',1,0),(432,'plg_user_joomla','plugin','joomla','user',0,1,1,0,'{\"name\":\"plg_user_joomla\",\"type\":\"plugin\",\"creationDate\":\"December 2006\",\"author\":\"Core Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_USER_JOOMLA_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"joomla\"}','{\"autoregister\":\"1\",\"mail_to_user\":\"0\",\"forceLogout\":\"1\"}','','',0,'0000-00-00 00:00:00',2,0),(433,'plg_user_profile','plugin','profile','user',0,0,1,0,'{\"name\":\"plg_user_profile\",\"type\":\"plugin\",\"creationDate\":\"January 2008\",\"author\":\"Core Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_USER_PROFILE_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"profile\"}','{\"register-require_address1\":\"1\",\"register-require_address2\":\"1\",\"register-require_city\":\"1\",\"register-require_region\":\"1\",\"register-require_country\":\"1\",\"register-require_postal_code\":\"1\",\"register-require_phone\":\"1\",\"register-require_website\":\"1\",\"register-require_favoritebook\":\"1\",\"register-require_aboutme\":\"1\",\"register-require_tos\":\"1\",\"register-require_dob\":\"1\",\"profile-require_address1\":\"1\",\"profile-require_address2\":\"1\",\"profile-require_city\":\"1\",\"profile-require_region\":\"1\",\"profile-require_country\":\"1\",\"profile-require_postal_code\":\"1\",\"profile-require_phone\":\"1\",\"profile-require_website\":\"1\",\"profile-require_favoritebook\":\"1\",\"profile-require_aboutme\":\"1\",\"profile-require_tos\":\"1\",\"profile-require_dob\":\"1\"}','','',0,'0000-00-00 00:00:00',0,0),(434,'plg_extension_joomla','plugin','joomla','extension',0,1,1,1,'{\"name\":\"plg_extension_joomla\",\"type\":\"plugin\",\"creationDate\":\"May 2010\",\"author\":\"Core Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_EXTENSION_JOOMLA_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"joomla\"}','','','',0,'0000-00-00 00:00:00',1,0),(435,'plg_content_joomla','plugin','joomla','content',0,1,1,0,'{\"name\":\"plg_content_joomla\",\"type\":\"plugin\",\"creationDate\":\"November 2010\",\"author\":\"Core Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_CONTENT_JOOMLA_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"joomla\"}','','','',0,'0000-00-00 00:00:00',0,0),(436,'plg_system_languagecode','plugin','languagecode','system',0,1,1,0,'{\"name\":\"plg_system_languagecode\",\"type\":\"plugin\",\"creationDate\":\"November 2011\",\"author\":\"Core Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_SYSTEM_LANGUAGECODE_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"languagecode\"}','','','',0,'0000-00-00 00:00:00',10,0),(437,'plg_quickicon_joomlaupdate','plugin','joomlaupdate','quickicon',0,0,1,1,'{\"name\":\"plg_quickicon_joomlaupdate\",\"type\":\"plugin\",\"creationDate\":\"August 2011\",\"author\":\"Core Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_QUICKICON_JOOMLAUPDATE_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"joomlaupdate\"}','','','',0,'0000-00-00 00:00:00',0,0),(438,'plg_quickicon_extensionupdate','plugin','extensionupdate','quickicon',0,0,1,1,'{\"name\":\"plg_quickicon_extensionupdate\",\"type\":\"plugin\",\"creationDate\":\"August 2011\",\"author\":\"Core Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_QUICKICON_EXTENSIONUPDATE_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"extensionupdate\"}','','','',0,'0000-00-00 00:00:00',0,0),(439,'plg_captcha_recaptcha','plugin','recaptcha','captcha',0,1,1,0,'{\"name\":\"plg_captcha_recaptcha\",\"type\":\"plugin\",\"creationDate\":\"December 2011\",\"author\":\"Core Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.4.0\",\"description\":\"PLG_CAPTCHA_RECAPTCHA_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"recaptcha\"}','{\"version\":\"1.0\",\"public_key\":\"6Ld4fykUAAAAAHJhqJLKxvf8k0gRWVQIjPtnTcuD\",\"private_key\":\"6Ld4fykUAAAAAI7t6Y7IlVnsE787mYnh1vDsbz2k\",\"theme\":\"clean\",\"theme2\":\"light\",\"size\":\"normal\"}','','',0,'0000-00-00 00:00:00',0,0),(440,'plg_system_highlight','plugin','highlight','system',0,1,1,0,'{\"name\":\"plg_system_highlight\",\"type\":\"plugin\",\"creationDate\":\"August 2011\",\"author\":\"Core Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_SYSTEM_HIGHLIGHT_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"highlight\"}','','','',0,'0000-00-00 00:00:00',7,0),(441,'plg_content_finder','plugin','finder','content',0,0,1,0,'{\"name\":\"plg_content_finder\",\"type\":\"plugin\",\"creationDate\":\"December 2011\",\"author\":\"Core Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_CONTENT_FINDER_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"finder\"}','','','',0,'0000-00-00 00:00:00',0,0),(442,'plg_finder_categories','plugin','categories','finder',0,1,1,0,'{\"name\":\"plg_finder_categories\",\"type\":\"plugin\",\"creationDate\":\"August 2011\",\"author\":\"Core Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_FINDER_CATEGORIES_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"categories\"}','','','',0,'0000-00-00 00:00:00',1,0),(443,'plg_finder_contacts','plugin','contacts','finder',0,1,1,0,'{\"name\":\"plg_finder_contacts\",\"type\":\"plugin\",\"creationDate\":\"August 2011\",\"author\":\"Core Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_FINDER_CONTACTS_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"contacts\"}','','','',0,'0000-00-00 00:00:00',2,0),(444,'plg_finder_content','plugin','content','finder',0,1,1,0,'{\"name\":\"plg_finder_content\",\"type\":\"plugin\",\"creationDate\":\"August 2011\",\"author\":\"Core Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_FINDER_CONTENT_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"content\"}','','','',0,'0000-00-00 00:00:00',3,0),(445,'plg_finder_newsfeeds','plugin','newsfeeds','finder',0,1,1,0,'{\"name\":\"plg_finder_newsfeeds\",\"type\":\"plugin\",\"creationDate\":\"August 2011\",\"author\":\"Core Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_FINDER_NEWSFEEDS_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"newsfeeds\"}','','','',0,'0000-00-00 00:00:00',4,0),(447,'plg_finder_tags','plugin','tags','finder',0,1,1,0,'{\"name\":\"plg_finder_tags\",\"type\":\"plugin\",\"creationDate\":\"February 2013\",\"author\":\"Core Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_FINDER_TAGS_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"tags\"}','','','',0,'0000-00-00 00:00:00',0,0),(448,'plg_twofactorauth_totp','plugin','totp','twofactorauth',0,0,1,0,'{\"name\":\"plg_twofactorauth_totp\",\"type\":\"plugin\",\"creationDate\":\"August 2013\",\"author\":\"Core Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.2.0\",\"description\":\"PLG_TWOFACTORAUTH_TOTP_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"totp\"}','','','',0,'0000-00-00 00:00:00',0,0),(449,'plg_authentication_cookie','plugin','cookie','authentication',0,1,1,0,'{\"name\":\"plg_authentication_cookie\",\"type\":\"plugin\",\"creationDate\":\"July 2013\",\"author\":\"Core Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_AUTH_COOKIE_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"cookie\"}','','','',0,'0000-00-00 00:00:00',0,0),(450,'plg_twofactorauth_yubikey','plugin','yubikey','twofactorauth',0,0,1,0,'{\"name\":\"plg_twofactorauth_yubikey\",\"type\":\"plugin\",\"creationDate\":\"September 2013\",\"author\":\"Core Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.2.0\",\"description\":\"PLG_TWOFACTORAUTH_YUBIKEY_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"yubikey\"}','','','',0,'0000-00-00 00:00:00',0,0),(451,'plg_search_tags','plugin','tags','search',0,1,1,0,'{\"name\":\"plg_search_tags\",\"type\":\"plugin\",\"creationDate\":\"March 2014\",\"author\":\"Core Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.0.0\",\"description\":\"PLG_SEARCH_TAGS_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"tags\"}','{\"search_limit\":\"50\",\"show_tagged_items\":\"1\"}','','',0,'0000-00-00 00:00:00',0,0),(452,'plg_system_updatenotification','plugin','updatenotification','system',0,0,1,0,'{\"name\":\"plg_system_updatenotification\",\"type\":\"plugin\",\"creationDate\":\"May 2015\",\"author\":\"Core Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.5.0\",\"description\":\"PLG_SYSTEM_UPDATENOTIFICATION_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"updatenotification\"}','{\"lastrun\":1463152784}','','',0,'0000-00-00 00:00:00',0,0),(453,'plg_editors-xtd_module','plugin','module','editors-xtd',0,1,6,0,'{\"name\":\"plg_editors-xtd_module\",\"type\":\"plugin\",\"creationDate\":\"October 2015\",\"author\":\"Core Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.5.0\",\"description\":\"PLG_MODULE_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"module\"}','','','',0,'0000-00-00 00:00:00',0,0),(454,'plg_system_stats','plugin','stats','system',0,1,1,0,'{\"name\":\"plg_system_stats\",\"type\":\"plugin\",\"creationDate\":\"November 2013\",\"author\":\"Core Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.5.0\",\"description\":\"PLG_SYSTEM_STATS_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"stats\"}','{\"mode\":3,\"lastrun\":1459159729,\"unique_id\":\"c86dfa92cbc1a69b75380041354fb01f3601cfab\",\"interval\":12}','','',0,'0000-00-00 00:00:00',0,0),(507,'isis','template','isis','',1,1,1,0,'{\"name\":\"isis\",\"type\":\"template\",\"creationDate\":\"3\\/30\\/2012\",\"author\":\"Kyle Ledbetter\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters, Inc. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"\",\"version\":\"1.0\",\"description\":\"TPL_ISIS_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"templateDetails\"}','{\"templateColor\":\"\",\"logoFile\":\"\"}','','',0,'0000-00-00 00:00:00',0,0),(600,'English (en-GB)','language','en-GB','',0,1,1,1,'{\"name\":\"English (en-GB)\",\"type\":\"language\",\"creationDate\":\"November 2015\",\"author\":\"Core Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.5.0\",\"description\":\"en-GB site language\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(601,'English (en-GB)','language','en-GB','',1,1,1,1,'{\"name\":\"English (en-GB)\",\"type\":\"language\",\"creationDate\":\"November 2015\",\"author\":\"Core Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.5.0\",\"description\":\"en-GB administrator language\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(700,'files_joomla','file','joomla','',0,1,1,1,'{\"name\":\"files_joomla\",\"type\":\"file\",\"creationDate\":\"March 2016\",\"author\":\"Core Project\",\"copyright\":\"(C) 2005 - 2016 Open Source Matters. All rights reserved\",\"authorEmail\":\"admin@joomla.org\",\"authorUrl\":\"www.joomla.org\",\"version\":\"3.5.0\",\"description\":\"FILES_JOOMLA_XML_DESCRIPTION\",\"group\":\"\"}','','','',0,'0000-00-00 00:00:00',0,0),(10000,'PLG_SYS_ADMINEXILE','plugin','adminexile','system',0,1,1,0,'{\"name\":\"PLG_SYS_ADMINEXILE\",\"type\":\"plugin\",\"creationDate\":\"Jan 2011\",\"author\":\"Michael Richey\",\"copyright\":\"Copyright (C) 2011 Michael Richey. All rights reserved.\",\"authorEmail\":\"adminexile@richeyweb.com\",\"authorUrl\":\"http:\\/\\/www.richeyweb.com\",\"version\":\"2.3.6\",\"description\":\"PLG_SYS_ADMINEXILE_XML_DESC\",\"group\":\"\",\"filename\":\"adminexile\"}','{\"key\":\"core\",\"twofactor\":\"0\",\"keyvalue\":\"ROCKS\",\"tmpwhitelist\":\"0\",\"tmpperiod\":\"60\",\"redirect\":\"{HOME}\",\"fourofour\":\"<!DOCTYPE HTML PUBLIC \\\"-\\/\\/IETF\\/\\/DTD HTML 2.0\\/\\/EN\\\">\\r\\n<html><head>\\r\\n<title>404 Not Found<\\/title>\\r\\n<\\/head><body>\\r\\n<h1>Not Found<\\/h1>\\r\\n<p>The requested URL {url} was not found on this server.<\\/p>\\r\\n<hr>\\r\\n{serversignature}\\r\\n<\\/body><\\/html>\",\"frontrestrict\":\"0\",\"maillink\":\"1\",\"maillinkgroup\":[\"8\"],\"ipsecurity\":\"0\",\"whitelist\":\"[\\\"127.0.0.1\\\"]\",\"blacklist\":\"[\\\"192.168.0.0\\/16\\\",\\\"169.254.0.0\\/16\\\",\\\"172.16.0.0\\/12\\\",\\\"10.0.0.0\\/8\\\"]\",\"blemail\":\"0\",\"blemailonce\":\"1\",\"blemailuser\":\"0\",\"bruteforce\":\"0\",\"bfmax\":\"5\",\"bfpenalty\":\"5\",\"bfpenaltymultiplier\":\"1\",\"bfemail\":\"0\",\"bfemailonce\":\"1\",\"bfemailuser\":\"0\"}','','',0,'0000-00-00 00:00:00',0,0),(10015,'synathina','template','synathina','',0,1,1,0,'{\"name\":\"synathina\",\"type\":\"template\",\"creationDate\":\"3\\/28\\/2016\",\"author\":\"ddasios\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters, Inc. All rights reserved.\",\"authorEmail\":\"ddasios@steficon.gr\",\"authorUrl\":\"\",\"version\":\"1.0\",\"description\":\"TPL_SYNATHINA_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"templateDetails\"}','','','',0,'0000-00-00 00:00:00',0,0),(10016,'Hellenic','language','el-GR','',0,1,0,0,'{\"name\":\"Hellenic\",\"type\":\"language\",\"creationDate\":\"2015-06-13\",\"author\":\"Greek translation team : joomla.gr\",\"copyright\":\"Copyright (C) 2005 - 2013 joomla.gr \\u03ba\\u03b1\\u03b9 Open Source Matters. All rights reserved.\",\"authorEmail\":\"joomla@joomla.gr\",\"authorUrl\":\"http:\\/\\/www.joomla.gr\",\"version\":\"3.4.2.1\",\"description\":\"Greek language pack for Joomla! 3.4.2\",\"group\":\"\",\"filename\":\"install\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(10017,'Greek','language','el-GR','',1,1,0,0,'{\"name\":\"Greek\",\"type\":\"language\",\"creationDate\":\"2015-06-13\",\"author\":\"Greek translation team : joomla.gr\",\"copyright\":\"Copyright (C) 2005 - 2013 joomla.gr \\u03ba\\u03b1\\u03b9 Open Source Matters. All rights reserved.\",\"authorEmail\":\"joomla@joomla.gr\",\"authorUrl\":\"http:\\/\\/www.joomla.gr\",\"version\":\"3.4.2.1\",\"description\":\"Greek language pack for Joomla! 3.4.2\",\"group\":\"\",\"filename\":\"install\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(10018,'Greek Language Pack','package','pkg_el-GR','',0,1,1,0,'{\"name\":\"Greek Language Pack\",\"type\":\"package\",\"creationDate\":\"2015-06-13\",\"author\":\"Greek translation team : joomla.gr\",\"copyright\":\"Copyright (C) 2005 - 2013 joomla.gr \\u03ba\\u03b1\\u03b9 Open Source Matters. All rights reserved.\",\"authorEmail\":\"joomla@joomla.gr\",\"authorUrl\":\"http:\\/\\/www.joomla.gr\",\"version\":\"3.4.2.1\",\"description\":\"Greek language pack for Joomla! 3.4.2 - \\u0391\\u03c1\\u03c7\\u03b5\\u03af\\u03b1 \\u03b5\\u03bb\\u03bb\\u03b7\\u03bd\\u03b9\\u03ba\\u03ae\\u03c2 \\u03b3\\u03bb\\u03ce\\u03c3\\u03c3\\u03b1\\u03c2 \\u03b3\\u03b9\\u03b1 \\u03c4\\u03b7\\u03bd \\u03ad\\u03ba\\u03b4\\u03bf\\u03c3\\u03b7 Joomla! 3.4.2 \\u03b1\\u03c0\\u03cc \\u03c4\\u03b7\\u03bd \\u03bf\\u03bc\\u03ac\\u03b4\\u03b1 \\u03c4\\u03bf\\u03c5 joomla.gr\",\"group\":\"\",\"filename\":\"pkg_el-GR\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(10019,'JCE','component','com_jce','',1,1,0,0,'{\"name\":\"JCE\",\"type\":\"component\",\"creationDate\":\"08 April 2016\",\"author\":\"Ryan Demmer\",\"copyright\":\"Copyright (C) 2006 - 2016 Ryan Demmer. All rights reserved\",\"authorEmail\":\"info@joomlacontenteditor.net\",\"authorUrl\":\"www.joomlacontenteditor.net\",\"version\":\"2.5.16\",\"description\":\"WF_ADMIN_DESC\",\"group\":\"\",\"filename\":\"jce\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(10020,'plg_editors_jce','plugin','jce','editors',0,1,1,0,'{\"name\":\"plg_editors_jce\",\"type\":\"plugin\",\"creationDate\":\"08 April 2016\",\"author\":\"Ryan Demmer\",\"copyright\":\"Copyright (C) 2006 - 2016 Ryan Demmer. All rights reserved\",\"authorEmail\":\"info@joomlacontenteditor.net\",\"authorUrl\":\"http:\\/\\/www.joomlacontenteditor.net\",\"version\":\"2.5.16\",\"description\":\"WF_EDITOR_PLUGIN_DESC\",\"group\":\"\",\"filename\":\"jce\"}','{\"verify_html\":\"1\",\"schema\":\"mixed\",\"entity_encoding\":\"raw\",\"keep_nbsp\":\"1\",\"pad_empty_tags\":\"1\",\"cleanup_pluginmode\":\"0\",\"forced_root_block\":\"p\",\"content_style_reset\":\"0\",\"content_css\":\"1\",\"content_css_custom\":\"\",\"body_class\":\"\",\"compress_javascript\":\"1\",\"compress_css\":\"1\",\"compress_gzip\":\"0\",\"use_cookies\":\"1\",\"custom_config\":\"\",\"callback_file\":\"\"}','','',0,'0000-00-00 00:00:00',0,0),(10021,'plg_system_jce','plugin','jce','system',0,1,1,0,'{\"name\":\"plg_system_jce\",\"type\":\"plugin\",\"creationDate\":\"08 April 2016\",\"author\":\"Ryan Demmer\",\"copyright\":\"Copyright (C) 2006 - 2016 Ryan Demmer. All rights reserved\",\"authorEmail\":\"info@joomlacontenteditor.net\",\"authorUrl\":\"http:\\/\\/www.joomlacontenteditor.net\",\"version\":\"2.5.16\",\"description\":\"PLG_JCE_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"jce\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(10022,'plg_quickicon_jcefilebrowser','plugin','jcefilebrowser','quickicon',0,1,1,0,'{\"name\":\"plg_quickicon_jcefilebrowser\",\"type\":\"plugin\",\"creationDate\":\"08 April 2016\",\"author\":\"Ryan Demmer\",\"copyright\":\"Copyright (C) 2006 - 2016 Ryan Demmer. All rights reserved\",\"authorEmail\":\"@@email@@\",\"authorUrl\":\"www.joomalcontenteditor.net\",\"version\":\"2.5.16\",\"description\":\"PLG_QUICKICON_JCEFILEBROWSER_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"jcefilebrowser\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(10023,'plg_content_attachments','plugin','attachments','content',0,1,1,0,'{\"name\":\"plg_content_attachments\",\"type\":\"plugin\",\"creationDate\":\"March 20, 2015\",\"author\":\"Jonathan M. Cameron\",\"copyright\":\"(C) 2007-2015 Jonathan M. Cameron. All rights reserved.\",\"authorEmail\":\"jmcameron@jmcameron.net\",\"authorUrl\":\"http:\\/\\/joomlacode.org\\/gf\\/project\\/attachments\\/\",\"version\":\"3.2.3\",\"description\":\"ATTACH_ATTACHMENTS_PLUGIN_DESCRIPTION\",\"group\":\"\",\"filename\":\"attachments\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(10024,'plg_search_attachments','plugin','attachments','search',0,1,1,0,'{\"name\":\"plg_search_attachments\",\"type\":\"plugin\",\"creationDate\":\"March 20, 2015\",\"author\":\"Jonathan M. Cameron\",\"copyright\":\"(C) 2007-2015 Jonathan M. Cameron. All rights reserved.\",\"authorEmail\":\"jmcameron@jmcameron.net\",\"authorUrl\":\"http:\\/\\/joomlacode.org\\/gf\\/project\\/attachments\\/\",\"version\":\"3.2.3\",\"description\":\"ATTACH_ATTACHMENTS_SEARCH_PLUGIN_DESCRIPTION\",\"group\":\"\",\"filename\":\"attachments\"}','{\"search_limit\":\"50\"}','','',0,'0000-00-00 00:00:00',0,0),(10025,'plg_attachments_plugin_framework','plugin','attachments_plugin_framework','attachments',0,1,1,0,'{\"name\":\"plg_attachments_plugin_framework\",\"type\":\"plugin\",\"creationDate\":\"March 20, 2015\",\"author\":\"Jonathan M. Cameron\",\"copyright\":\"(C) 2009-2015 Jonathan M. Cameron. All rights reserved.\",\"authorEmail\":\"jmcameron@jmcameron.net\",\"authorUrl\":\"http:\\/\\/joomlacode.org\\/gf\\/project\\/attachments\\/\",\"version\":\"3.2.3\",\"description\":\"ATTACH_ATTACHMENTS_FOR_COMPONENTS_PLUGIN_FRAMEWORK_DESCRIPTION\",\"group\":\"\",\"filename\":\"attachments_plugin_framework\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(10026,'plg_attachments_for_content','plugin','attachments_for_content','attachments',0,1,6,0,'{\"name\":\"plg_attachments_for_content\",\"type\":\"plugin\",\"creationDate\":\"March 20, 2015\",\"author\":\"Jonathan M. Cameron\",\"copyright\":\"(C) 2009-2015 Jonathan M. Cameron. All rights reserved.\",\"authorEmail\":\"jmcameron@jmcameron.net\",\"authorUrl\":\"http:\\/\\/joomlacode.org\\/gf\\/project\\/attachments\\/\",\"version\":\"3.2.3\",\"description\":\"ATTACH_ATTACHMENTS_FOR_CONTENT_PLUGIN_DESCRIPTION\",\"group\":\"\",\"filename\":\"attachments_for_content\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(10027,'plg_system_show_attachments_in_editor','plugin','show_attachments','system',0,1,1,0,'{\"name\":\"plg_system_show_attachments_in_editor\",\"type\":\"plugin\",\"creationDate\":\"March 20, 2015\",\"author\":\"Jonathan M. Cameron\",\"copyright\":\"(C) 2011-2015 Jonathan M. Cameron. All rights reserved.\",\"authorEmail\":\"jmcameron@jmcameron.net\",\"authorUrl\":\"http:\\/\\/joomlacode.org\\/gf\\/project\\/attachments\\/\",\"version\":\"3.2.3\",\"description\":\"ATTACH_SHOW_ATTACHMENTS_IN_EDITOR_PLUGIN_DESCRIPTION\",\"group\":\"\",\"filename\":\"show_attachments\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(10028,'plg_editors-xtd_add_attachment_btn','plugin','add_attachment','editors-xtd',0,1,1,0,'{\"name\":\"plg_editors-xtd_add_attachment_btn\",\"type\":\"plugin\",\"creationDate\":\"March 20, 2015\",\"author\":\"Jonathan M. Cameron\",\"copyright\":\"(C) 2007-2015 Jonathan M. Cameron. All rights reserved.\",\"authorEmail\":\"jmcameron@jmcameron.net\",\"authorUrl\":\"http:\\/\\/joomlacode.org\\/gf\\/project\\/attachments\\/\",\"version\":\"3.2.3\",\"description\":\"ATTACH_ADD_ATTACHMENT_BUTTON_PLUGIN_DESCRIPTION\",\"group\":\"\",\"filename\":\"add_attachment\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(10029,'plg_editors-xtd_insert_attachments_token_btn','plugin','insert_attachments_token','editors-xtd',0,1,1,0,'{\"name\":\"plg_editors-xtd_insert_attachments_token_btn\",\"type\":\"plugin\",\"creationDate\":\"March 20, 2015\",\"author\":\"Jonathan M. Cameron\",\"copyright\":\"(C) 2007-2015 Jonathan M. Cameron. All rights reserved.\",\"authorEmail\":\"jmcameron@jmcameron.net\",\"authorUrl\":\"http:\\/\\/joomlacode.org\\/gf\\/project\\/attachments\\/\",\"version\":\"3.2.3\",\"description\":\"ATTACH_INSERT_ATTACHMENTS_TOKEN_BUTTON_PLUGIN_DESCRIPTION\",\"group\":\"\",\"filename\":\"insert_attachments_token\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(10030,'plg_quickicon_attachments','plugin','attachments','quickicon',0,1,1,0,'{\"name\":\"plg_quickicon_attachments\",\"type\":\"plugin\",\"creationDate\":\"March 20, 2015\",\"author\":\"Jonathan M. Cameron\",\"copyright\":\"(C) 2007-2015 Jonathan M. Cameron. All rights reserved.\",\"authorEmail\":\"jmcameron@jmcameron.net\",\"authorUrl\":\"http:\\/\\/joomlacode.org\\/gf\\/project\\/attachments\\/\",\"version\":\"3.2.3\",\"description\":\"PLG_QUICKICON_ATTACHMENTS_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"attachments\"}','{\"context\":\"mod_quickicon\"}','','',0,'0000-00-00 00:00:00',0,0),(10031,'com_attachments','component','com_attachments','',1,1,0,0,'{\"name\":\"com_attachments\",\"type\":\"component\",\"creationDate\":\"March 20, 2015\",\"author\":\"Jonathan M. Cameron\",\"copyright\":\"(C) 2007-2015 Jonathan M. Cameron. All rights reserved.\",\"authorEmail\":\"jmcameron@jmcameron.net\",\"authorUrl\":\"http:\\/\\/joomlacode.org\\/gf\\/project\\/attachments3\\/\",\"version\":\"3.2.3\",\"description\":\"ATTACH_ATTACHMENTS_COMPONENT_DESCRIPTION\",\"group\":\"\",\"filename\":\"attachments\"}','{\"publish_default\":\"1\",\"auto_publish_warning\":\"\",\"default_access_level\":\"1\",\"user_field_1_name\":\"\",\"user_field_2_name\":\"\",\"user_field_3_name\":\"\",\"max_filename_length\":0,\"attachments_placement\":\"custom\",\"allow_frontend_access_editing\":\"0\",\"show_column_titles\":\"0\",\"show_description\":\"1\",\"show_creator_name\":\"0\",\"show_file_size\":\"0\",\"show_downloads\":\"0\",\"show_created_date\":\"0\",\"show_modified_date\":\"0\",\"date_format\":\"Y-m-d H:i\",\"sort_order\":\"filename\",\"hide_on_frontpage\":\"0\",\"hide_with_readmore\":\"0\",\"hide_on_blogs\":\"0\",\"hide_except_article_views\":\"0\",\"always_show_category_attachments\":\"0\",\"show_guest_access_levels\":[\"1\"],\"hide_add_attachments_link\":\"0\",\"max_attachment_size\":0,\"forbidden_filename_characters\":\"#=?%&\",\"attachments_table_style\":\"attachmentsList\",\"file_link_open_mode\":\"in_same_window\",\"attachments_titles\":\"Downloads\",\"link_check_timeout\":\"10\",\"superimpose_url_link_icons\":\"1\",\"suppress_obsolete_attachments\":\"0\",\"login_url\":\"index.php?option=com_users&view=login\",\"register_url\":\"index.php?option=com_users&view=registration\",\"secure\":\"0\",\"download_mode\":\"inline\"}','','',0,'0000-00-00 00:00:00',0,0),(10032,'pkg_attachments','package','pkg_attachments','',0,1,1,0,'{\"name\":\"pkg_attachments\",\"type\":\"package\",\"creationDate\":\"March 20, 2015\",\"author\":\"Jonathan M. Cameron\",\"copyright\":\"(C) 2007-2015 Jonathan M. Cameron. All rights reserved.\",\"authorEmail\":\"jmcameron@jmcameron.net\",\"authorUrl\":\"http:\\/\\/joomlacode.org\\/gf\\/project\\/attachments\\/\",\"version\":\"3.2.3\",\"description\":\"ATTACH_PACKAGE_ATTACHMENTS_FOR_JOOMLA_16PLUS\",\"group\":\"\",\"filename\":\"pkg_attachments\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(10033,'com_di','component','com_di','',1,1,0,0,'{\"name\":\"com_di\",\"type\":\"component\",\"creationDate\":\"February 2013\",\"author\":\"Dizi\",\"copyright\":\"Copyright (C) 2013 Dizi\",\"authorEmail\":\"labs@dizi.lt\",\"authorUrl\":\"http:\\/\\/www.dizi.lt\\/labs\",\"version\":\"1.0.3\",\"description\":\"COM_DI_DESCRIPTION\",\"group\":\"\"}','{\"use_featured\":1,\"quality\":70,\"manager_size\":\"regular\",\"delete_size_images\":1,\"delete_images_on_content_delete\":0}','','',0,'0000-00-00 00:00:00',0,0),(10034,'Dizi images','module','mod_images','',1,1,2,0,'{\"name\":\"Dizi images\",\"type\":\"module\",\"creationDate\":\"January 2013\",\"author\":\"Dizi\",\"copyright\":\"Copyright (C) 2013 dizi.lt\",\"authorEmail\":\"labs@dizi.lt\",\"authorUrl\":\"http:\\/\\/www.dizi.lt\\/labs\",\"version\":\"1.0.0\",\"description\":\"MOD_IMAGES_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_images\"}','','','',0,'0000-00-00 00:00:00',0,1),(10035,'plg_content_images','plugin','images','content',0,1,1,0,'{\"name\":\"plg_content_images\",\"type\":\"plugin\",\"creationDate\":\"January 2013\",\"author\":\"Dizi\",\"copyright\":\"Copyright (C) 2013 dizi.lt\",\"authorEmail\":\"labs@dizi.lt\",\"authorUrl\":\"http:\\/\\/www.dizi.lt\\/labs\",\"version\":\"1.0.0\",\"description\":\"PLG_IMAGES_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"images\"}','[]','','',0,'0000-00-00 00:00:00',0,0),(10036,'plg_system_images','plugin','images','system',0,1,1,0,'{\"name\":\"plg_system_images\",\"type\":\"plugin\",\"creationDate\":\"January 2013\",\"author\":\"Dizi\",\"copyright\":\"Copyright (C) 2013 dizi.lt\",\"authorEmail\":\"labs@dizi.lt\",\"authorUrl\":\"http:\\/\\/www.dizi.lt\\/labs\",\"version\":\"1.0.0\",\"description\":\"PLG_IMAGES_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"images\"}','','','',0,'0000-00-00 00:00:00',0,0),(10037,'Images gallery','module','mod_images','',0,1,0,0,'{\"name\":\"Images gallery\",\"type\":\"module\",\"creationDate\":\"January 2013\",\"author\":\"Dizi\",\"copyright\":\"Copyright (C) 2013 dizi.lt\",\"authorEmail\":\"labs@dizi.lt\",\"authorUrl\":\"http:\\/\\/www.dizi.lt\\/labs\",\"version\":\"1.0.0\",\"description\":\"MOD_IMAGES_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_images\"}','{\"fluid\":\"1\",\"load_fancybox\":\"1\",\"cache\":\"1\",\"cache_time\":\"900\"}','','',0,'0000-00-00 00:00:00',0,1),(10038,'Articles','module','mod_articles','',0,1,1,0,'{\"name\":\"mod_articles\",\"type\":\"module\",\"creationDate\":\"March 2016\",\"author\":\"Core Project\",\"copyright\":\"Copyright (C) 2005 - 2015 Open Source Matters. All rights reserved.\",\"authorEmail\":\"ddasios@steficon.gr\",\"authorUrl\":\"www.steficon.gr\",\"version\":\"3.0.0\",\"description\":\"MOD_ARTICLES_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_articles\"}','','','',0,'0000-00-00 00:00:00',0,0),(10039,'Teams','component','com_teams','',1,1,0,0,'{\"name\":\"Teams\",\"type\":\"component\",\"creationDate\":\"12.April.2016\",\"author\":\"ddasios\",\"copyright\":\"steficon.gr 2016\",\"authorEmail\":\"ddasios@steficon.gr\",\"authorUrl\":\"www.steficon.gr\",\"version\":\"1.0.0\",\"description\":\"Create teams\",\"group\":\"\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(10040,'plg_system_email','plugin','email','system',0,1,1,0,'{\"name\":\"plg_system_email\",\"type\":\"plugin\",\"creationDate\":\"August 2013\",\"author\":\"Michael Richey\",\"copyright\":\"Copyright (C) 2005 - 2011 Michael Richey. All rights reserved.\",\"authorEmail\":\"authemail@richeyweb.com\",\"authorUrl\":\"www.richeyweb.com\",\"version\":\"2.3\",\"description\":\"PLG_SYS_EMAIL_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"email\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(10041,'plg_authentication_email','plugin','email','authentication',0,1,1,0,'{\"name\":\"plg_authentication_email\",\"type\":\"plugin\",\"creationDate\":\"March 2011\",\"author\":\"Michael Richey\",\"copyright\":\"Copyright (C) 2005 - 2011 Michael Richey. All rights reserved.\",\"authorEmail\":\"authemail@richeyweb.com\",\"authorUrl\":\"www.richeyweb.com\",\"version\":\"2.3\",\"description\":\"PLG_AUTH_EMAIL_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"email\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(10042,'Authentication - Email','package','pkg_email','',0,1,1,0,'{\"name\":\"Authentication - Email\",\"type\":\"package\",\"creationDate\":\"March 2011\",\"author\":\"Michael Richey\",\"copyright\":\"\",\"authorEmail\":\"auth_email@richeyweb.com\",\"authorUrl\":\"http:\\/\\/www.richeyweb.com\",\"version\":\"2.3\",\"description\":\"Authentication - Email , authentication and system plugins\",\"group\":\"\",\"filename\":\"email\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(10043,'Teams','module','mod_teams','',0,1,1,0,'{\"name\":\"mod_teams\",\"type\":\"module\",\"creationDate\":\"May 2016\",\"author\":\"Core Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"ddasios@steficon.gr\",\"authorUrl\":\"www.steficon.gr\",\"version\":\"3.0.0\",\"description\":\"MOD_TEAMS_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_teams\"}','','','',0,'2016-05-12 08:49:43',0,0),(10044,'Actions','component','com_actions','',1,1,0,0,'{\"name\":\"Actions\",\"type\":\"component\",\"creationDate\":\"18.May.2016\",\"author\":\"ddasios\",\"copyright\":\"steficon.gr 2016\",\"authorEmail\":\"ddasios@steficon.gr\",\"authorUrl\":\"www.steficon.gr\",\"version\":\"1.0.0\",\"description\":\"Show actions\",\"group\":\"\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(10045,'Stegi','module','mod_stegi','',0,1,1,0,'{\"name\":\"mod_stegi\",\"type\":\"module\",\"creationDate\":\"May 2016\",\"author\":\"Core Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"ddasios@steficon.gr\",\"authorUrl\":\"www.steficon.gr\",\"version\":\"3.0.0\",\"description\":\"MOD_STEGI_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_stegi\"}','','','',0,'2016-05-12 08:49:43',0,0),(10046,'Toolkits','module','mod_toolkits','',0,1,1,0,'{\"name\":\"mod_toolkits\",\"type\":\"module\",\"creationDate\":\"May 2016\",\"author\":\"Core Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"ddasios@steficon.gr\",\"authorUrl\":\"www.steficon.gr\",\"version\":\"3.0.0\",\"description\":\"MOD_TOOLIKTS_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_toolkits\"}','','','',0,'2016-05-12 08:49:43',0,0),(10047,'Slider','module','mod_slider','',0,1,1,0,'{\"name\":\"mod_slider\",\"type\":\"module\",\"creationDate\":\"May 2016\",\"author\":\"Core Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"ddasios@steficon.gr\",\"authorUrl\":\"www.steficon.gr\",\"version\":\"3.0.0\",\"description\":\"MOD_SLIDER_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_slider\"}','','','',0,'2016-05-12 08:49:43',0,0),(10048,'Actions','component','com_actions','',1,1,0,0,'{\"name\":\"Actions\",\"type\":\"component\",\"creationDate\":\"1.June.2016\",\"author\":\"ddasios\",\"copyright\":\"steficon.gr 2016\",\"authorEmail\":\"ddasios@steficon.gr\",\"authorUrl\":\"www.steficon.gr\",\"version\":\"1.0.0\",\"description\":\"Create actions\",\"group\":\"\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(10049,'Open call','module','mod_opencall','',0,1,1,0,'{\"name\":\"mod_opencall\",\"type\":\"module\",\"creationDate\":\"June 2016\",\"author\":\"Core Project\",\"copyright\":\"Copyright (C) 2005 - 2016 Open Source Matters. All rights reserved.\",\"authorEmail\":\"ddasios@steficon.gr\",\"authorUrl\":\"www.steficon.gr\",\"version\":\"3.0.0\",\"description\":\"MOD_OPENCALL_XML_DESCRIPTION\",\"group\":\"\",\"filename\":\"mod_opencall\"}','','','',0,'2016-05-12 08:49:43',0,0),(10050,'Stegi Hours','component','com_stegihours','',1,1,0,0,'{\"name\":\"Stegi Hours\",\"type\":\"component\",\"creationDate\":\"6.June.2016\",\"author\":\"ddasios\",\"copyright\":\"steficon.gr 2016\",\"authorEmail\":\"ddasios@steficon.gr\",\"authorUrl\":\"www.steficon.gr\",\"version\":\"1.0.0\",\"description\":\"Manage stegi hours\",\"group\":\"\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(10051,'mod_actions','module','mod_actions','',0,1,1,0,'{\"name\":\"Actions module\",\"type\":\"module\",\"creationDate\":\"May 2016\",\"author\":\"Steficon Core\",\"copyright\":\"Copyright (C) 2005 - 2013 Open Source Matters. All rights reserved.\",\"authorEmail\":\"ddasios@steficon.gr\",\"authorUrl\":\"www.steficon.gr\",\"version\":\"3.0.0\",\"description\":\"The module for actions feature\",\"group\":\"\",\"filename\":\"mod_actions\"}','{}','','',0,'0000-00-00 00:00:00',0,-1),(10052,'Teams Export','component','com_teamsexports','',1,1,0,0,'{\"name\":\"Export teams\",\"type\":\"component\",\"creationDate\":\"4.August.2016\",\"author\":\"ddasios\",\"copyright\":\"steficon.gr 2016\",\"authorEmail\":\"ddasios@steficon.gr\",\"authorUrl\":\"www.steficon.gr\",\"version\":\"1.0.0\",\"description\":\"Export teams\",\"group\":\"\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(10053,'Newsletters Export','component','com_newsletters','',1,1,0,0,'{\"name\":\"Export newsletters\",\"type\":\"component\",\"creationDate\":\"9.August.2016\",\"author\":\"ddasios\",\"copyright\":\"steficon.gr 2016\",\"authorEmail\":\"ddasios@steficon.gr\",\"authorUrl\":\"www.steficon.gr\",\"version\":\"1.0.0\",\"description\":\"Export newsletters\",\"group\":\"\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(10054,'Statistics','component','com_stats','',1,1,0,0,'{\"name\":\"Statistics\",\"type\":\"component\",\"creationDate\":\"9.August.2016\",\"author\":\"ddasios\",\"copyright\":\"steficon.gr 2016\",\"authorEmail\":\"ddasios@steficon.gr\",\"authorUrl\":\"www.steficon.gr\",\"version\":\"1.0.0\",\"description\":\"Statistics\",\"group\":\"\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(10055,'Teams Statistics','component','com_teamstats','',1,1,0,0,'{\"name\":\"Teams Statistics\",\"type\":\"component\",\"creationDate\":\"10.August.2016\",\"author\":\"ddasios\",\"copyright\":\"steficon.gr 2016\",\"authorEmail\":\"ddasios@steficon.gr\",\"authorUrl\":\"www.steficon.gr\",\"version\":\"1.0.0\",\"description\":\"Teams Statistics\",\"group\":\"\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(10056,'Opencalls','component','com_opencalls','',1,1,0,0,'{\"name\":\"Open calls\",\"type\":\"component\",\"creationDate\":\"18.Dec.2017\",\"author\":\"ddasios\",\"copyright\":\"steficon.gr 2016\",\"authorEmail\":\"ddasios@steficon.gr\",\"authorUrl\":\"www.steficon.gr\",\"version\":\"1.0.0\",\"description\":\"Show open calls\",\"group\":\"\"}','{}','','',0,'2017-01-18 00:00:00',0,0),(10057,'com_support','component','com_support','',1,1,0,0,'{\"name\":\"com_support\",\"type\":\"component\",\"creationDate\":\"May 2017\",\"author\":\"Alex Spahos\",\"copyright\":\"Skata sta copyright\",\"authorEmail\":\"aspahos@steficon.gr\",\"authorUrl\":\"http:\\/\\/www.steficon.gr\",\"version\":\"0.0.1\",\"description\":\"Simple component to manage support types provided for actions\",\"group\":\"\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(10058,'Supportersexports','component','com_supportersexports','',1,1,0,0,'{\"name\":\"Supportersexports\",\"type\":\"component\",\"creationDate\":\"July\",\"author\":\"Steficon Core! Project\",\"copyright\":\"(C) 2017 Open Source 2017. All rights reserved.\\n\\t\",\"authorEmail\":\"info@steficon.gr\",\"authorUrl\":\"www.steficon.gr\",\"version\":\"3.0.0\",\"description\":\"Supportersexports Component\",\"group\":\"\",\"filename\":\"supportersexports\"}','{}','','',0,'0000-00-00 00:00:00',0,0),(10059,'Στατιστικά αιτημάτων υποστήριξης','component','com_supportersemails','',1,1,1,0,'{\"name\":\"Στατιστικά αιτημάτων υποστήριξης\",\"type\":\"component\",\"creationDate\":\"March 2018\",\"author\":\"ddasios\",\"copyright\":\"steficon\",\"authorEmail\":\"ddasios@steficon.gr\",\"authorUrl\":\"http:\\/\\/www.steficon.gr\",\"version\":\"0.0.1\",\"description\":\"Simple component to view emails sent to supporters\",\"group\":\"\"}','{}','','',0,'2018-03-04 00:00:00',0,0);
/*!40000 ALTER TABLE `prefi_extensions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prefi_finder_filters`
--

DROP TABLE IF EXISTS `prefi_finder_filters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `prefi_finder_filters` (
  `filter_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `state` tinyint(1) NOT NULL DEFAULT '1',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(10) unsigned NOT NULL,
  `created_by_alias` varchar(255) NOT NULL,
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `map_count` int(10) unsigned NOT NULL DEFAULT '0',
  `data` text NOT NULL,
  `params` mediumtext,
  PRIMARY KEY (`filter_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prefi_finder_filters`
--

LOCK TABLES `prefi_finder_filters` WRITE;
/*!40000 ALTER TABLE `prefi_finder_filters` DISABLE KEYS */;
/*!40000 ALTER TABLE `prefi_finder_filters` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prefi_finder_links`
--

DROP TABLE IF EXISTS `prefi_finder_links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `prefi_finder_links` (
  `link_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `url` varchar(255) NOT NULL,
  `route` varchar(255) NOT NULL,
  `title` varchar(400) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `indexdate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `md5sum` varchar(32) DEFAULT NULL,
  `published` tinyint(1) NOT NULL DEFAULT '1',
  `state` int(5) DEFAULT '1',
  `access` int(5) DEFAULT '0',
  `language` varchar(8) NOT NULL,
  `publish_start_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_end_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `start_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `end_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `list_price` double unsigned NOT NULL DEFAULT '0',
  `sale_price` double unsigned NOT NULL DEFAULT '0',
  `type_id` int(11) NOT NULL,
  `object` mediumblob NOT NULL,
  PRIMARY KEY (`link_id`),
  KEY `idx_type` (`type_id`),
  KEY `idx_title` (`title`(100)),
  KEY `idx_md5` (`md5sum`),
  KEY `idx_url` (`url`(75)),
  KEY `idx_published_list` (`published`,`state`,`access`,`publish_start_date`,`publish_end_date`,`list_price`),
  KEY `idx_published_sale` (`published`,`state`,`access`,`publish_start_date`,`publish_end_date`,`sale_price`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prefi_finder_links`
--

LOCK TABLES `prefi_finder_links` WRITE;
/*!40000 ALTER TABLE `prefi_finder_links` DISABLE KEYS */;
/*!40000 ALTER TABLE `prefi_finder_links` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prefi_finder_links_terms0`
--

DROP TABLE IF EXISTS `prefi_finder_links_terms0`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `prefi_finder_links_terms0` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prefi_finder_links_terms0`
--

LOCK TABLES `prefi_finder_links_terms0` WRITE;
/*!40000 ALTER TABLE `prefi_finder_links_terms0` DISABLE KEYS */;
/*!40000 ALTER TABLE `prefi_finder_links_terms0` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prefi_finder_links_terms1`
--

DROP TABLE IF EXISTS `prefi_finder_links_terms1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `prefi_finder_links_terms1` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prefi_finder_links_terms1`
--

LOCK TABLES `prefi_finder_links_terms1` WRITE;
/*!40000 ALTER TABLE `prefi_finder_links_terms1` DISABLE KEYS */;
/*!40000 ALTER TABLE `prefi_finder_links_terms1` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prefi_finder_links_terms2`
--

DROP TABLE IF EXISTS `prefi_finder_links_terms2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `prefi_finder_links_terms2` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prefi_finder_links_terms2`
--

LOCK TABLES `prefi_finder_links_terms2` WRITE;
/*!40000 ALTER TABLE `prefi_finder_links_terms2` DISABLE KEYS */;
/*!40000 ALTER TABLE `prefi_finder_links_terms2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prefi_finder_links_terms3`
--

DROP TABLE IF EXISTS `prefi_finder_links_terms3`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `prefi_finder_links_terms3` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prefi_finder_links_terms3`
--

LOCK TABLES `prefi_finder_links_terms3` WRITE;
/*!40000 ALTER TABLE `prefi_finder_links_terms3` DISABLE KEYS */;
/*!40000 ALTER TABLE `prefi_finder_links_terms3` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prefi_finder_links_terms4`
--

DROP TABLE IF EXISTS `prefi_finder_links_terms4`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `prefi_finder_links_terms4` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prefi_finder_links_terms4`
--

LOCK TABLES `prefi_finder_links_terms4` WRITE;
/*!40000 ALTER TABLE `prefi_finder_links_terms4` DISABLE KEYS */;
/*!40000 ALTER TABLE `prefi_finder_links_terms4` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prefi_finder_links_terms5`
--

DROP TABLE IF EXISTS `prefi_finder_links_terms5`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `prefi_finder_links_terms5` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prefi_finder_links_terms5`
--

LOCK TABLES `prefi_finder_links_terms5` WRITE;
/*!40000 ALTER TABLE `prefi_finder_links_terms5` DISABLE KEYS */;
/*!40000 ALTER TABLE `prefi_finder_links_terms5` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prefi_finder_links_terms6`
--

DROP TABLE IF EXISTS `prefi_finder_links_terms6`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `prefi_finder_links_terms6` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prefi_finder_links_terms6`
--

LOCK TABLES `prefi_finder_links_terms6` WRITE;
/*!40000 ALTER TABLE `prefi_finder_links_terms6` DISABLE KEYS */;
/*!40000 ALTER TABLE `prefi_finder_links_terms6` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prefi_finder_links_terms7`
--

DROP TABLE IF EXISTS `prefi_finder_links_terms7`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `prefi_finder_links_terms7` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prefi_finder_links_terms7`
--

LOCK TABLES `prefi_finder_links_terms7` WRITE;
/*!40000 ALTER TABLE `prefi_finder_links_terms7` DISABLE KEYS */;
/*!40000 ALTER TABLE `prefi_finder_links_terms7` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prefi_finder_links_terms8`
--

DROP TABLE IF EXISTS `prefi_finder_links_terms8`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `prefi_finder_links_terms8` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prefi_finder_links_terms8`
--

LOCK TABLES `prefi_finder_links_terms8` WRITE;
/*!40000 ALTER TABLE `prefi_finder_links_terms8` DISABLE KEYS */;
/*!40000 ALTER TABLE `prefi_finder_links_terms8` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prefi_finder_links_terms9`
--

DROP TABLE IF EXISTS `prefi_finder_links_terms9`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `prefi_finder_links_terms9` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prefi_finder_links_terms9`
--

LOCK TABLES `prefi_finder_links_terms9` WRITE;
/*!40000 ALTER TABLE `prefi_finder_links_terms9` DISABLE KEYS */;
/*!40000 ALTER TABLE `prefi_finder_links_terms9` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prefi_finder_links_termsa`
--

DROP TABLE IF EXISTS `prefi_finder_links_termsa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `prefi_finder_links_termsa` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prefi_finder_links_termsa`
--

LOCK TABLES `prefi_finder_links_termsa` WRITE;
/*!40000 ALTER TABLE `prefi_finder_links_termsa` DISABLE KEYS */;
/*!40000 ALTER TABLE `prefi_finder_links_termsa` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prefi_finder_links_termsb`
--

DROP TABLE IF EXISTS `prefi_finder_links_termsb`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `prefi_finder_links_termsb` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prefi_finder_links_termsb`
--

LOCK TABLES `prefi_finder_links_termsb` WRITE;
/*!40000 ALTER TABLE `prefi_finder_links_termsb` DISABLE KEYS */;
/*!40000 ALTER TABLE `prefi_finder_links_termsb` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prefi_finder_links_termsc`
--

DROP TABLE IF EXISTS `prefi_finder_links_termsc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `prefi_finder_links_termsc` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prefi_finder_links_termsc`
--

LOCK TABLES `prefi_finder_links_termsc` WRITE;
/*!40000 ALTER TABLE `prefi_finder_links_termsc` DISABLE KEYS */;
/*!40000 ALTER TABLE `prefi_finder_links_termsc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prefi_finder_links_termsd`
--

DROP TABLE IF EXISTS `prefi_finder_links_termsd`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `prefi_finder_links_termsd` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prefi_finder_links_termsd`
--

LOCK TABLES `prefi_finder_links_termsd` WRITE;
/*!40000 ALTER TABLE `prefi_finder_links_termsd` DISABLE KEYS */;
/*!40000 ALTER TABLE `prefi_finder_links_termsd` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prefi_finder_links_termse`
--

DROP TABLE IF EXISTS `prefi_finder_links_termse`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `prefi_finder_links_termse` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prefi_finder_links_termse`
--

LOCK TABLES `prefi_finder_links_termse` WRITE;
/*!40000 ALTER TABLE `prefi_finder_links_termse` DISABLE KEYS */;
/*!40000 ALTER TABLE `prefi_finder_links_termse` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prefi_finder_links_termsf`
--

DROP TABLE IF EXISTS `prefi_finder_links_termsf`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `prefi_finder_links_termsf` (
  `link_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`term_id`),
  KEY `idx_term_weight` (`term_id`,`weight`),
  KEY `idx_link_term_weight` (`link_id`,`term_id`,`weight`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prefi_finder_links_termsf`
--

LOCK TABLES `prefi_finder_links_termsf` WRITE;
/*!40000 ALTER TABLE `prefi_finder_links_termsf` DISABLE KEYS */;
/*!40000 ALTER TABLE `prefi_finder_links_termsf` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prefi_finder_taxonomy`
--

DROP TABLE IF EXISTS `prefi_finder_taxonomy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `prefi_finder_taxonomy` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int(10) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL,
  `state` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `access` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `ordering` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `parent_id` (`parent_id`),
  KEY `state` (`state`),
  KEY `ordering` (`ordering`),
  KEY `access` (`access`),
  KEY `idx_parent_published` (`parent_id`,`state`,`access`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prefi_finder_taxonomy`
--

LOCK TABLES `prefi_finder_taxonomy` WRITE;
/*!40000 ALTER TABLE `prefi_finder_taxonomy` DISABLE KEYS */;
INSERT INTO `prefi_finder_taxonomy` VALUES (1,0,'ROOT',0,0,0);
/*!40000 ALTER TABLE `prefi_finder_taxonomy` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prefi_finder_taxonomy_map`
--

DROP TABLE IF EXISTS `prefi_finder_taxonomy_map`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `prefi_finder_taxonomy_map` (
  `link_id` int(10) unsigned NOT NULL,
  `node_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`link_id`,`node_id`),
  KEY `link_id` (`link_id`),
  KEY `node_id` (`node_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prefi_finder_taxonomy_map`
--

LOCK TABLES `prefi_finder_taxonomy_map` WRITE;
/*!40000 ALTER TABLE `prefi_finder_taxonomy_map` DISABLE KEYS */;
/*!40000 ALTER TABLE `prefi_finder_taxonomy_map` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prefi_finder_terms`
--

DROP TABLE IF EXISTS `prefi_finder_terms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `prefi_finder_terms` (
  `term_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `term` varchar(75) NOT NULL,
  `stem` varchar(75) NOT NULL,
  `common` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `phrase` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `weight` float unsigned NOT NULL DEFAULT '0',
  `soundex` varchar(75) NOT NULL,
  `links` int(10) NOT NULL DEFAULT '0',
  `language` char(3) NOT NULL DEFAULT '',
  PRIMARY KEY (`term_id`),
  UNIQUE KEY `idx_term` (`term`),
  KEY `idx_term_phrase` (`term`,`phrase`),
  KEY `idx_stem_phrase` (`stem`,`phrase`),
  KEY `idx_soundex_phrase` (`soundex`,`phrase`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prefi_finder_terms`
--

LOCK TABLES `prefi_finder_terms` WRITE;
/*!40000 ALTER TABLE `prefi_finder_terms` DISABLE KEYS */;
/*!40000 ALTER TABLE `prefi_finder_terms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prefi_finder_terms_common`
--

DROP TABLE IF EXISTS `prefi_finder_terms_common`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `prefi_finder_terms_common` (
  `term` varchar(75) NOT NULL,
  `language` varchar(3) NOT NULL,
  KEY `idx_word_lang` (`term`,`language`),
  KEY `idx_lang` (`language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prefi_finder_terms_common`
--

LOCK TABLES `prefi_finder_terms_common` WRITE;
/*!40000 ALTER TABLE `prefi_finder_terms_common` DISABLE KEYS */;
INSERT INTO `prefi_finder_terms_common` VALUES ('a','en'),('about','en'),('after','en'),('ago','en'),('all','en'),('am','en'),('an','en'),('and','en'),('ani','en'),('any','en'),('are','en'),('aren\'t','en'),('as','en'),('at','en'),('be','en'),('but','en'),('by','en'),('for','en'),('from','en'),('get','en'),('go','en'),('how','en'),('if','en'),('in','en'),('into','en'),('is','en'),('isn\'t','en'),('it','en'),('its','en'),('me','en'),('more','en'),('most','en'),('must','en'),('my','en'),('new','en'),('no','en'),('none','en'),('not','en'),('noth','en'),('nothing','en'),('of','en'),('off','en'),('often','en'),('old','en'),('on','en'),('onc','en'),('once','en'),('onli','en'),('only','en'),('or','en'),('other','en'),('our','en'),('ours','en'),('out','en'),('over','en'),('page','en'),('she','en'),('should','en'),('small','en'),('so','en'),('some','en'),('than','en'),('thank','en'),('that','en'),('the','en'),('their','en'),('theirs','en'),('them','en'),('then','en'),('there','en'),('these','en'),('they','en'),('this','en'),('those','en'),('thus','en'),('time','en'),('times','en'),('to','en'),('too','en'),('true','en'),('under','en'),('until','en'),('up','en'),('upon','en'),('use','en'),('user','en'),('users','en'),('veri','en'),('version','en'),('very','en'),('via','en'),('want','en'),('was','en'),('way','en'),('were','en'),('what','en'),('when','en'),('where','en'),('whi','en'),('which','en'),('who','en'),('whom','en'),('whose','en'),('why','en'),('wide','en'),('will','en'),('with','en'),('within','en'),('without','en'),('would','en'),('yes','en'),('yet','en'),('you','en'),('your','en'),('yours','en');
/*!40000 ALTER TABLE `prefi_finder_terms_common` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prefi_finder_tokens`
--

DROP TABLE IF EXISTS `prefi_finder_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `prefi_finder_tokens` (
  `term` varchar(75) NOT NULL,
  `stem` varchar(75) NOT NULL,
  `common` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `phrase` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `weight` float unsigned NOT NULL DEFAULT '1',
  `context` tinyint(1) unsigned NOT NULL DEFAULT '2',
  `language` char(3) NOT NULL DEFAULT '',
  KEY `idx_word` (`term`),
  KEY `idx_context` (`context`)
) ENGINE=MEMORY DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prefi_finder_tokens`
--

LOCK TABLES `prefi_finder_tokens` WRITE;
/*!40000 ALTER TABLE `prefi_finder_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `prefi_finder_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prefi_finder_tokens_aggregate`
--

DROP TABLE IF EXISTS `prefi_finder_tokens_aggregate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `prefi_finder_tokens_aggregate` (
  `term_id` int(10) unsigned NOT NULL,
  `map_suffix` char(1) NOT NULL,
  `term` varchar(75) NOT NULL,
  `stem` varchar(75) NOT NULL,
  `common` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `phrase` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `term_weight` float unsigned NOT NULL,
  `context` tinyint(1) unsigned NOT NULL DEFAULT '2',
  `context_weight` float unsigned NOT NULL,
  `total_weight` float unsigned NOT NULL,
  `language` char(3) NOT NULL DEFAULT '',
  KEY `token` (`term`),
  KEY `keyword_id` (`term_id`)
) ENGINE=MEMORY DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prefi_finder_tokens_aggregate`
--

LOCK TABLES `prefi_finder_tokens_aggregate` WRITE;
/*!40000 ALTER TABLE `prefi_finder_tokens_aggregate` DISABLE KEYS */;
/*!40000 ALTER TABLE `prefi_finder_tokens_aggregate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prefi_finder_types`
--

DROP TABLE IF EXISTS `prefi_finder_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `prefi_finder_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `mime` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `title` (`title`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prefi_finder_types`
--

LOCK TABLES `prefi_finder_types` WRITE;
/*!40000 ALTER TABLE `prefi_finder_types` DISABLE KEYS */;
/*!40000 ALTER TABLE `prefi_finder_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prefi_languages`
--

DROP TABLE IF EXISTS `prefi_languages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `prefi_languages` (
  `lang_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `lang_code` char(7) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `title` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `title_native` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `sef` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `metakey` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `metadesc` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `sitename` varchar(1024) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `published` int(11) NOT NULL DEFAULT '0',
  `access` int(10) unsigned NOT NULL DEFAULT '0',
  `ordering` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`lang_id`),
  UNIQUE KEY `idx_sef` (`sef`),
  UNIQUE KEY `idx_image` (`image`),
  UNIQUE KEY `idx_langcode` (`lang_code`),
  KEY `idx_access` (`access`),
  KEY `idx_ordering` (`ordering`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prefi_languages`
--

LOCK TABLES `prefi_languages` WRITE;
/*!40000 ALTER TABLE `prefi_languages` DISABLE KEYS */;
INSERT INTO `prefi_languages` VALUES (1,'en-GB','English','English','en','en','','','','',1,1,2),(2,'el-GR','Greek','Ελληνικά','el','el','','','','',1,1,1);
/*!40000 ALTER TABLE `prefi_languages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prefi_menu`
--

DROP TABLE IF EXISTS `prefi_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `prefi_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `menutype` varchar(24) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'The type of menu this item belongs to. FK to #__menu_types.menutype',
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'The display title of the menu item.',
  `alias` varchar(400) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT 'The SEF alias of the menu item.',
  `note` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `path` varchar(1024) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'The computed path of the menu item based on the alias field.',
  `link` varchar(1024) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'The actually link the menu item refers to.',
  `type` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'The type of link: Component, URL, Alias, Separator',
  `published` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'The published state of the menu link.',
  `parent_id` int(10) unsigned NOT NULL DEFAULT '1' COMMENT 'The parent menu item in the menu tree.',
  `level` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'The relative level in the tree.',
  `component_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'FK to #__extensions.id',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'FK to #__users.id',
  `checked_out_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'The time the menu item was checked out.',
  `browserNav` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'The click behaviour of the link.',
  `access` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'The access level required to view the menu item.',
  `img` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'The image of the menu item.',
  `template_style_id` int(10) unsigned NOT NULL DEFAULT '0',
  `params` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'JSON encoded data for the menu item.',
  `lft` int(11) NOT NULL DEFAULT '0' COMMENT 'Nested set lft.',
  `rgt` int(11) NOT NULL DEFAULT '0' COMMENT 'Nested set rgt.',
  `home` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT 'Indicates if this menu item is the home or default page.',
  `language` char(7) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `client_id` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_client_id_parent_id_alias_language` (`client_id`,`parent_id`,`alias`(100),`language`),
  KEY `idx_componentid` (`component_id`,`menutype`,`published`,`access`),
  KEY `idx_menutype` (`menutype`),
  KEY `idx_left_right` (`lft`,`rgt`),
  KEY `idx_alias` (`alias`(100)),
  KEY `idx_path` (`path`(100)),
  KEY `idx_language` (`language`)
) ENGINE=InnoDB AUTO_INCREMENT=196 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prefi_menu`
--

LOCK TABLES `prefi_menu` WRITE;
/*!40000 ALTER TABLE `prefi_menu` DISABLE KEYS */;
INSERT INTO `prefi_menu` VALUES (1,'','Menu_Item_Root','root','','','','',1,0,0,0,0,'0000-00-00 00:00:00',0,0,'',0,'',0,199,0,'*',0),(2,'menu','com_banners','Banners','','Banners','index.php?option=com_banners','component',0,1,1,4,0,'0000-00-00 00:00:00',0,0,'class:banners',0,'',1,10,0,'*',1),(3,'menu','com_banners','Banners','','Banners/Banners','index.php?option=com_banners','component',0,2,2,4,0,'0000-00-00 00:00:00',0,0,'class:banners',0,'',2,3,0,'*',1),(4,'menu','com_banners_categories','Categories','','Banners/Categories','index.php?option=com_categories&extension=com_banners','component',0,2,2,6,0,'0000-00-00 00:00:00',0,0,'class:banners-cat',0,'',4,5,0,'*',1),(5,'menu','com_banners_clients','Clients','','Banners/Clients','index.php?option=com_banners&view=clients','component',0,2,2,4,0,'0000-00-00 00:00:00',0,0,'class:banners-clients',0,'',6,7,0,'*',1),(6,'menu','com_banners_tracks','Tracks','','Banners/Tracks','index.php?option=com_banners&view=tracks','component',0,2,2,4,0,'0000-00-00 00:00:00',0,0,'class:banners-tracks',0,'',8,9,0,'*',1),(7,'menu','com_contact','Contacts','','Contacts','index.php?option=com_contact','component',0,1,1,8,0,'0000-00-00 00:00:00',0,0,'class:contact',0,'',91,96,0,'*',1),(8,'menu','com_contact_contacts','Contacts','','Contacts/Contacts','index.php?option=com_contact','component',0,7,2,8,0,'0000-00-00 00:00:00',0,0,'class:contact',0,'',92,93,0,'*',1),(9,'menu','com_contact_categories','Categories','','Contacts/Categories','index.php?option=com_categories&extension=com_contact','component',0,7,2,6,0,'0000-00-00 00:00:00',0,0,'class:contact-cat',0,'',94,95,0,'*',1),(10,'menu','com_messages','Messaging','','Messaging','index.php?option=com_messages','component',0,1,1,15,0,'0000-00-00 00:00:00',0,0,'class:messages',0,'',97,100,0,'*',1),(11,'menu','com_messages_add','New Private Message','','Messaging/New Private Message','index.php?option=com_messages&task=message.add','component',0,10,2,15,0,'0000-00-00 00:00:00',0,0,'class:messages-add',0,'',98,99,0,'*',1),(13,'menu','com_newsfeeds','News Feeds','','News Feeds','index.php?option=com_newsfeeds','component',0,1,1,17,0,'0000-00-00 00:00:00',0,0,'class:newsfeeds',0,'',101,106,0,'*',1),(14,'menu','com_newsfeeds_feeds','Feeds','','News Feeds/Feeds','index.php?option=com_newsfeeds','component',0,13,2,17,0,'0000-00-00 00:00:00',0,0,'class:newsfeeds',0,'',102,103,0,'*',1),(15,'menu','com_newsfeeds_categories','Categories','','News Feeds/Categories','index.php?option=com_categories&extension=com_newsfeeds','component',0,13,2,6,0,'0000-00-00 00:00:00',0,0,'class:newsfeeds-cat',0,'',104,105,0,'*',1),(16,'menu','com_redirect','Redirect','','Redirect','index.php?option=com_redirect','component',0,1,1,24,0,'0000-00-00 00:00:00',0,0,'class:redirect',0,'',107,108,0,'*',1),(17,'menu','com_search','Basic Search','','Basic Search','index.php?option=com_search','component',0,1,1,19,0,'0000-00-00 00:00:00',0,0,'class:search',0,'',109,110,0,'*',1),(18,'menu','com_finder','Smart Search','','Smart Search','index.php?option=com_finder','component',0,1,1,27,0,'0000-00-00 00:00:00',0,0,'class:finder',0,'',111,112,0,'*',1),(19,'menu','com_joomlaupdate','Core Update','','Core Update','index.php?option=com_joomlaupdate','component',1,1,1,28,0,'0000-00-00 00:00:00',0,0,'class:joomlaupdate',0,'',113,114,0,'*',1),(20,'main','com_tags','Tags','','Tags','index.php?option=com_tags','component',0,1,1,29,0,'0000-00-00 00:00:00',0,1,'class:tags',0,'',115,116,0,'',1),(21,'main','com_postinstall','Post-installation messages','','Post-installation messages','index.php?option=com_postinstall','component',0,1,1,32,0,'0000-00-00 00:00:00',0,1,'class:postinstall',0,'',119,120,0,'*',1),(101,'mainmenu','Home','home','','home','index.php?option=com_content&view=featured','component',1,1,1,22,233,'2018-05-14 19:17:32',0,1,'',0,'{\"featured_categories\":[\"\"],\"layout_type\":\"blog\",\"num_leading_articles\":\"1\",\"num_intro_articles\":\"3\",\"num_columns\":\"3\",\"num_links\":\"0\",\"multi_column_order\":\"1\",\"orderby_pri\":\"\",\"orderby_sec\":\"front\",\"order_date\":\"\",\"show_pagination\":\"2\",\"show_pagination_results\":\"1\",\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"info_block_position\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_vote\":\"\",\"show_readmore\":\"\",\"show_readmore_title\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"show_feed_link\":\"1\",\"feed_summary\":\"\",\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"page_title\":\"\",\"show_page_heading\":1,\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0}',121,122,1,'*',0),(110,'mainmenugreek','συνΑθηνά','συναθηνά','synathina','συναθηνά','index.php?option=com_content&view=category&layout=blog&id=11','component',1,1,1,22,0,'0000-00-00 00:00:00',0,1,' ',0,'{\"layout_type\":\"blog\",\"show_category_heading_title_text\":\"\",\"show_category_title\":\"\",\"show_description\":\"\",\"show_description_image\":\"\",\"maxLevel\":\"\",\"show_empty_categories\":\"\",\"show_no_articles\":\"\",\"show_subcat_desc\":\"\",\"show_cat_num_articles\":\"\",\"show_cat_tags\":\"\",\"page_subheading\":\"\",\"num_leading_articles\":\"1000\",\"num_intro_articles\":\"\",\"num_columns\":\"\",\"num_links\":\"\",\"multi_column_order\":\"\",\"show_subcategory_content\":\"\",\"orderby_pri\":\"\",\"orderby_sec\":\"order\",\"order_date\":\"\",\"show_pagination\":\"\",\"show_pagination_results\":\"\",\"show_featured\":\"\",\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"info_block_position\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_vote\":\"\",\"show_readmore\":\"\",\"show_readmore_title\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"show_tags\":\"\",\"show_noauth\":\"\",\"show_feed_link\":\"\",\"feed_summary\":\"\",\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"menu_show\":1,\"page_title\":\"\",\"show_page_heading\":\"\",\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0}',37,44,0,'el-GR',0),(116,'mainmenugreek','Νέα','νέα','news','νέα','index.php?option=com_content&view=category&layout=blog&id=10','component',1,1,1,22,0,'0000-00-00 00:00:00',0,1,' ',0,'{\"layout_type\":\"blog\",\"show_category_heading_title_text\":\"\",\"show_category_title\":\"\",\"show_description\":\"\",\"show_description_image\":\"\",\"maxLevel\":\"\",\"show_empty_categories\":\"\",\"show_no_articles\":\"\",\"show_subcat_desc\":\"\",\"show_cat_num_articles\":\"\",\"show_cat_tags\":\"\",\"page_subheading\":\"\",\"num_leading_articles\":\"\",\"num_intro_articles\":\"6\",\"num_columns\":\"1\",\"num_links\":\"\",\"multi_column_order\":\"\",\"show_subcategory_content\":\"\",\"orderby_pri\":\"\",\"orderby_sec\":\"rdate\",\"order_date\":\"created\",\"show_pagination\":\"1\",\"show_pagination_results\":\"1\",\"show_featured\":\"\",\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"info_block_position\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_vote\":\"\",\"show_readmore\":\"\",\"show_readmore_title\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"show_tags\":\"\",\"show_noauth\":\"\",\"show_feed_link\":\"\",\"feed_summary\":\"\",\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"menu_show\":1,\"page_title\":\"\",\"show_page_heading\":\"\",\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0}',45,46,0,'el-GR',0),(117,'footermenugreek','Eπικοινωνία','eπικοινωνία','','eπικοινωνία','index.php?option=com_contact&view=contact&id=1','component',1,1,1,8,0,'0000-00-00 00:00:00',0,1,' ',0,'{\"presentation_style\":\"\",\"show_contact_category\":\"\",\"show_contact_list\":\"\",\"show_tags\":\"\",\"show_name\":\"\",\"show_position\":\"\",\"show_email\":\"\",\"show_street_address\":\"\",\"show_suburb\":\"\",\"show_state\":\"\",\"show_postcode\":\"\",\"show_country\":\"\",\"show_telephone\":\"\",\"show_mobile\":\"\",\"show_fax\":\"\",\"show_webpage\":\"\",\"show_misc\":\"\",\"show_image\":\"\",\"allow_vcard\":\"\",\"show_articles\":\"\",\"articles_display_num\":\"\",\"show_links\":\"\",\"linka_name\":\"\",\"linkb_name\":\"\",\"linkc_name\":\"\",\"linkd_name\":\"\",\"linke_name\":\"\",\"show_email_form\":\"\",\"show_email_copy\":\"\",\"banned_email\":\"\",\"banned_subject\":\"\",\"banned_text\":\"\",\"validate_session\":\"\",\"custom_reply\":\"\",\"redirect\":\"\",\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"menu_show\":1,\"page_title\":\"\",\"show_page_heading\":\"\",\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0}',79,80,0,'el-GR',0),(118,'footermenugreek','Βοήθεια','βοήθεια','','βοήθεια','index.php?option=com_content&view=article&id=5','component',1,1,1,22,0,'0000-00-00 00:00:00',0,1,' ',0,'{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"info_block_position\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_vote\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"show_tags\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"menu_show\":1,\"page_title\":\"\",\"show_page_heading\":\"\",\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0}',89,90,0,'el-GR',0),(119,'hiddenmenu','Όροι χρήσης','όροι-χρήσης','','όροι-χρήσης','index.php?option=com_content&view=article&id=6','component',1,1,1,22,0,'0000-00-00 00:00:00',0,1,' ',0,'{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"info_block_position\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_vote\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"show_tags\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"menu_show\":1,\"page_title\":\"\",\"show_page_heading\":\"\",\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0}',85,86,0,'el-GR',0),(120,'usermenugreek','Είσοδος','είσοδος','','είσοδος','index.php?option=com_users&view=login','component',1,1,1,25,0,'0000-00-00 00:00:00',0,5,' ',0,'{\"login_redirect_url\":\"\",\"logindescription_show\":\"1\",\"login_description\":\"\",\"login_image\":\"\",\"logout_redirect_url\":\"\",\"logoutdescription_show\":\"1\",\"logout_description\":\"\",\"logout_image\":\"\",\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"menu_show\":1,\"page_title\":\"\",\"show_page_heading\":\"1\",\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0}',127,128,0,'el-GR',0),(121,'usermenugreek','Εγγραφή','εγγραφή','','εγγραφή','index.php?option=com_users&view=registration','component',1,1,1,25,0,'0000-00-00 00:00:00',0,5,' ',0,'{\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"menu_show\":1,\"page_title\":\"\",\"show_page_heading\":\"\",\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0}',133,134,0,'el-GR',0),(122,'mainmenuenglish','About us','about-us','synathina','synathina/about-us','index.php?option=com_content&view=category&layout=blog&id=19','component',1,190,2,22,0,'0000-00-00 00:00:00',0,1,' ',0,'{\"layout_type\":\"blog\",\"show_category_heading_title_text\":\"\",\"show_category_title\":\"\",\"show_description\":\"\",\"show_description_image\":\"\",\"maxLevel\":\"\",\"show_empty_categories\":\"\",\"show_no_articles\":\"\",\"show_subcat_desc\":\"\",\"show_cat_num_articles\":\"\",\"show_cat_tags\":\"\",\"page_subheading\":\"\",\"num_leading_articles\":\"1000\",\"num_intro_articles\":\"\",\"num_columns\":\"\",\"num_links\":\"\",\"multi_column_order\":\"\",\"show_subcategory_content\":\"\",\"orderby_pri\":\"\",\"orderby_sec\":\"order\",\"order_date\":\"\",\"show_pagination\":\"\",\"show_pagination_results\":\"\",\"show_featured\":\"\",\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"info_block_position\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_vote\":\"\",\"show_readmore\":\"\",\"show_readmore_title\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"show_tags\":\"\",\"show_noauth\":\"\",\"show_feed_link\":\"\",\"feed_summary\":\"\",\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"menu_show\":1,\"page_title\":\"\",\"show_page_heading\":\"\",\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0}',12,13,0,'en-GB',0),(123,'main','ATTACH_ATTACHMENTS','attach_attachments','','attach_attachments','index.php?option=com_attachments','component',0,1,1,10031,0,'0000-00-00 00:00:00',0,1,'../media/com_attachments/images/attachments.png',0,'{}',137,142,0,'',1),(124,'main','ATTACH_ADD_NEW_ATTACHMENT','attach_add_new_attachment','','attach_attachments/attach_add_new_attachment','index.php?option=com_attachments&task=attachment.add','component',0,123,2,10031,0,'0000-00-00 00:00:00',0,1,'class:newarticle',0,'{}',138,139,0,'',1),(125,'main','JTOOLBAR_OPTIONS','jtoolbar_options','','attach_attachments/jtoolbar_options','index.php?option=com_attachments&task=params.edit','component',0,123,2,10031,0,'0000-00-00 00:00:00',0,1,'class:config',0,'{}',140,141,0,'',1),(126,'footermenugreek','Press','press','press','press','index.php?option=com_content&view=category&id=9','component',0,1,1,22,0,'0000-00-00 00:00:00',0,1,' ',0,'{\"show_category_title\":\"\",\"show_description\":\"\",\"show_description_image\":\"\",\"maxLevel\":\"\",\"show_empty_categories\":\"\",\"show_no_articles\":\"\",\"show_category_heading_title_text\":\"\",\"show_subcat_desc\":\"\",\"show_cat_num_articles\":\"\",\"show_cat_tags\":\"\",\"page_subheading\":\"\",\"show_pagination_limit\":\"\",\"filter_field\":\"\",\"show_headings\":\"\",\"list_show_date\":\"\",\"date_format\":\"\",\"list_show_hits\":\"\",\"list_show_author\":\"\",\"orderby_pri\":\"\",\"orderby_sec\":\"\",\"order_date\":\"created\",\"show_pagination\":\"\",\"show_pagination_results\":\"\",\"display_num\":\"10\",\"show_featured\":\"\",\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_vote\":\"\",\"show_readmore\":\"\",\"show_readmore_title\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"show_feed_link\":\"\",\"feed_summary\":\"\",\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"menu_show\":1,\"page_title\":\"\",\"show_page_heading\":\"\",\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0}',83,84,0,'el-GR',0),(127,'main','COM_DI_MENU','com_di_menu','','com_di_menu','index.php?option=com_di','component',0,1,1,10033,0,'0000-00-00 00:00:00',0,1,'../media/com_di/images/di-16x16.png',0,'{}',143,144,0,'',1),(128,'menu','com_teams','Ομάδες','','Ομάδες','index.php?option=com_teams','component',0,1,1,10039,0,'0000-00-00 00:00:00',0,0,'class:banners',0,'',117,118,0,'*',1),(129,'usermenugreek','Ο λογαριασμός μου','ο-λογαριασμός-μου','','ο-λογαριασμός-μου','index.php?option=com_users&view=profile','component',1,1,1,25,0,'0000-00-00 00:00:00',0,2,' ',0,'{\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"menu_show\":1,\"page_title\":\"\",\"show_page_heading\":\"1\",\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0}',145,146,0,'el-GR',0),(130,'usermenugreek','Αποσύνδεση','αποσύνδεση','','αποσύνδεση','index.php?option=com_users&view=login&layout=logout&task=user.menulogout','component',1,1,1,25,0,'0000-00-00 00:00:00',0,2,' ',0,'{\"logout\":\"\",\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"menu_show\":1,\"page_title\":\"\",\"show_page_heading\":\"\",\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0}',147,148,0,'el-GR',0),(131,'homemenugreek','Αρχική','αρχική','','αρχική','index.php?option=com_content&view=featured','component',1,1,1,22,0,'0000-00-00 00:00:00',0,1,' ',0,'{\"featured_categories\":[\"\"],\"layout_type\":\"blog\",\"num_leading_articles\":\"5\",\"num_intro_articles\":\"\",\"num_columns\":\"\",\"num_links\":\"\",\"multi_column_order\":\"\",\"orderby_pri\":\"\",\"orderby_sec\":\"front\",\"order_date\":\"\",\"show_pagination\":\"\",\"show_pagination_results\":\"\",\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"info_block_position\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_vote\":\"\",\"show_readmore\":\"\",\"show_readmore_title\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"show_tags\":\"\",\"show_noauth\":\"\",\"show_feed_link\":\"\",\"feed_summary\":\"\",\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"menu_show\":1,\"page_title\":\"\",\"show_page_heading\":\"\",\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0}',65,66,1,'el-GR',0),(132,'main','JCE','jce','','jce','index.php?option=com_jce','component',0,1,1,10019,0,'0000-00-00 00:00:00',0,1,'components/com_jce/media/img/menu/logo.png',0,'{}',149,158,0,'',1),(133,'main','WF_MENU_CPANEL','wf_menu_cpanel','','jce/wf_menu_cpanel','index.php?option=com_jce','component',0,132,2,10019,0,'0000-00-00 00:00:00',0,1,'components/com_jce/media/img/menu/jce-cpanel.png',0,'{}',150,151,0,'',1),(134,'main','WF_MENU_CONFIG','wf_menu_config','','jce/wf_menu_config','index.php?option=com_jce&view=config','component',0,132,2,10019,0,'0000-00-00 00:00:00',0,1,'components/com_jce/media/img/menu/jce-config.png',0,'{}',152,153,0,'',1),(135,'main','WF_MENU_PROFILES','wf_menu_profiles','','jce/wf_menu_profiles','index.php?option=com_jce&view=profiles','component',0,132,2,10019,0,'0000-00-00 00:00:00',0,1,'components/com_jce/media/img/menu/jce-profiles.png',0,'{}',154,155,0,'',1),(136,'main','WF_MENU_INSTALL','wf_menu_install','','jce/wf_menu_install','index.php?option=com_jce&view=installer','component',0,132,2,10019,0,'0000-00-00 00:00:00',0,1,'components/com_jce/media/img/menu/jce-install.png',0,'{}',156,157,0,'',1),(137,'mainmenugreek','Ομάδες πολιτών','ομάδες-πολιτών','teams','ομάδες/ομάδες-πολιτών','index.php?option=com_content&view=category&layout=blog&id=12','component',1,188,2,22,0,'0000-00-00 00:00:00',0,1,' ',0,'{\"layout_type\":\"blog\",\"show_category_heading_title_text\":\"\",\"show_category_title\":\"\",\"show_description\":\"\",\"show_description_image\":\"\",\"maxLevel\":\"\",\"show_empty_categories\":\"\",\"show_no_articles\":\"\",\"show_subcat_desc\":\"\",\"show_cat_num_articles\":\"\",\"show_cat_tags\":\"\",\"page_subheading\":\"\",\"num_leading_articles\":\"100\",\"num_intro_articles\":\"0\",\"num_columns\":\"0\",\"num_links\":\"0\",\"multi_column_order\":\"\",\"show_subcategory_content\":\"\",\"orderby_pri\":\"\",\"orderby_sec\":\"order\",\"order_date\":\"\",\"show_pagination\":\"\",\"show_pagination_results\":\"\",\"show_featured\":\"\",\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"info_block_position\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_vote\":\"\",\"show_readmore\":\"\",\"show_readmore_title\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"show_tags\":\"\",\"show_noauth\":\"\",\"show_feed_link\":\"\",\"feed_summary\":\"\",\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"menu_show\":1,\"page_title\":\"\",\"show_page_heading\":\"\",\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0}',54,55,0,'el-GR',0),(138,'mainmenugreek','Αρχείο Δράσεων ','αρχείο-δράσεων','','δράσεις/αρχείο-δράσεων','index.php?option=com_actions&view=actions','component',1,186,2,10048,0,'0000-00-00 00:00:00',0,1,' ',0,'{\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"menu_show\":1,\"page_title\":\"\",\"show_page_heading\":\"\",\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0}',48,49,0,'el-GR',0),(139,'hiddenmenu','Καταχώριση Δράσης','καταχώριση-δράσης','','2016-05-29-17-15-23/καταχώριση-δράσης','index.php?option=com_actions&view=form','component',1,163,2,10048,0,'0000-00-00 00:00:00',0,2,' ',0,'{\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"menu_show\":1,\"page_title\":\"\",\"show_page_heading\":\"\",\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0}',174,175,0,'*',0),(140,'hiddenmenu','Ομάδα','ομάδα','','ομάδα','index.php?option=com_teams&view=team','component',1,1,1,10039,0,'0000-00-00 00:00:00',0,1,' ',0,'{\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"menu_show\":1,\"page_title\":\"\",\"show_page_heading\":\"\",\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0}',159,160,0,'*',0),(141,'mainmenugreek','Δίκτυο','δίκτυο','eu','συναθηνά/δίκτυο','index.php?option=com_content&view=category&layout=blog&id=13','component',1,110,2,22,0,'0000-00-00 00:00:00',0,1,' ',0,'{\"layout_type\":\"blog\",\"show_category_heading_title_text\":\"\",\"show_category_title\":\"\",\"show_description\":\"\",\"show_description_image\":\"\",\"maxLevel\":\"\",\"show_empty_categories\":\"\",\"show_no_articles\":\"\",\"show_subcat_desc\":\"\",\"show_cat_num_articles\":\"\",\"show_cat_tags\":\"\",\"page_subheading\":\"\",\"num_leading_articles\":\"1000\",\"num_intro_articles\":\"\",\"num_columns\":\"\",\"num_links\":\"\",\"multi_column_order\":\"\",\"show_subcategory_content\":\"\",\"orderby_pri\":\"\",\"orderby_sec\":\"order\",\"order_date\":\"\",\"show_pagination\":\"\",\"show_pagination_results\":\"\",\"show_featured\":\"\",\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"info_block_position\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_vote\":\"\",\"show_readmore\":\"\",\"show_readmore_title\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"show_tags\":\"\",\"show_noauth\":\"\",\"show_feed_link\":\"\",\"feed_summary\":\"\",\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"menu_show\":1,\"page_title\":\"\",\"show_page_heading\":\"\",\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0}',42,43,0,'el-GR',0),(142,'footermenugreek','Newsletter','2016-05-24-13-50-31','','2016-05-24-13-50-31','#newsletter-message','url',1,1,1,0,0,'0000-00-00 00:00:00',0,1,' ',0,'{\"menu-anchor_title\":\"newsletter-tooltip\",\"menu-anchor_css\":\"\",\"menu-anchor_rel\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"menu_show\":1}',81,82,0,'el-GR',0),(143,'hiddenmenu','Οι Δράσεις Μου','οι-δράσεις-μου','','2016-05-29-17-15-23/οι-δράσεις-μου','index.php?option=com_actions&view=myactions','component',1,163,2,10044,0,'0000-00-00 00:00:00',0,2,' ',0,'{\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"menu_show\":1,\"page_title\":\"\",\"show_page_heading\":\"\",\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0}',172,173,0,'*',0),(144,'hiddenmenu','Επεξεργασία Δράσης','επεξεργασία-δράσης','','2016-05-29-17-15-23/επεξεργασία-δράσης','index.php?option=com_actions&view=edit','component',1,163,2,10044,0,'0000-00-00 00:00:00',0,2,' ',0,'{\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"menu_show\":1,\"page_title\":\"\",\"show_page_heading\":\"\",\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0}',170,171,0,'*',0),(145,'mainmenugreek','Στέγη','στέγη','stegi','στέγη','index.php?option=com_content&view=article&id=37','component',1,1,1,22,0,'0000-00-00 00:00:00',0,1,' ',0,'{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"info_block_position\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_vote\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"show_tags\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"menu_show\":1,\"page_title\":\"\",\"show_page_heading\":\"\",\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0}',59,60,0,'el-GR',0),(146,'mainmenugreek','Open Calls','open-calls','opencalls','open-calls','index.php?option=com_content&view=category&layout=blog&id=15','component',1,1,1,22,0,'0000-00-00 00:00:00',0,1,' ',0,'{\"layout_type\":\"blog\",\"show_category_heading_title_text\":\"\",\"show_category_title\":\"\",\"show_description\":\"\",\"show_description_image\":\"\",\"maxLevel\":\"\",\"show_empty_categories\":\"\",\"show_no_articles\":\"\",\"show_subcat_desc\":\"\",\"show_cat_num_articles\":\"\",\"show_cat_tags\":\"\",\"page_subheading\":\"\",\"num_leading_articles\":\"\",\"num_intro_articles\":\"6\",\"num_columns\":\"1\",\"num_links\":\"0\",\"multi_column_order\":\"\",\"show_subcategory_content\":\"\",\"orderby_pri\":\"\",\"orderby_sec\":\"rdate\",\"order_date\":\"created\",\"show_pagination\":\"\",\"show_pagination_results\":\"\",\"show_featured\":\"\",\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"info_block_position\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_vote\":\"\",\"show_readmore\":\"\",\"show_readmore_title\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"show_tags\":\"\",\"show_noauth\":\"\",\"show_feed_link\":\"\",\"feed_summary\":\"\",\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"menu_show\":1,\"page_title\":\"\",\"show_page_heading\":\"\",\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0}',61,62,0,'el-GR',0),(147,'mainmenuenglish','Citizens\' groups','citizen-groups','teams','groups1/citizen-groups','index.php?option=com_content&view=category&layout=blog&id=16','component',1,194,2,22,0,'0000-00-00 00:00:00',0,1,' ',0,'{\"layout_type\":\"blog\",\"show_category_heading_title_text\":\"\",\"show_category_title\":\"\",\"show_description\":\"\",\"show_description_image\":\"\",\"maxLevel\":\"\",\"show_empty_categories\":\"\",\"show_no_articles\":\"\",\"show_subcat_desc\":\"\",\"show_cat_num_articles\":\"\",\"show_cat_tags\":\"\",\"page_subheading\":\"\",\"num_leading_articles\":\"100\",\"num_intro_articles\":\"0\",\"num_columns\":\"0\",\"num_links\":\"0\",\"multi_column_order\":\"\",\"show_subcategory_content\":\"\",\"orderby_pri\":\"\",\"orderby_sec\":\"order\",\"order_date\":\"\",\"show_pagination\":\"\",\"show_pagination_results\":\"\",\"show_featured\":\"\",\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"info_block_position\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_vote\":\"\",\"show_readmore\":\"\",\"show_readmore_title\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"show_tags\":\"\",\"show_noauth\":\"\",\"show_feed_link\":\"\",\"feed_summary\":\"\",\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"menu_show\":1,\"page_title\":\"\",\"show_page_heading\":\"\",\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0}',28,29,0,'en-GB',0),(148,'mainmenuenglish','Citizens\' activities','citizens-archive','','activities/citizens-archive','index.php?option=com_actions&view=actions','component',1,192,2,10048,0,'0000-00-00 00:00:00',0,1,' ',0,'{\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"menu_show\":1,\"page_title\":\"\",\"show_page_heading\":\"\",\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0}',22,23,0,'en-GB',0),(149,'homemenuenglish','Homepage','homepage','','homepage','index.php?option=com_content&view=featured','component',1,1,1,22,233,'2018-05-15 16:50:19',0,1,' ',0,'{\"featured_categories\":[\"\"],\"layout_type\":\"blog\",\"num_leading_articles\":\"5\",\"num_intro_articles\":\"\",\"num_columns\":\"\",\"num_links\":\"\",\"multi_column_order\":\"\",\"orderby_pri\":\"\",\"orderby_sec\":\"front\",\"order_date\":\"\",\"show_pagination\":\"\",\"show_pagination_results\":\"\",\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"info_block_position\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_vote\":\"\",\"show_readmore\":\"\",\"show_readmore_title\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"show_tags\":\"\",\"show_noauth\":\"\",\"show_feed_link\":\"\",\"feed_summary\":\"\",\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"menu_show\":1,\"page_title\":\"\",\"show_page_heading\":\"\",\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0}',63,64,1,'en-GB',0),(150,'usermenuenglish','Log in','log-in','','log-in','index.php?option=com_users&view=login','component',1,1,1,25,0,'0000-00-00 00:00:00',0,5,' ',0,'{\"login_redirect_url\":\"\",\"logindescription_show\":\"1\",\"login_description\":\"\",\"login_image\":\"\",\"logout_redirect_url\":\"\",\"logoutdescription_show\":\"1\",\"logout_description\":\"\",\"logout_image\":\"\",\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"menu_show\":1,\"page_title\":\"\",\"show_page_heading\":\"1\",\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0}',161,162,0,'en-GB',0),(151,'usermenuenglish','Sign up','sign-up','','sign-up','index.php?option=com_users&view=registration','component',1,1,1,25,0,'0000-00-00 00:00:00',0,5,' ',0,'{\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"menu_show\":1,\"page_title\":\"\",\"show_page_heading\":\"\",\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0}',163,164,0,'en-GB',0),(152,'usermenuenglish','My account','my-account','','my-account','index.php?option=com_users&view=profile','component',1,1,1,25,0,'0000-00-00 00:00:00',0,2,' ',0,'{\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"menu_show\":1,\"page_title\":\"\",\"show_page_heading\":\"1\",\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0}',165,166,0,'en-GB',0),(153,'usermenuenglish','Log out','log-out','','log-out','index.php?option=com_users&view=login&layout=logout&task=user.menulogout','component',1,1,1,25,0,'0000-00-00 00:00:00',0,2,' ',0,'{\"logout\":\"\",\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"menu_show\":1,\"page_title\":\"\",\"show_page_heading\":\"\",\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0}',167,168,0,'en-GB',0),(154,'mainmenuenglish','Open Calls','open-calls','opencalls','open-calls','index.php?option=com_content&view=category&layout=blog&id=15','component',1,1,1,22,0,'0000-00-00 00:00:00',0,1,' ',0,'{\"layout_type\":\"blog\",\"show_category_heading_title_text\":\"\",\"show_category_title\":\"\",\"show_description\":\"\",\"show_description_image\":\"\",\"maxLevel\":\"\",\"show_empty_categories\":\"\",\"show_no_articles\":\"\",\"show_subcat_desc\":\"\",\"show_cat_num_articles\":\"\",\"show_cat_tags\":\"\",\"page_subheading\":\"\",\"num_leading_articles\":\"0\",\"num_intro_articles\":\"6\",\"num_columns\":\"1\",\"num_links\":\"0\",\"multi_column_order\":\"\",\"show_subcategory_content\":\"\",\"orderby_pri\":\"\",\"orderby_sec\":\"rdate\",\"order_date\":\"created\",\"show_pagination\":\"\",\"show_pagination_results\":\"\",\"show_featured\":\"\",\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"info_block_position\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_vote\":\"\",\"show_readmore\":\"\",\"show_readmore_title\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"show_tags\":\"\",\"show_noauth\":\"\",\"show_feed_link\":\"\",\"feed_summary\":\"\",\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"menu_show\":1,\"page_title\":\"\",\"show_page_heading\":\"\",\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0}',35,36,0,'en-GB',0),(155,'mainmenuenglish','News','news','news','news','index.php?option=com_content&view=category&layout=blog&id=10','component',1,1,1,22,0,'0000-00-00 00:00:00',0,1,' ',0,'{\"layout_type\":\"blog\",\"show_category_heading_title_text\":\"\",\"show_category_title\":\"\",\"show_description\":\"\",\"show_description_image\":\"\",\"maxLevel\":\"\",\"show_empty_categories\":\"\",\"show_no_articles\":\"\",\"show_subcat_desc\":\"\",\"show_cat_num_articles\":\"\",\"show_cat_tags\":\"\",\"page_subheading\":\"\",\"num_leading_articles\":\"\",\"num_intro_articles\":\"6\",\"num_columns\":\"1\",\"num_links\":\"\",\"multi_column_order\":\"\",\"show_subcategory_content\":\"\",\"orderby_pri\":\"\",\"orderby_sec\":\"rdate\",\"order_date\":\"created\",\"show_pagination\":\"1\",\"show_pagination_results\":\"1\",\"show_featured\":\"\",\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"info_block_position\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_vote\":\"\",\"show_readmore\":\"\",\"show_readmore_title\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"show_tags\":\"\",\"show_noauth\":\"\",\"show_feed_link\":\"\",\"feed_summary\":\"\",\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"menu_show\":1,\"page_title\":\"\",\"show_page_heading\":\"\",\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0}',19,20,0,'en-GB',0),(156,'mainmenuenglish','synAthina Kiosk','synathina-kiosk','stegi','synathina-kiosk','index.php?option=com_content&view=article&id=52','component',1,1,1,22,0,'0000-00-00 00:00:00',0,1,' ',0,'{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"info_block_position\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_vote\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"show_tags\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"menu_show\":1,\"page_title\":\"\",\"show_page_heading\":\"\",\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0}',33,34,0,'en-GB',0),(157,'mainmenuenglish','Network','network','eu','synathina/network','index.php?option=com_content&view=category&layout=blog&id=18','component',1,190,2,22,0,'0000-00-00 00:00:00',0,1,' ',0,'{\"layout_type\":\"blog\",\"show_category_heading_title_text\":\"\",\"show_category_title\":\"\",\"show_description\":\"\",\"show_description_image\":\"\",\"maxLevel\":\"\",\"show_empty_categories\":\"\",\"show_no_articles\":\"\",\"show_subcat_desc\":\"\",\"show_cat_num_articles\":\"\",\"show_cat_tags\":\"\",\"page_subheading\":\"\",\"num_leading_articles\":\"1000\",\"num_intro_articles\":\"\",\"num_columns\":\"\",\"num_links\":\"\",\"multi_column_order\":\"\",\"show_subcategory_content\":\"\",\"orderby_pri\":\"\",\"orderby_sec\":\"order\",\"order_date\":\"\",\"show_pagination\":\"\",\"show_pagination_results\":\"\",\"show_featured\":\"\",\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"info_block_position\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_vote\":\"\",\"show_readmore\":\"\",\"show_readmore_title\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"show_tags\":\"\",\"show_noauth\":\"\",\"show_feed_link\":\"\",\"feed_summary\":\"\",\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"menu_show\":1,\"page_title\":\"\",\"show_page_heading\":\"\",\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0}',16,17,0,'en-GB',0),(158,'footermenuenglish','Contact','contact','','contact','index.php?option=com_contact&view=contact&id=2','component',1,1,1,8,0,'0000-00-00 00:00:00',0,1,' ',0,'{\"presentation_style\":\"\",\"show_contact_category\":\"\",\"show_contact_list\":\"\",\"show_tags\":\"\",\"show_name\":\"\",\"show_position\":\"\",\"show_email\":\"\",\"show_street_address\":\"\",\"show_suburb\":\"\",\"show_state\":\"\",\"show_postcode\":\"\",\"show_country\":\"\",\"show_telephone\":\"\",\"show_mobile\":\"\",\"show_fax\":\"\",\"show_webpage\":\"\",\"show_misc\":\"\",\"show_image\":\"\",\"allow_vcard\":\"\",\"show_articles\":\"\",\"articles_display_num\":\"\",\"show_links\":\"\",\"linka_name\":\"\",\"linkb_name\":\"\",\"linkc_name\":\"\",\"linkd_name\":\"\",\"linke_name\":\"\",\"show_email_form\":\"\",\"show_email_copy\":\"\",\"banned_email\":\"\",\"banned_subject\":\"\",\"banned_text\":\"\",\"validate_session\":\"\",\"custom_reply\":\"\",\"redirect\":\"\",\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"menu_show\":1,\"page_title\":\"\",\"show_page_heading\":\"\",\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0}',69,70,0,'en-GB',0),(159,'footermenuenglish','Terms of use','terms-of-use','','terms-of-use','index.php?option=com_content&view=article&id=53','component',0,1,1,22,0,'0000-00-00 00:00:00',0,1,' ',0,'{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"info_block_position\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_vote\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"show_tags\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"menu_show\":1,\"page_title\":\"\",\"show_page_heading\":\"\",\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0}',75,76,0,'en-GB',0),(160,'footermenuenglish','Newsletter','2016-05-24-13-50-32','','2016-05-24-13-50-32','#newsletter-message','url',1,1,1,0,0,'0000-00-00 00:00:00',0,1,' ',0,'{\"menu-anchor_title\":\"newsletter-tooltip\",\"menu-anchor_css\":\"\",\"menu-anchor_rel\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"menu_show\":1}',71,72,0,'en-GB',0),(161,'footermenuenglish','Press','press-2','press','press-2','index.php?option=com_content&view=category&id=9','component',0,1,1,22,0,'0000-00-00 00:00:00',0,1,' ',0,'{\"show_category_title\":\"\",\"show_description\":\"\",\"show_description_image\":\"\",\"maxLevel\":\"\",\"show_empty_categories\":\"\",\"show_no_articles\":\"\",\"show_category_heading_title_text\":\"\",\"show_subcat_desc\":\"\",\"show_cat_num_articles\":\"\",\"show_cat_tags\":\"\",\"page_subheading\":\"\",\"show_pagination_limit\":\"\",\"filter_field\":\"\",\"show_headings\":\"\",\"list_show_date\":\"\",\"date_format\":\"\",\"list_show_hits\":\"\",\"list_show_author\":\"\",\"orderby_pri\":\"\",\"orderby_sec\":\"\",\"order_date\":\"created\",\"show_pagination\":\"\",\"show_pagination_results\":\"\",\"display_num\":\"10\",\"show_featured\":\"\",\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_vote\":\"\",\"show_readmore\":\"\",\"show_readmore_title\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"show_noauth\":\"\",\"show_feed_link\":\"\",\"feed_summary\":\"\",\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"menu_show\":1,\"page_title\":\"\",\"show_page_heading\":\"\",\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0}',73,74,0,'en-GB',0),(162,'footermenuenglish','Help','help-2','','help-2','index.php?option=com_content&view=article&id=5','component',0,1,1,22,0,'0000-00-00 00:00:00',0,1,' ',0,'{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"info_block_position\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_vote\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"show_tags\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"menu_show\":1,\"page_title\":\"\",\"show_page_heading\":\"\",\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0}',77,78,0,'en-GB',0),(163,'hiddenmenu','Ο λογαριασμός μου','2016-05-29-17-15-23','','2016-05-29-17-15-23','index.php?Itemid=','alias',1,1,1,0,0,'0000-00-00 00:00:00',0,1,' ',0,'{\"aliasoptions\":\"129\",\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"menu_show\":1}',169,180,0,'*',0),(165,'menu','com_stegihours','Ημερολόγιο Στέγης','','Ημερολόγιο Στέγης','index.php?option=com_stegihours','component',0,1,1,10050,0,'0000-00-00 00:00:00',0,0,'class:banners',0,'',123,124,0,'*',1),(166,'menu','com_teamsexports','Στατιστικά ομάδων','','Στατιστικά ομάδων','index.php?option=com_teamsexports','component',0,1,1,10052,0,'0000-00-00 00:00:00',0,0,'class:banners',0,'',125,126,0,'*',1),(167,'menu','com_newsletters','Newsletters export','','Newsletters export','index.php?option=com_newsletters','component',0,1,1,10053,0,'0000-00-00 00:00:00',0,0,'class:banners',0,'',129,130,0,'*',1),(168,'menu','com_stats','Στατιστικά δράσεων','','Στατιστικά δράσεων','index.php?option=com_stats','component',0,1,1,10054,0,'0000-00-00 00:00:00',0,0,'class:banners',0,'',131,132,0,'*',1),(169,'menu','com_teamstats','Στατιστικά νέων χρηστών','','Στατιστικά νέων χρηστών','index.php?option=com_teamstats','component',0,1,1,10055,0,'0000-00-00 00:00:00',0,0,'class:banners',0,'',135,136,0,'*',1),(170,'hiddenmenu','Open Calls','open-calls','','2016-05-29-17-15-23/open-calls','index.php?option=com_opencalls&view=opencalls','component',1,163,2,10056,0,'0000-00-00 00:00:00',0,1,' ',0,'{\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"menu_show\":1,\"page_title\":\"\",\"show_page_heading\":\"\",\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0}',176,177,0,'*',0),(171,'hiddenmenu','Επεξεργασία Open Call','επεξεργασία-open-call','','2016-05-29-17-15-23/επεξεργασία-open-call','index.php?option=com_opencalls&view=edit','component',1,163,2,10056,0,'0000-00-00 00:00:00',0,1,' ',0,'{\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"menu_show\":1,\"page_title\":\"\",\"show_page_heading\":\"\",\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0}',178,179,0,'*',0),(172,'footermenugreek','Όροι χρήσης (2)','όροι-χρήσης-2','','όροι-χρήσης-2','index.php?option=com_content&view=article&id=6','component',-2,1,1,22,0,'0000-00-00 00:00:00',0,1,' ',0,'{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"info_block_position\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_vote\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"show_tags\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"menu_show\":1,\"page_title\":\"\",\"show_page_heading\":\"\",\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0}',87,88,0,'el-GR',0),(173,'hiddenmenu','Best practices','best-practices','practices','best-practices','index.php?option=com_content&view=category&layout=blog&id=21','component',1,1,1,22,0,'0000-00-00 00:00:00',0,1,' ',0,'{\"layout_type\":\"blog\",\"show_category_heading_title_text\":\"\",\"show_category_title\":\"\",\"show_description\":\"\",\"show_description_image\":\"\",\"maxLevel\":\"\",\"show_empty_categories\":\"\",\"show_no_articles\":\"\",\"show_subcat_desc\":\"\",\"show_cat_num_articles\":\"\",\"show_cat_tags\":\"\",\"page_subheading\":\"\",\"num_leading_articles\":\"\",\"num_intro_articles\":\"\",\"num_columns\":\"\",\"num_links\":\"\",\"multi_column_order\":\"\",\"show_subcategory_content\":\"\",\"orderby_pri\":\"\",\"orderby_sec\":\"\",\"order_date\":\"\",\"show_pagination\":\"\",\"show_pagination_results\":\"\",\"show_featured\":\"\",\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"info_block_position\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_vote\":\"\",\"show_readmore\":\"\",\"show_readmore_title\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"show_tags\":\"\",\"show_noauth\":\"\",\"show_feed_link\":\"\",\"feed_summary\":\"\",\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"menu_show\":1,\"page_title\":\"\",\"show_page_heading\":\"\",\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0}',181,182,0,'en-GB',0),(174,'hiddenmenu','Βέλτιστες πρακτικές','βέλτιστες-πρακτικές','practices','βέλτιστες-πρακτικές','index.php?option=com_content&view=category&layout=blog&id=20','component',1,1,1,22,0,'0000-00-00 00:00:00',0,1,' ',0,'{\"layout_type\":\"blog\",\"show_category_heading_title_text\":\"\",\"show_category_title\":\"\",\"show_description\":\"\",\"show_description_image\":\"\",\"maxLevel\":\"\",\"show_empty_categories\":\"\",\"show_no_articles\":\"\",\"show_subcat_desc\":\"\",\"show_cat_num_articles\":\"\",\"show_cat_tags\":\"\",\"page_subheading\":\"\",\"num_leading_articles\":\"\",\"num_intro_articles\":\"\",\"num_columns\":\"\",\"num_links\":\"\",\"multi_column_order\":\"\",\"show_subcategory_content\":\"\",\"orderby_pri\":\"\",\"orderby_sec\":\"\",\"order_date\":\"\",\"show_pagination\":\"\",\"show_pagination_results\":\"\",\"show_featured\":\"\",\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"info_block_position\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_vote\":\"\",\"show_readmore\":\"\",\"show_readmore_title\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"show_tags\":\"\",\"show_noauth\":\"\",\"show_feed_link\":\"\",\"feed_summary\":\"\",\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"menu_show\":1,\"page_title\":\"\",\"show_page_heading\":\"\",\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0}',183,184,0,'el-GR',0),(176,'main','COM_SUPPORT','com_support','','com_support','index.php?option=com_support','component',0,1,1,10057,0,'0000-00-00 00:00:00',0,1,'class:component',0,'{}',185,186,0,'',1),(177,'main','Supportersexports','Στατιστικά Υποστηρικτών','','Στατιστικά Υποστηρικτών','index.php?option=com_supportersexports','component',0,1,1,10058,0,'0000-00-00 00:00:00',0,1,'class:supportersexports',0,'{}',187,188,0,'',1),(178,'main','Supportersemails','Στατιστικά emails υποστήριξης','','Στατιστικά emails υποστήριξης','index.php?option=com_supportersemails','component',0,1,1,10059,0,'2018-03-03 23:00:00',0,1,'class:supportersemails',0,'{}',197,198,0,'',1),(179,'topmenuenglish','Register activity','2018-05-14-17-19-56','','2018-05-14-17-19-56','index.php?Itemid=','alias',1,1,1,0,0,'0000-00-00 00:00:00',0,1,' ',0,'{\"aliasoptions\":\"139\",\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"menu_show\":1}',189,190,0,'en-GB',0),(180,'topmenuenglish','Register open call','2018-05-14-17-20-32','','2018-05-14-17-20-32','#opencall-message','url',1,1,1,0,0,'0000-00-00 00:00:00',0,1,' ',0,'{\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"opencall-tooltip\",\"menu-anchor_rel\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"menu_show\":1}',191,192,0,'en-GB',0),(181,'topmenugreek','Καταχώριση δράσης','2018-05-14-17-21-33','','2018-05-14-17-21-33','index.php?Itemid=','alias',1,1,1,0,0,'0000-00-00 00:00:00',0,1,' ',0,'{\"aliasoptions\":\"139\",\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"menu_show\":1}',193,194,0,'el-GR',0),(182,'topmenugreek','Καταχώριση open call','2018-05-14-17-21-57','','2018-05-14-17-21-57','#opencall-message','url',1,1,1,0,0,'0000-00-00 00:00:00',0,1,' ',0,'{\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"opencall-tooltip\",\"menu-anchor_rel\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"menu_show\":1}',195,196,0,'el-GR',0),(183,'mainmenugreek','Σχετικά με εμάς','σχετικά-με-εμάς','synathina','συναθηνά/σχετικά-με-εμάς','index.php?option=com_content&view=category&layout=blog&id=11','component',1,110,2,22,0,'0000-00-00 00:00:00',0,1,' ',0,'{\"layout_type\":\"blog\",\"show_category_heading_title_text\":\"\",\"show_category_title\":\"\",\"show_description\":\"\",\"show_description_image\":\"\",\"maxLevel\":\"\",\"show_empty_categories\":\"\",\"show_no_articles\":\"\",\"show_subcat_desc\":\"\",\"show_cat_num_articles\":\"\",\"show_cat_tags\":\"\",\"page_subheading\":\"\",\"num_leading_articles\":\"1000\",\"num_intro_articles\":\"\",\"num_columns\":\"\",\"num_links\":\"\",\"multi_column_order\":\"\",\"show_subcategory_content\":\"\",\"orderby_pri\":\"\",\"orderby_sec\":\"order\",\"order_date\":\"\",\"show_pagination\":\"\",\"show_pagination_results\":\"\",\"show_featured\":\"\",\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"info_block_position\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_vote\":\"\",\"show_readmore\":\"\",\"show_readmore_title\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"show_tags\":\"\",\"show_noauth\":\"\",\"show_feed_link\":\"\",\"feed_summary\":\"\",\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"menu_show\":1,\"page_title\":\"\",\"show_page_heading\":\"\",\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0}',38,39,0,'el-GR',0),(184,'mainmenugreek','Στατιστικά','στατιστικά','stats','συναθηνά/στατιστικά','index.php?option=com_content&view=article&id=643','component',1,110,2,22,0,'0000-00-00 00:00:00',0,1,' ',0,'{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"info_block_position\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_vote\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"show_tags\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"menu_show\":1,\"page_title\":\"\",\"show_page_heading\":\"\",\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0}',40,41,0,'el-GR',0),(185,'mainmenugreek','Δράσεις (2)','δράσεις-2','','δράσεις-2','index.php?option=com_actions&view=actions','component',-2,1,1,10048,0,'0000-00-00 00:00:00',0,1,' ',0,'{\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"menu_show\":1,\"page_title\":\"\",\"show_page_heading\":\"\",\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0}',67,68,0,'el-GR',0),(186,'mainmenugreek','Δράσεις','δράσεις','','δράσεις','index.php?option=com_actions&view=actions','component',1,1,1,10048,0,'0000-00-00 00:00:00',0,1,' ',0,'{\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"menu_show\":1,\"page_title\":\"\",\"show_page_heading\":\"\",\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0}',47,52,0,'el-GR',0),(187,'mainmenugreek','Βέλτιστες πρακτικές','βέλτιστες-πρακτικές','bestpractices','δράσεις/βέλτιστες-πρακτικές','index.php?option=com_content&view=category&layout=blog&id=20','component',1,186,2,22,0,'0000-00-00 00:00:00',0,1,' ',0,'{\"layout_type\":\"blog\",\"show_category_heading_title_text\":\"\",\"show_category_title\":\"\",\"show_description\":\"\",\"show_description_image\":\"\",\"maxLevel\":\"\",\"show_empty_categories\":\"\",\"show_no_articles\":\"\",\"show_subcat_desc\":\"\",\"show_cat_num_articles\":\"\",\"show_cat_tags\":\"\",\"page_subheading\":\"\",\"num_leading_articles\":\"\",\"num_intro_articles\":\"6\",\"num_columns\":\"1\",\"num_links\":\"\",\"multi_column_order\":\"\",\"show_subcategory_content\":\"\",\"orderby_pri\":\"\",\"orderby_sec\":\"rdate\",\"order_date\":\"created\",\"show_pagination\":\"1\",\"show_pagination_results\":\"1\",\"show_featured\":\"\",\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"info_block_position\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_vote\":\"\",\"show_readmore\":\"\",\"show_readmore_title\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"show_tags\":\"\",\"show_noauth\":\"\",\"show_feed_link\":\"\",\"feed_summary\":\"\",\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"menu_show\":1,\"page_title\":\"\",\"show_page_heading\":\"\",\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0}',50,51,0,'el-GR',0),(188,'mainmenugreek','Ομάδες','ομάδες','','ομάδες','index.php?Itemid=','alias',1,1,1,0,0,'0000-00-00 00:00:00',0,1,' ',0,'{\"aliasoptions\":\"137\",\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"menu_show\":1}',53,58,0,'el-GR',0),(189,'mainmenugreek','Υποστηρικτές','υποστηρικτές','supporters','ομάδες/υποστηρικτές','index.php?option=com_content&view=category&layout=blog&id=22','component',1,188,2,22,0,'0000-00-00 00:00:00',0,1,' ',0,'{\"layout_type\":\"blog\",\"show_category_heading_title_text\":\"\",\"show_category_title\":\"\",\"show_description\":\"\",\"show_description_image\":\"\",\"maxLevel\":\"\",\"show_empty_categories\":\"\",\"show_no_articles\":\"\",\"show_subcat_desc\":\"\",\"show_cat_num_articles\":\"\",\"show_cat_tags\":\"\",\"page_subheading\":\"\",\"num_leading_articles\":\"100\",\"num_intro_articles\":\"\",\"num_columns\":\"\",\"num_links\":\"\",\"multi_column_order\":\"\",\"show_subcategory_content\":\"\",\"orderby_pri\":\"\",\"orderby_sec\":\"order\",\"order_date\":\"\",\"show_pagination\":\"\",\"show_pagination_results\":\"\",\"show_featured\":\"\",\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"info_block_position\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_vote\":\"\",\"show_readmore\":\"\",\"show_readmore_title\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"show_tags\":\"\",\"show_noauth\":\"\",\"show_feed_link\":\"\",\"feed_summary\":\"\",\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"menu_show\":1,\"page_title\":\"\",\"show_page_heading\":\"\",\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0}',56,57,0,'el-GR',0),(190,'mainmenuenglish','synAthina','synathina','synathina','synathina','index.php?Itemid=','alias',1,1,1,0,0,'0000-00-00 00:00:00',0,1,' ',0,'{\"aliasoptions\":\"122\",\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"menu_show\":1}',11,18,0,'en-GB',0),(191,'mainmenuenglish','Statistics','statistics','stats','synathina/statistics','index.php?option=com_content&view=article&id=643','component',1,190,2,22,0,'0000-00-00 00:00:00',0,1,' ',0,'{\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"info_block_position\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_vote\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"show_tags\":\"\",\"show_noauth\":\"\",\"urls_position\":\"\",\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"menu_show\":1,\"page_title\":\"\",\"show_page_heading\":\"\",\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0}',14,15,0,'en-GB',0),(192,'mainmenuenglish','Activities','activities','','activities','index.php?option=com_actions&view=actions','component',1,1,1,10048,0,'0000-00-00 00:00:00',0,1,' ',0,'{\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"menu_show\":1,\"page_title\":\"\",\"show_page_heading\":\"\",\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0}',21,26,0,'en-GB',0),(193,'mainmenuenglish','Best practices','best-practices','bestpractices','activities/best-practices','index.php?option=com_content&view=category&layout=blog&id=21','component',1,192,2,22,0,'0000-00-00 00:00:00',0,1,' ',0,'{\"layout_type\":\"blog\",\"show_category_heading_title_text\":\"\",\"show_category_title\":\"\",\"show_description\":\"\",\"show_description_image\":\"\",\"maxLevel\":\"\",\"show_empty_categories\":\"\",\"show_no_articles\":\"\",\"show_subcat_desc\":\"\",\"show_cat_num_articles\":\"\",\"show_cat_tags\":\"\",\"page_subheading\":\"\",\"num_leading_articles\":\"0\",\"num_intro_articles\":\"6\",\"num_columns\":\"1\",\"num_links\":\"\",\"multi_column_order\":\"\",\"show_subcategory_content\":\"\",\"orderby_pri\":\"\",\"orderby_sec\":\"order\",\"order_date\":\"created\",\"show_pagination\":\"1\",\"show_pagination_results\":\"1\",\"show_featured\":\"\",\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"info_block_position\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_vote\":\"\",\"show_readmore\":\"\",\"show_readmore_title\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"show_tags\":\"\",\"show_noauth\":\"\",\"show_feed_link\":\"\",\"feed_summary\":\"\",\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"menu_show\":1,\"page_title\":\"\",\"show_page_heading\":\"\",\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0}',24,25,0,'en-GB',0),(194,'mainmenuenglish','Groups','groups1','','groups1','index.php?Itemid=','alias',1,1,1,0,0,'0000-00-00 00:00:00',0,1,' ',0,'{\"aliasoptions\":\"147\",\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"menu_show\":1}',27,32,0,'en-GB',0),(195,'mainmenuenglish','Supporters','supporters','supporters','groups1/supporters','index.php?option=com_content&view=category&layout=blog&id=23','component',1,194,2,22,0,'0000-00-00 00:00:00',0,1,' ',0,'{\"layout_type\":\"blog\",\"show_category_heading_title_text\":\"\",\"show_category_title\":\"\",\"show_description\":\"\",\"show_description_image\":\"\",\"maxLevel\":\"\",\"show_empty_categories\":\"\",\"show_no_articles\":\"\",\"show_subcat_desc\":\"\",\"show_cat_num_articles\":\"\",\"show_cat_tags\":\"\",\"page_subheading\":\"\",\"num_leading_articles\":\"100\",\"num_intro_articles\":\"0\",\"num_columns\":\"0\",\"num_links\":\"0\",\"multi_column_order\":\"\",\"show_subcategory_content\":\"\",\"orderby_pri\":\"none\",\"orderby_sec\":\"order\",\"order_date\":\"\",\"show_pagination\":\"\",\"show_pagination_results\":\"\",\"show_featured\":\"\",\"show_title\":\"\",\"link_titles\":\"\",\"show_intro\":\"\",\"info_block_position\":\"\",\"show_category\":\"\",\"link_category\":\"\",\"show_parent_category\":\"\",\"link_parent_category\":\"\",\"show_author\":\"\",\"link_author\":\"\",\"show_create_date\":\"\",\"show_modify_date\":\"\",\"show_publish_date\":\"\",\"show_item_navigation\":\"\",\"show_vote\":\"\",\"show_readmore\":\"\",\"show_readmore_title\":\"\",\"show_icons\":\"\",\"show_print_icon\":\"\",\"show_email_icon\":\"\",\"show_hits\":\"\",\"show_tags\":\"\",\"show_noauth\":\"\",\"show_feed_link\":\"\",\"feed_summary\":\"\",\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"menu_show\":1,\"page_title\":\"\",\"show_page_heading\":\"\",\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0}',30,31,0,'en-GB',0);
/*!40000 ALTER TABLE `prefi_menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prefi_menu_types`
--

DROP TABLE IF EXISTS `prefi_menu_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `prefi_menu_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `menutype` varchar(24) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(48) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_menutype` (`menutype`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prefi_menu_types`
--

LOCK TABLES `prefi_menu_types` WRITE;
/*!40000 ALTER TABLE `prefi_menu_types` DISABLE KEYS */;
INSERT INTO `prefi_menu_types` VALUES (1,'mainmenu','Main Menu','The main menu for the site'),(2,'mainmenugreek','Main Menu Greek',''),(3,'footermenugreek','Footer Menu Greek',''),(4,'usermenugreek','User Menu Greek',''),(5,'mainmenuenglish','Main Menu English',''),(6,'hiddenmenu','Hidden menu',''),(7,'usermenuenglish','User Menu English',''),(8,'footermenuenglish','Footer Menu English',''),(9,'topmenugreek','Top Menu Greek',''),(10,'topmenuenglish','Top Menu English',''),(11,'homemenugreek','Home Menu Greek',''),(12,'homemenuenglish','Home Menu English','');
/*!40000 ALTER TABLE `prefi_menu_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prefi_messages`
--

DROP TABLE IF EXISTS `prefi_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `prefi_messages` (
  `message_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id_from` int(10) unsigned NOT NULL DEFAULT '0',
  `user_id_to` int(10) unsigned NOT NULL DEFAULT '0',
  `folder_id` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `date_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `state` tinyint(1) NOT NULL DEFAULT '0',
  `priority` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `subject` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `message` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`message_id`),
  KEY `useridto_state` (`user_id_to`,`state`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prefi_messages`
--

LOCK TABLES `prefi_messages` WRITE;
/*!40000 ALTER TABLE `prefi_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `prefi_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prefi_messages_cfg`
--

DROP TABLE IF EXISTS `prefi_messages_cfg`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `prefi_messages_cfg` (
  `user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `cfg_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `cfg_value` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  UNIQUE KEY `idx_user_var_name` (`user_id`,`cfg_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prefi_messages_cfg`
--

LOCK TABLES `prefi_messages_cfg` WRITE;
/*!40000 ALTER TABLE `prefi_messages_cfg` DISABLE KEYS */;
/*!40000 ALTER TABLE `prefi_messages_cfg` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prefi_modules`
--

DROP TABLE IF EXISTS `prefi_modules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `prefi_modules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `asset_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'FK to the #__assets table.',
  `title` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `note` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `ordering` int(11) NOT NULL DEFAULT '0',
  `position` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `module` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `access` int(10) unsigned NOT NULL DEFAULT '0',
  `showtitle` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `params` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `client_id` tinyint(4) NOT NULL DEFAULT '0',
  `language` char(7) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `published` (`published`,`access`),
  KEY `newsfeeds` (`module`,`published`),
  KEY `idx_language` (`language`)
) ENGINE=InnoDB AUTO_INCREMENT=121 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prefi_modules`
--

LOCK TABLES `prefi_modules` WRITE;
/*!40000 ALTER TABLE `prefi_modules` DISABLE KEYS */;
INSERT INTO `prefi_modules` VALUES (1,39,'Main Menu Greek','','',1,'mainmenu',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_menu',1,0,'{\"menutype\":\"mainmenugreek\",\"base\":\"\",\"startLevel\":\"1\",\"endLevel\":\"2\",\"showAllChildren\":\"1\",\"tag_id\":\"\",\"class_sfx\":\"l-header__nav__menu menu menu--inline\",\"window_open\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"itemid\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'el-GR'),(2,40,'Login','','',1,'login',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_login',1,1,'',1,'*'),(3,41,'Popular Articles','','',3,'cpanel',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_popular',3,1,'{\"count\":\"5\",\"catid\":\"\",\"user_id\":\"0\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"0\"}',1,'*'),(4,42,'Recently Added Articles','','',4,'cpanel',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_latest',3,1,'{\"count\":\"5\",\"ordering\":\"c_dsc\",\"catid\":\"\",\"user_id\":\"0\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"0\"}',1,'*'),(8,43,'Toolbar','','',1,'toolbar',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_toolbar',3,1,'',1,'*'),(9,44,'Quick Icons','','',1,'icon',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_quickicon',3,1,'',1,'*'),(10,45,'Logged-in Users','','',2,'cpanel',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_logged',3,1,'{\"count\":\"5\",\"name\":\"1\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"0\"}',1,'*'),(12,46,'Admin Menu','','',1,'menu',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_menu',3,1,'{\"layout\":\"\",\"moduleclass_sfx\":\"\",\"shownew\":\"1\",\"showhelp\":\"1\",\"cache\":\"0\"}',1,'*'),(13,47,'Admin Submenu','','',1,'submenu',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_submenu',3,1,'',1,'*'),(14,48,'User Status','','',2,'status',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_status',3,1,'',1,'*'),(15,49,'Title','','',1,'title',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_title',3,1,'',1,'*'),(16,50,'Login Form','','',1,'position-7',0,'0000-00-00 00:00:00','2016-03-28 14:41:37','0000-00-00 00:00:00',0,'mod_login',1,1,'{\"pretext\":\"\",\"posttext\":\"\",\"login\":\"129\",\"logout\":\"101\",\"greeting\":\"1\",\"name\":\"0\",\"usesecure\":\"0\",\"usetext\":\"0\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"0\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(17,51,'Breadcrumbs','','',1,'breadcumbs',0,'0000-00-00 00:00:00','2016-03-29 08:48:06','0000-00-00 00:00:00',0,'mod_breadcrumbs',1,0,'{\"showHere\":\"0\",\"showHome\":\"1\",\"homeText\":\"\",\"showLast\":\"1\",\"separator\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"itemid\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(79,52,'Multilanguage status','','',1,'status',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',0,'mod_multilangstatus',3,1,'{\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"0\"}',1,'*'),(86,53,'Core Version','','',1,'footer',0,'0000-00-00 00:00:00','2016-03-28 10:44:40','0000-00-00 00:00:00',1,'mod_version',3,1,'{\"format\":\"short\",\"product\":\"1\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"0\"}',1,'*'),(87,63,'Footer Menu Greek','','',1,'footermenu',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_menu',1,0,'{\"menutype\":\"footermenugreek\",\"base\":\"\",\"startLevel\":\"1\",\"endLevel\":\"1\",\"showAllChildren\":\"0\",\"tag_id\":\"js-footer-menu-item\",\"class_sfx\":\"menu nav-site-com\",\"window_open\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"itemid\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'el-GR'),(88,65,'Language Switcher','','',0,'languages',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_languages',1,0,'{\"header_text\":\"\",\"footer_text\":\"\",\"dropdown\":\"0\",\"image\":\"0\",\"inline\":\"1\",\"show_active\":\"1\",\"full_name\":\"0\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"0\",\"cache_time\":\"900\",\"cachemode\":\"itemid\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(89,66,'Extra Links_gr','','<p><a href=\"http://www.bloomberg.org/\" target=\"_blank\"><img src=\"images/extra_links/bloomberg_img.png\" alt=\"bloomberg img\" /></a><a href=\"http://mayorschallenge.bloomberg.org/\" target=\"_blank\"><img src=\"images/extra_links/mayor_chalenge_img.png\" alt=\"mayor chalenge img\" /></a>\r\n<img src=\"/images/synathina_espa_logos_gr.png\" width=\"100%\" style=\"margin-top:10px;\" />\r\n</p>',1,'links',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',1,0,'{\"prepare_content\":\"0\",\"backgroundimage\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'el-GR'),(90,73,'News Banner','','<p><img src=\"images/banners/tpl_banner_img.jpg\" alt=\"\" /></p>',1,'banner',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',0,'mod_custom',1,0,'{\"prepare_content\":\"0\",\"backgroundimage\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(91,82,'Dizi images','','',0,'images',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_images',3,1,'',1,'*'),(92,83,'Images gallery','','',0,'images',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',0,'mod_images',1,1,'{\"fluid\":\"1\",\"load_fancybox\":\"1\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(93,88,'Άρθρα','','',0,'articles',0,'0000-00-00 00:00:00','2016-03-29 10:48:24','0000-00-00 00:00:00',-2,'mod_articles_category',1,1,'{\"mode\":\"normal\",\"show_on_article_page\":\"0\",\"count\":\"0\",\"show_front\":\"show\",\"category_filtering_type\":\"1\",\"catid\":[\"10\"],\"show_child_category_articles\":\"0\",\"levels\":\"1\",\"author_filtering_type\":\"1\",\"created_by\":[\"\"],\"author_alias_filtering_type\":\"1\",\"created_by_alias\":[\"\"],\"excluded_articles\":\"\",\"date_filtering\":\"off\",\"date_field\":\"a.created\",\"start_date_range\":\"\",\"end_date_range\":\"\",\"relative_date\":\"30\",\"article_ordering\":\"a.ordering\",\"article_ordering_direction\":\"ASC\",\"article_grouping\":\"none\",\"article_grouping_direction\":\"ksort\",\"month_year_format\":\"F Y\",\"link_titles\":\"1\",\"show_date\":\"0\",\"show_date_field\":\"created\",\"show_date_format\":\"Y-m-d H:i:s\",\"show_category\":\"0\",\"show_hits\":\"0\",\"show_author\":\"0\",\"show_introtext\":\"0\",\"introtext_limit\":\"100\",\"show_readmore\":\"0\",\"show_readmore_title\":\"1\",\"readmore_limit\":\"15\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"owncache\":\"1\",\"cache_time\":\"900\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(94,89,'Άρθρα','','',1,'articles',233,'2019-02-20 11:29:16','0000-00-00 00:00:00','0000-00-00 00:00:00',0,'mod_articles',1,1,'{\"catid\":\"8\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'el-GR'),(95,96,'test','','',0,'',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_articles_category',1,1,'{\"mode\":\"normal\",\"show_on_article_page\":\"1\",\"count\":\"0\",\"show_front\":\"show\",\"category_filtering_type\":\"1\",\"catid\":[\"\",\"2\",\"10\"],\"show_child_category_articles\":\"0\",\"levels\":\"1\",\"author_filtering_type\":\"1\",\"created_by\":[\"\"],\"author_alias_filtering_type\":\"1\",\"created_by_alias\":[\"\"],\"excluded_articles\":\"\",\"date_filtering\":\"off\",\"date_field\":\"a.created\",\"start_date_range\":\"\",\"end_date_range\":\"\",\"relative_date\":\"30\",\"article_ordering\":\"a.title\",\"article_ordering_direction\":\"ASC\",\"article_grouping\":\"none\",\"article_grouping_direction\":\"ksort\",\"month_year_format\":\"F Y\",\"link_titles\":\"1\",\"show_date\":\"0\",\"show_date_field\":\"created\",\"show_date_format\":\"Y-m-d H:i:s\",\"show_category\":\"0\",\"show_hits\":\"0\",\"show_author\":\"0\",\"show_introtext\":\"0\",\"introtext_limit\":\"100\",\"show_readmore\":\"0\",\"show_readmore_title\":\"1\",\"readmore_limit\":\"15\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"owncache\":\"1\",\"cache_time\":\"900\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(96,106,'User Menu Greek','','',1,'usermenu',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_menu',1,0,'{\"menutype\":\"usermenugreek\",\"base\":\"\",\"startLevel\":\"1\",\"endLevel\":\"1\",\"showAllChildren\":\"0\",\"tag_id\":\"\",\"class_sfx\":\"account-actions inline-list--separated\",\"window_open\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"itemid\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'el-GR'),(97,112,'Synathina Banner','','<p><img src=\"images/banners/synathina_banner.jpg\" alt=\"synathina banner\" /></p>',1,'banner',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',0,'mod_custom',1,0,'{\"prepare_content\":\"0\",\"backgroundimage\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(98,332,'Ομάδες','','',1,'teams',233,'2018-07-23 13:22:07','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_teams',1,0,'{\"support_actions\":\"0\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(99,333,'Υποστηρικτές','','',1,'teams',0,'0000-00-00 00:00:00','2016-05-12 14:21:28','0000-00-00 00:00:00',-2,'mod_teams',1,0,'{\"support_actions\":\"1\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(100,1883,'Δράσεις','','<p class=\"MsoNormal\">Οργανώνεις δράσεις που προωθούν κοινωφελείς σκοπούς και βελτιώνουν την ποιότητα ζωής στην πόλη; Μπορείς τώρα να τις καταχωρίσεις στην ιστοσελίδα του συνΑθηνά και να διαμορφώσεις έτσι ένα χάρτη που αποτυπώνει τη θετική συμβολή των ενεργών πολιτών στις προκλήσεις της πόλης. <br /> <br /> Για τον δήμο Αθηναίων, η αποτύπωση αυτών των δράσεων σε ένα ενιαίο αρχείο αποτελεί ένα πολύτιμο εργαλείο γνώσης που τον βοηθά να βρίσκεται σε επαφή με τις προτεραιότητες των πολιτών και να συντονίζεται με τις δυνάμεις της κοινωνίας πολιτών για την αντιμετώπιση καίριων προκλήσεων της πόλης.</p>\r\n<p class=\"MsoNormal\">Η ομάδα του συνΑθηνά, με τη σειρά της, αναγνωρίζει τις δράσεις με τον θετικότερο αντίκτυπο, αναδεικνύει τις βέλτιστες πρακτικές και εντοπίζει ευκαιρίες συνεργασίας αλλά και αναβάθμισης της διοίκησης της πόλης μέσα από τις πρακτικές των πολιτών.</p>\r\n<p class=\"MsoNormal\">Γιατί κάθε δράση μπορεί να γίνει μοχλός αλλαγής!</p>',1,'actions_text',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',1,1,'{\"prepare_content\":\"0\",\"backgroundimage\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'el-GR'),(101,1907,'Στέγη','','',1,'stegi',233,'2017-01-18 10:23:43','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_stegi',1,0,'{\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(102,1911,'Εγχείριδια δράσεων','','',1,'toolkits',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',0,'mod_toolkits',1,1,'{\"cat\":\"14\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'el-GR'),(103,1917,'Main Menu English','','',1,'mainmenu',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_menu',1,0,'{\"menutype\":\"mainmenuenglish\",\"base\":\"\",\"startLevel\":\"1\",\"endLevel\":\"2\",\"showAllChildren\":\"1\",\"tag_id\":\"\",\"class_sfx\":\"l-header__nav__menu menu menu--inline\",\"window_open\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"itemid\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'en-GB'),(104,1918,'Activities','','<p>Do you organize socially beneficial activities which aim at improving the quality of life in the city? You can now upload them on our webpage and form a map which showcases the active citizens’ positive contribution to the challenges of the city.</p>\r\n<p>This activities’ archive provides invaluable knowledge to the administration of the City, helps it stay in touch with the priorities of its citizens and coordinate with stakeholders of the civil society, in order to address the challenges of the city.</p>\r\n<p>The synAthina team acknowledges the most impactful activities in the city and highlights the best practices. Through those practices, it also traces opportunities for collaboration and for the upgrade of the city administration.</p>\r\n<p>Every activity can become a lever of change!</p>',1,'actions_text',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',1,1,'{\"prepare_content\":\"0\",\"backgroundimage\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'en-GB'),(105,1919,'Toolkits','','',1,'toolkits',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',0,'mod_toolkits',1,1,'{\"cat\":\"14\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'en-GB'),(106,1927,'User Menu English','','',1,'usermenu',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_menu',1,0,'{\"menutype\":\"usermenuenglish\",\"base\":\"\",\"startLevel\":\"1\",\"endLevel\":\"1\",\"showAllChildren\":\"0\",\"tag_id\":\"\",\"class_sfx\":\"account-actions inline-list--separated\",\"window_open\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"itemid\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'en-GB'),(107,1934,'Articles','','',1,'articles',233,'2019-02-20 11:29:44','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_articles',1,1,'{\"catid\":\"8\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'en-GB'),(108,1936,'Footer Menu English','','',1,'footermenu',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_menu',1,0,'{\"menutype\":\"footermenuenglish\",\"base\":\"\",\"startLevel\":\"1\",\"endLevel\":\"1\",\"showAllChildren\":\"0\",\"tag_id\":\"js-footer-menu-item\",\"class_sfx\":\"menu nav-site-com\",\"window_open\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"itemid\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'en-GB'),(109,1937,'Στέγη (copy)','','',1,'stegi',0,'0000-00-00 00:00:00','2016-05-29 14:55:51','0000-00-00 00:00:00',-2,'mod_stegi',1,0,'{\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(110,1938,'Synathina Slider','','',1,'slider',0,'0000-00-00 00:00:00','2016-06-06 12:38:20','0000-00-00 00:00:00',1,'mod_slider',1,0,'{\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(111,2208,'Open call','','',1,'opencall',0,'0000-00-00 00:00:00','2016-06-06 09:35:06','0000-00-00 00:00:00',1,'mod_opencall',1,0,'{\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'*'),(112,3898,'Extra Links_en','','<p><a href=\"http://www.bloomberg.org/\" target=\"_blank\"><img src=\"images/extra_links/bloomberg_img.png\" alt=\"bloomberg img\" /></a><a href=\"http://mayorschallenge.bloomberg.org/\" target=\"_blank\"><img src=\"images/extra_links/mayor_chalenge_img.png\" alt=\"mayor chalenge img\" /></a>\r\n\r\n<img src=\"/images/synathina_espa_logos_en.png\" width=\"100%\" style=\"margin-top:10px;\" />\r\n</p>',1,'links',0,'0000-00-00 00:00:00','2016-10-19 10:02:29','0000-00-00 00:00:00',1,'mod_custom',1,0,'{\"prepare_content\":\"0\",\"backgroundimage\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'en-GB'),(113,8440,'Βέλτιστες Πρακτικές','','<p>Μέσα από έρευνα στο πεδίο και συνεντεύξεις με τις ομάδες πολιτών που αναρτούν τις δράσεις τους στο synathina.gr, η ομάδα του συνΑθηνά αναγνωρίζει τις δράσεις με τον υψηλότερο θετικό αντίκτυπο στην πόλη. Κάθε βέλτιστη πρακτική της κοινωνίας πολιτών απαντά σε υπαρκτές προκλήσεις της πόλης και αναδεικνύει την κοινωνική καινοτομία ως μοχλό αναβάθμισης της ποιότητας ζωής αλλά και της ίδιας της διοίκησης της πόλης.</p>',1,'top_text',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',1,1,'{\"prepare_content\":\"0\",\"backgroundimage\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'el-GR'),(114,8441,'Best Practices','','<p>Through field research and interviews with groups of citizens who post their activities at synathina.gr, the synAthina team acknowledges the activities with the highest positive impact on the city. Every best practice of the civil society responds to the real challenges of the city and highlights social innovation as a lever to upgrade the quality of life and even the city\'s own administration.</p>',1,'top_text',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',1,1,'{\"prepare_content\":\"0\",\"backgroundimage\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'en-GB'),(115,8442,'Mobile Menu Greek','','',1,'mobilemenu',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_menu',1,0,'{\"menutype\":\"mainmenugreek\",\"base\":\"\",\"startLevel\":\"1\",\"endLevel\":\"0\",\"showAllChildren\":\"1\",\"tag_id\":\"\",\"class_sfx\":\"mobile-menu__list menu\",\"window_open\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"itemid\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'el-GR'),(116,8443,'Mobile Menu English','','',1,'mobilemenu',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_menu',1,0,'{\"menutype\":\"mainmenuenglish\",\"base\":\"\",\"startLevel\":\"1\",\"endLevel\":\"0\",\"showAllChildren\":\"1\",\"tag_id\":\"\",\"class_sfx\":\"mobile-menu__list menu\",\"window_open\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"itemid\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'en-GB'),(117,8444,'Top Menu Greek','','',1,'topmenu',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_menu',1,0,'{\"menutype\":\"topmenugreek\",\"base\":\"\",\"startLevel\":\"1\",\"endLevel\":\"1\",\"showAllChildren\":\"0\",\"tag_id\":\"\",\"class_sfx\":\"synathina-actions menu\",\"window_open\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"itemid\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'el-GR'),(118,8445,'Top Menu English','','',1,'topmenu',233,'2018-07-23 13:28:05','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_menu',1,0,'{\"menutype\":\"topmenuenglish\",\"base\":\"\",\"startLevel\":\"1\",\"endLevel\":\"1\",\"showAllChildren\":\"0\",\"tag_id\":\"\",\"class_sfx\":\"synathina-actions menu\",\"window_open\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"itemid\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'en-GB'),(119,8446,'Οι αριθμοί μιλούν','','<p>Από την έναρξη της λειτουργίας της, τον Ιούλιο του 2013, έως και σήμερα η ιστοσελίδα και η στέγη του συνΑθηνά έχουν φιλοξενήσει συνολικά <strong>{total_actions} δράσεις</strong> τις οποίες πραγματοποίησαν <strong>{total_teams} ομάδες</strong> πολιτών και φορείς σε συνεργασία με <strong>{total_donators} υποστηρικτές</strong>. Από τα στοιχεία που συλλέγουμε μέσα από τις δράσεις αντλούμε πολύτιμες πληροφορίες για τις προτεραιότητες των πολιτών.</p>',1,'top_text',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',1,1,'{\"prepare_content\":\"0\",\"backgroundimage\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'el-GR'),(120,8447,'What the numbers say','','<p>From when it was launched, in July 2013, up to this day, the webpage and the kiosk of synAthina have hosted <strong>{total_actions} activities</strong>&nbsp;which have been realized by <strong>{total_teams} groups</strong> of citizens and institutions in cooperation with <strong>{total_donators} sponsors</strong>. Based on the data we collect from the activities, we gather valuable information about the citizens’ priorities regarding their city.</p>',1,'top_text',0,'0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',1,'mod_custom',1,1,'{\"prepare_content\":\"0\",\"backgroundimage\":\"\",\"layout\":\"_:default\",\"moduleclass_sfx\":\"\",\"cache\":\"1\",\"cache_time\":\"900\",\"cachemode\":\"static\",\"module_tag\":\"div\",\"bootstrap_size\":\"0\",\"header_tag\":\"h3\",\"header_class\":\"\",\"style\":\"0\"}',0,'en-GB');
/*!40000 ALTER TABLE `prefi_modules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prefi_modules_menu`
--

DROP TABLE IF EXISTS `prefi_modules_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `prefi_modules_menu` (
  `moduleid` int(11) NOT NULL DEFAULT '0',
  `menuid` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`moduleid`,`menuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prefi_modules_menu`
--

LOCK TABLES `prefi_modules_menu` WRITE;
/*!40000 ALTER TABLE `prefi_modules_menu` DISABLE KEYS */;
INSERT INTO `prefi_modules_menu` VALUES (1,0),(2,0),(3,0),(4,0),(6,0),(7,0),(8,0),(9,0),(10,0),(12,0),(13,0),(14,0),(15,0),(16,0),(17,0),(79,0),(86,0),(87,0),(88,0),(89,0),(90,116),(90,117),(90,118),(90,119),(90,120),(90,121),(90,122),(90,126),(90,129),(90,130),(90,137),(90,138),(90,139),(90,140),(90,141),(90,143),(90,144),(90,145),(90,146),(90,147),(90,148),(90,150),(90,151),(90,152),(90,153),(90,154),(90,155),(90,156),(90,157),(90,158),(90,170),(90,171),(90,173),(90,174),(91,0),(92,0),(93,116),(94,116),(95,0),(96,0),(97,110),(98,0),(99,0),(100,0),(101,145),(101,156),(102,138),(103,0),(104,0),(105,148),(106,0),(107,155),(108,0),(109,145),(110,184),(110,191),(111,0),(112,0),(113,187),(114,193),(115,0),(116,0),(117,0),(118,0),(119,184),(120,191);
/*!40000 ALTER TABLE `prefi_modules_menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prefi_municipality_services`
--

DROP TABLE IF EXISTS `prefi_municipality_services`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `prefi_municipality_services` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(1000) NOT NULL,
  `email_name` varchar(1000) NOT NULL,
  `email` varchar(300) NOT NULL,
  `published` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prefi_municipality_services`
--

LOCK TABLES `prefi_municipality_services` WRITE;
/*!40000 ALTER TABLE `prefi_municipality_services` DISABLE KEYS */;
INSERT INTO `prefi_municipality_services` VALUES (1,'την αιγίδα του Δήμου Αθηναίων για τη δράση μου','την αιγίδα του Δήμου Αθηναίων για τη δράση μου','',0),(2,'να χρησιμοποιήσω έναν κοινόχρηστο χώρο για τη δράση  μου','χρήση κοινόχρηστου χώρου ','',0),(3,'να χρησιμοποιήσω ένα δημοτικό κτήριο για την υλοποίηση της δράσης μου','χρήση δημοτικού κτηρίου ','',0),(4,'να οργανώσω μια δράση φροντίδας σε χώρο πρασίνου του δήμου Αθηναίων','φροντίδα σε χώρο πρασίνου του δήμου Αθηναίων','',1),(5,'να οργανώσω μια δράση καθαριότητας σε χώρο εντός του δήμου Αθηναίων','καθαριότητα σε χώρο εντός του δήμου Αθηναίων','',1),(6,'να οργανώσω μια δράση φροντίδας παιδικής χαράς του δήμου Αθηναίων','φροντίδα παιδικής χαράς του δήμου Αθηναίων','',1),(7,'την  υποστήριξη των τεχνικών υπηρεσιών του δήμου Αθηναίων για τη δράση  μου','υποστήριξη των τεχνικών υπηρεσιών του δήμου Αθηναίων','',1),(8,'τη ρύθμιση της κυκλοφορίας / προσωρινή απαγόρευση της στάθμευσης σε δημόσιο χώρο που χρησιμοποιώ για τη δράση μου','τη ρύθμιση της κυκλοφορίας / προσωρινή απαγόρευση της στάθμευσης σε δημόσιο χώρο που χρησιμοποιώ για τη δράση μου','',1),(9,'τη συμμετοχή των μουσικών συνόλων του δήμου Αθηναίων/ ΟΠΑΝΔΑ στη δράση μου','τη συμμετοχή των μουσικών συνόλων του δήμου Αθηναίων/ ΟΠΑΝΔΑ στη δράση μου','',1),(10,'άλλο','άλλο','',1);
/*!40000 ALTER TABLE `prefi_municipality_services` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prefi_newsfeeds`
--

DROP TABLE IF EXISTS `prefi_newsfeeds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `prefi_newsfeeds` (
  `catid` int(11) NOT NULL DEFAULT '0',
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `alias` varchar(400) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `link` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `numarticles` int(10) unsigned NOT NULL DEFAULT '1',
  `cache_time` int(10) unsigned NOT NULL DEFAULT '3600',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `rtl` tinyint(4) NOT NULL DEFAULT '0',
  `access` int(10) unsigned NOT NULL DEFAULT '0',
  `language` char(7) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `params` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(10) unsigned NOT NULL DEFAULT '0',
  `created_by_alias` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(10) unsigned NOT NULL DEFAULT '0',
  `metakey` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `metadesc` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `metadata` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `xreference` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'A reference to enable linkages to external data sets.',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `version` int(10) unsigned NOT NULL DEFAULT '1',
  `hits` int(10) unsigned NOT NULL DEFAULT '0',
  `images` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_access` (`access`),
  KEY `idx_checkout` (`checked_out`),
  KEY `idx_state` (`published`),
  KEY `idx_catid` (`catid`),
  KEY `idx_createdby` (`created_by`),
  KEY `idx_language` (`language`),
  KEY `idx_xreference` (`xreference`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prefi_newsfeeds`
--

LOCK TABLES `prefi_newsfeeds` WRITE;
/*!40000 ALTER TABLE `prefi_newsfeeds` DISABLE KEYS */;
/*!40000 ALTER TABLE `prefi_newsfeeds` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prefi_newsletters`
--

DROP TABLE IF EXISTS `prefi_newsletters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `prefi_newsletters` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(300) NOT NULL,
  `status` tinyint(4) NOT NULL,
  `timestamp` varchar(20) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=794 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prefi_newsletters`
--

LOCK TABLES `prefi_newsletters` WRITE;
/*!40000 ALTER TABLE `prefi_newsletters` DISABLE KEYS */;
INSERT INTO `prefi_newsletters` VALUES (1,'test@synathina.gr',0,'1547127732');
/*!40000 ALTER TABLE `prefi_newsletters` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prefi_overrider`
--

DROP TABLE IF EXISTS `prefi_overrider`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `prefi_overrider` (
  `id` int(10) NOT NULL AUTO_INCREMENT COMMENT 'Primary Key',
  `constant` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `string` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `file` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2256 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prefi_overrider`
--

LOCK TABLES `prefi_overrider` WRITE;
/*!40000 ALTER TABLE `prefi_overrider` DISABLE KEYS */;
/*!40000 ALTER TABLE `prefi_overrider` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prefi_plg_system_adminexile`
--

DROP TABLE IF EXISTS `prefi_plg_system_adminexile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `prefi_plg_system_adminexile` (
  `ip` varchar(45) NOT NULL,
  `firstattempt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `lastattempt` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `attempts` int(11) NOT NULL,
  `penalty` int(11) NOT NULL,
  PRIMARY KEY (`ip`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prefi_plg_system_adminexile`
--

LOCK TABLES `prefi_plg_system_adminexile` WRITE;
/*!40000 ALTER TABLE `prefi_plg_system_adminexile` DISABLE KEYS */;
/*!40000 ALTER TABLE `prefi_plg_system_adminexile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prefi_plg_system_adminexile_tmpwhitelist`
--

DROP TABLE IF EXISTS `prefi_plg_system_adminexile_tmpwhitelist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `prefi_plg_system_adminexile_tmpwhitelist` (
  `ip` varchar(15) NOT NULL,
  `expire` datetime NOT NULL,
  PRIMARY KEY (`ip`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prefi_plg_system_adminexile_tmpwhitelist`
--

LOCK TABLES `prefi_plg_system_adminexile_tmpwhitelist` WRITE;
/*!40000 ALTER TABLE `prefi_plg_system_adminexile_tmpwhitelist` DISABLE KEYS */;
/*!40000 ALTER TABLE `prefi_plg_system_adminexile_tmpwhitelist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prefi_postinstall_messages`
--

DROP TABLE IF EXISTS `prefi_postinstall_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `prefi_postinstall_messages` (
  `postinstall_message_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `extension_id` bigint(20) NOT NULL DEFAULT '700' COMMENT 'FK to #__extensions',
  `title_key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'Lang key for the title',
  `description_key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'Lang key for description',
  `action_key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `language_extension` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'com_postinstall' COMMENT 'Extension holding lang keys',
  `language_client_id` tinyint(3) NOT NULL DEFAULT '1',
  `type` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'link' COMMENT 'Message type - message, link, action',
  `action_file` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT 'RAD URI to the PHP file containing action method',
  `action` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '' COMMENT 'Action method name or URL',
  `condition_file` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'RAD URI to file holding display condition method',
  `condition_method` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Display condition method, must return boolean',
  `version_introduced` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '3.2.0' COMMENT 'Version when this message was introduced',
  `enabled` tinyint(3) NOT NULL DEFAULT '1',
  PRIMARY KEY (`postinstall_message_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prefi_postinstall_messages`
--

LOCK TABLES `prefi_postinstall_messages` WRITE;
/*!40000 ALTER TABLE `prefi_postinstall_messages` DISABLE KEYS */;
INSERT INTO `prefi_postinstall_messages` VALUES (1,700,'PLG_TWOFACTORAUTH_TOTP_POSTINSTALL_TITLE','PLG_TWOFACTORAUTH_TOTP_POSTINSTALL_BODY','PLG_TWOFACTORAUTH_TOTP_POSTINSTALL_ACTION','plg_twofactorauth_totp',1,'action','site://plugins/twofactorauth/totp/postinstall/actions.php','twofactorauth_postinstall_action','site://plugins/twofactorauth/totp/postinstall/actions.php','twofactorauth_postinstall_condition','3.2.0',0),(2,700,'COM_CPANEL_WELCOME_BEGINNERS_TITLE','COM_CPANEL_WELCOME_BEGINNERS_MESSAGE','','com_cpanel',1,'message','','','','','3.2.0',0),(3,700,'COM_CPANEL_MSG_STATS_COLLECTION_TITLE','COM_CPANEL_MSG_STATS_COLLECTION_BODY','','com_cpanel',1,'message','','','admin://components/com_admin/postinstall/statscollection.php','admin_postinstall_statscollection_condition','3.5.0',0);
/*!40000 ALTER TABLE `prefi_postinstall_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prefi_redirect_links`
--

DROP TABLE IF EXISTS `prefi_redirect_links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `prefi_redirect_links` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `old_url` varchar(2048) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `new_url` varchar(2048) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `referer` varchar(2048) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `hits` int(10) unsigned NOT NULL DEFAULT '0',
  `published` tinyint(4) NOT NULL,
  `created_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `header` smallint(3) NOT NULL DEFAULT '301',
  PRIMARY KEY (`id`),
  KEY `idx_old_url` (`old_url`(100)),
  KEY `idx_link_modifed` (`modified_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prefi_redirect_links`
--

LOCK TABLES `prefi_redirect_links` WRITE;
/*!40000 ALTER TABLE `prefi_redirect_links` DISABLE KEYS */;
/*!40000 ALTER TABLE `prefi_redirect_links` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prefi_schemas`
--

DROP TABLE IF EXISTS `prefi_schemas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `prefi_schemas` (
  `extension_id` int(11) NOT NULL,
  `version_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`extension_id`,`version_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prefi_schemas`
--

LOCK TABLES `prefi_schemas` WRITE;
/*!40000 ALTER TABLE `prefi_schemas` DISABLE KEYS */;
INSERT INTO `prefi_schemas` VALUES (700,'3.5.0-2016-03-01'),(10000,'2.3.6'),(10031,'3.1-2013-04-29'),(10057,'');
/*!40000 ALTER TABLE `prefi_schemas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prefi_session`
--

DROP TABLE IF EXISTS `prefi_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `prefi_session` (
  `session_id` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `client_id` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `guest` tinyint(4) unsigned DEFAULT '1',
  `time` varchar(14) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `data` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `userid` int(11) DEFAULT '0',
  `username` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`session_id`),
  KEY `userid` (`userid`),
  KEY `time` (`time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prefi_session`
--

LOCK TABLES `prefi_session` WRITE;
/*!40000 ALTER TABLE `prefi_session` DISABLE KEYS */;
INSERT INTO `prefi_session` VALUES ('je4fe8kf4pc7rnktneen53o0e0',0,1,'1551262956','joomla|s:1848:\"TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjoyOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjE6e3M6OToiX19kZWZhdWx0IjtPOjg6InN0ZENsYXNzIjozOntzOjc6InNlc3Npb24iO086ODoic3RkQ2xhc3MiOjI6e3M6NzoiY291bnRlciI7aTo5O3M6NToidGltZXIiO086ODoic3RkQ2xhc3MiOjM6e3M6NToic3RhcnQiO2k6MTU1MTI2MTgzNDtzOjQ6Imxhc3QiO2k6MTU1MTI2MjI1ODtzOjM6Im5vdyI7aToxNTUxMjYyOTU1O319czo4OiJyZWdpc3RyeSI7TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjoyOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjE6e3M6MTU6ImNvbV9hdHRhY2htZW50cyI7Tzo4OiJzdGRDbGFzcyI6MTp7czoxMToiY3VycmVudF91cmwiO3M6MjA2OiImcmV0dXJuPWFIUjBjRG92TDNONWJtRjBhQzVuY2k5cGJtUmxlQzV3YUhBdlpXd3ZKVU5GSlVKR0pVTkZKVUpESlVORkpVRkRKVU5GSlVJMEpVTkZKVUkxSlVOR0pUZ3lMeVZEUlNWQ1JpVkRSU1ZDUXlWRFJTVkJReVZEUlNWQ05DVkRSU1ZDTlNWRFJpVTRNaTBsUTBZbE9EQWxRMFVsUWtZbFEwVWxRa0lsUTBVbFFqa2xRMFlsT0RRbFEwWWxPRVVsUTBVbFFrUSUyRiI7fX1zOjk6InNlcGFyYXRvciI7czoxOiIuIjt9czo0OiJ1c2VyIjtPOjU6IkpVc2VyIjoyNjp7czo5OiIAKgBpc1Jvb3QiO2I6MDtzOjI6ImlkIjtpOjA7czo0OiJuYW1lIjtOO3M6ODoidXNlcm5hbWUiO047czo1OiJlbWFpbCI7TjtzOjg6InBhc3N3b3JkIjtOO3M6MTQ6InBhc3N3b3JkX2NsZWFyIjtzOjA6IiI7czo1OiJibG9jayI7TjtzOjk6InNlbmRFbWFpbCI7aTowO3M6MTI6InJlZ2lzdGVyRGF0ZSI7TjtzOjEzOiJsYXN0dmlzaXREYXRlIjtOO3M6MTA6ImFjdGl2YXRpb24iO047czo2OiJwYXJhbXMiO047czo2OiJncm91cHMiO2E6MTp7aTowO3M6MToiOSI7fXM6NToiZ3Vlc3QiO2k6MTtzOjEzOiJsYXN0UmVzZXRUaW1lIjtOO3M6MTA6InJlc2V0Q291bnQiO047czoxMjoicmVxdWlyZVJlc2V0IjtOO3M6MTA6IgAqAF9wYXJhbXMiO086MjQ6Ikpvb21sYVxSZWdpc3RyeVxSZWdpc3RyeSI6Mjp7czo3OiIAKgBkYXRhIjtPOjg6InN0ZENsYXNzIjowOnt9czo5OiJzZXBhcmF0b3IiO3M6MToiLiI7fXM6MTQ6IgAqAF9hdXRoR3JvdXBzIjthOjI6e2k6MDtpOjE7aToxO2k6OTt9czoxNDoiACoAX2F1dGhMZXZlbHMiO2E6Mzp7aTowO2k6MTtpOjE7aToxO2k6MjtpOjU7fXM6MTU6IgAqAF9hdXRoQWN0aW9ucyI7TjtzOjEyOiIAKgBfZXJyb3JNc2ciO047czoxMzoiACoAdXNlckhlbHBlciI7TzoxODoiSlVzZXJXcmFwcGVySGVscGVyIjowOnt9czoxMDoiACoAX2Vycm9ycyI7YTowOnt9czozOiJhaWQiO2k6MDt9fX1zOjk6InNlcGFyYXRvciI7czoxOiIuIjt9\";',0,''),('udsupnn0sfji4mmiiachuuivg0',1,0,'1551263725','joomla|s:3456:\"TzoyNDoiSm9vbWxhXFJlZ2lzdHJ5XFJlZ2lzdHJ5IjoyOntzOjc6IgAqAGRhdGEiO086ODoic3RkQ2xhc3MiOjE6e3M6OToiX19kZWZhdWx0IjtPOjg6InN0ZENsYXNzIjozOntzOjc6InNlc3Npb24iO086ODoic3RkQ2xhc3MiOjM6e3M6NzoiY291bnRlciI7aToyMztzOjU6InRpbWVyIjtPOjg6InN0ZENsYXNzIjozOntzOjU6InN0YXJ0IjtpOjE1NTEyNjI5NjE7czo0OiJsYXN0IjtpOjE1NTEyNjM3MjQ7czozOiJub3ciO2k6MTU1MTI2MzcyNDt9czo1OiJ0b2tlbiI7czozMjoiOWlMajJDWElwM3dETFFvemM5N1dIVExaYTV4SFU0b1oiO31zOjg6InJlZ2lzdHJ5IjtPOjI0OiJKb29tbGFcUmVnaXN0cnlcUmVnaXN0cnkiOjI6e3M6NzoiACoAZGF0YSI7Tzo4OiJzdGRDbGFzcyI6Mzp7czoxODoicGxnX3N5c19hZG1pbmV4aWxlIjtPOjg6InN0ZENsYXNzIjoxOntzOjQ6ImNvcmUiO2I6MTt9czoxNToiY29tX2F0dGFjaG1lbnRzIjtPOjg6InN0ZENsYXNzIjoyOntzOjExOiJjdXJyZW50X3VybCI7czoxMTI6IiZyZXR1cm49YUhSMGNEb3ZMM041Ym1GMGFDNW5jaTloWkcxcGJtbHpkSEpoZEc5eUwybHVaR1Y0TG5Cb2NEOXZjSFJwYjI0OVkyOXRYMk52Ym5SbGJuUW1kbWxsZHoxaGNuUnBZMnhsY3clM0QlM0QiO3M6MTE6ImF0dGFjaG1lbnRzIjtPOjg6InN0ZENsYXNzIjo0OntzOjg6Im9yZGVyY29sIjtOO3M6MTA6ImxpbWl0c3RhcnQiO3M6MjoiNDAiO3M6NjoiZmlsdGVyIjtPOjg6InN0ZENsYXNzIjozOntzOjY6InNlYXJjaCI7czowOiIiO3M6NjoiZW50aXR5IjtzOjM6IkFMTCI7czoxMjoicGFyZW50X3N0YXRlIjtzOjM6IkFMTCI7fXM6OToib3JkZXJkaXJuIjtzOjA6IiI7fX1zOjExOiJjb21fY29udGVudCI7Tzo4OiJzdGRDbGFzcyI6Mjp7czo4OiJhcnRpY2xlcyI7Tzo4OiJzdGRDbGFzcyI6Mzp7czo2OiJmaWx0ZXIiO2E6ODp7czo2OiJzZWFyY2giO3M6MDoiIjtzOjk6InB1Ymxpc2hlZCI7czowOiIiO3M6MTE6ImNhdGVnb3J5X2lkIjtzOjA6IiI7czo2OiJhY2Nlc3MiO3M6MDoiIjtzOjg6Imxhbmd1YWdlIjtzOjA6IiI7czozOiJ0YWciO3M6MDoiIjtzOjk6ImF1dGhvcl9pZCI7czowOiIiO3M6NToibGV2ZWwiO3M6MDoiIjt9czo0OiJsaXN0IjthOjI6e3M6MTI6ImZ1bGxvcmRlcmluZyI7czo5OiJhLmlkIERFU0MiO3M6NToibGltaXQiO3M6MjoiMjAiO31zOjEwOiJsaW1pdHN0YXJ0IjtpOjIwO31zOjQ6ImVkaXQiO086ODoic3RkQ2xhc3MiOjE6e3M6NzoiYXJ0aWNsZSI7Tzo4OiJzdGRDbGFzcyI6Mjp7czoyOiJpZCI7YTowOnt9czo0OiJkYXRhIjtOO319fX1zOjk6InNlcGFyYXRvciI7czoxOiIuIjt9czo0OiJ1c2VyIjtPOjU6IkpVc2VyIjoyODp7czo5OiIAKgBpc1Jvb3QiO2I6MTtzOjI6ImlkIjtzOjM6IjIzMyI7czo0OiJuYW1lIjtzOjEwOiJTdXBlciBVc2VyIjtzOjg6InVzZXJuYW1lIjtzOjU6ImFkbWluIjtzOjU6ImVtYWlsIjtzOjE4OiJhZG1pbkBzeW5hdGhpbmEuZ3IiO3M6ODoicGFzc3dvcmQiO3M6NjA6IiQyeSQxMCRodnV6NkJlTkR1Unp4UXJaTUs5Wm8uQzlMNC9DS3ZxUThjNS50TkpkTUVBSmNhQ0w3b2tzdSI7czoxNDoicGFzc3dvcmRfY2xlYXIiO3M6MDoiIjtzOjU6ImJsb2NrIjtzOjE6IjAiO3M6OToic2VuZEVtYWlsIjtzOjE6IjEiO3M6MTI6InJlZ2lzdGVyRGF0ZSI7czoxOToiMjAxNi0wMy0yOCAxMDowODoxMCI7czoxMzoibGFzdHZpc2l0RGF0ZSI7czoxOToiMjAxOS0wMi0yNSAxMDo0ODoyMyI7czoxMDoiYWN0aXZhdGlvbiI7czoxOiIwIjtzOjY6InBhcmFtcyI7czo5NzoieyJhZG1pbl9zdHlsZSI6IiIsImFkbWluX2xhbmd1YWdlIjoiZW4tR0IiLCJsYW5ndWFnZSI6IiIsImVkaXRvciI6IiIsImhlbHBzaXRlIjoiIiwidGltZXpvbmUiOiIifSI7czo2OiJncm91cHMiO2E6MTp7aTo4O3M6MToiOCI7fXM6NToiZ3Vlc3QiO2k6MDtzOjEzOiJsYXN0UmVzZXRUaW1lIjtzOjE5OiIwMDAwLTAwLTAwIDAwOjAwOjAwIjtzOjEwOiJyZXNldENvdW50IjtzOjE6IjAiO3M6MTI6InJlcXVpcmVSZXNldCI7czoxOiIwIjtzOjEwOiIAKgBfcGFyYW1zIjtPOjI0OiJKb29tbGFcUmVnaXN0cnlcUmVnaXN0cnkiOjI6e3M6NzoiACoAZGF0YSI7Tzo4OiJzdGRDbGFzcyI6Njp7czoxMToiYWRtaW5fc3R5bGUiO3M6MDoiIjtzOjE0OiJhZG1pbl9sYW5ndWFnZSI7czo1OiJlbi1HQiI7czo4OiJsYW5ndWFnZSI7czowOiIiO3M6NjoiZWRpdG9yIjtzOjA6IiI7czo4OiJoZWxwc2l0ZSI7czowOiIiO3M6ODoidGltZXpvbmUiO3M6MDoiIjt9czo5OiJzZXBhcmF0b3IiO3M6MToiLiI7fXM6MTQ6IgAqAF9hdXRoR3JvdXBzIjthOjI6e2k6MDtpOjE7aToxO2k6ODt9czoxNDoiACoAX2F1dGhMZXZlbHMiO2E6NTp7aTowO2k6MTtpOjE7aToxO2k6MjtpOjI7aTozO2k6MztpOjQ7aTo2O31zOjE1OiIAKgBfYXV0aEFjdGlvbnMiO047czoxMjoiACoAX2Vycm9yTXNnIjtOO3M6MTM6IgAqAHVzZXJIZWxwZXIiO086MTg6IkpVc2VyV3JhcHBlckhlbHBlciI6MDp7fXM6MTA6IgAqAF9lcnJvcnMiO2E6MDp7fXM6MzoiYWlkIjtpOjA7czo2OiJvdHBLZXkiO3M6MDoiIjtzOjQ6Im90ZXAiO3M6MDoiIjt9fX1zOjk6InNlcGFyYXRvciI7czoxOiIuIjt9\";',233,'admin');
/*!40000 ALTER TABLE `prefi_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prefi_stegi`
--

DROP TABLE IF EXISTS `prefi_stegi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `prefi_stegi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `team_id` int(11) NOT NULL,
  `action_id` int(11) NOT NULL,
  `date_start` datetime NOT NULL,
  `date_end` datetime NOT NULL,
  `description` text NOT NULL,
  `test` int(11) NOT NULL,
  `published` tinyint(4) NOT NULL,
  `timestamp` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prefi_stegi`
--

LOCK TABLES `prefi_stegi` WRITE;
/*!40000 ALTER TABLE `prefi_stegi` DISABLE KEYS */;
/*!40000 ALTER TABLE `prefi_stegi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prefi_stegihours`
--

DROP TABLE IF EXISTS `prefi_stegihours`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `prefi_stegihours` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `asset_id` int(255) unsigned NOT NULL DEFAULT '0',
  `catid` int(11) NOT NULL,
  `team_id` int(11) NOT NULL,
  `name` varchar(1000) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `alias` varchar(500) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `title` varchar(1000) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `description` text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `date_start` datetime NOT NULL,
  `date_end` datetime NOT NULL,
  `action_id` int(11) NOT NULL,
  `published` int(11) NOT NULL,
  `access` int(11) NOT NULL,
  `ordering` int(11) NOT NULL,
  `language` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `created` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `modified` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `created_by` int(11) NOT NULL,
  `modified_by` int(11) NOT NULL,
  `publish_up` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `publish_down` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `checked_out` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2319 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prefi_stegihours`
--

LOCK TABLES `prefi_stegihours` WRITE;
/*!40000 ALTER TABLE `prefi_stegihours` DISABLE KEYS */;
/*!40000 ALTER TABLE `prefi_stegihours` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prefi_tags`
--

DROP TABLE IF EXISTS `prefi_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `prefi_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int(10) unsigned NOT NULL DEFAULT '0',
  `lft` int(11) NOT NULL DEFAULT '0',
  `rgt` int(11) NOT NULL DEFAULT '0',
  `level` int(10) unsigned NOT NULL DEFAULT '0',
  `path` varchar(400) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `alias` varchar(400) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `note` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `checked_out` int(11) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `access` int(10) unsigned NOT NULL DEFAULT '0',
  `params` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `metadesc` varchar(1024) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'The meta description for the page.',
  `metakey` varchar(1024) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'The meta keywords for the page.',
  `metadata` varchar(2048) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'JSON encoded metadata properties.',
  `created_user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `created_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by_alias` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `modified_user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `modified_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `images` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `urls` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `hits` int(10) unsigned NOT NULL DEFAULT '0',
  `language` char(7) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `version` int(10) unsigned NOT NULL DEFAULT '1',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `tag_idx` (`published`,`access`),
  KEY `idx_access` (`access`),
  KEY `idx_checkout` (`checked_out`),
  KEY `idx_path` (`path`(100)),
  KEY `idx_left_right` (`lft`,`rgt`),
  KEY `idx_alias` (`alias`(100)),
  KEY `idx_language` (`language`)
) ENGINE=InnoDB AUTO_INCREMENT=76 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prefi_tags`
--

LOCK TABLES `prefi_tags` WRITE;
/*!40000 ALTER TABLE `prefi_tags` DISABLE KEYS */;
INSERT INTO `prefi_tags` VALUES (1,0,0,149,0,'','ROOT','root','','',1,0,'0000-00-00 00:00:00',1,'','','','',42,'2011-01-01 00:00:01','',0,'0000-00-00 00:00:00','','',0,'*',1,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(2,1,1,2,1,'συναθηνά,','συνΑθηνά,','συναθηνά,','','',1,0,'2016-07-08 17:27:06',1,'{}','','','{}',233,'2016-07-08 17:27:06','',0,'2016-07-08 17:27:06','{}','{}',0,'*',1,'2016-07-08 17:27:06','2016-07-08 17:27:06'),(3,1,3,4,1,'city-makers,',' City Makers,','city-makers,','','',1,0,'2016-07-08 17:27:06',1,'{}','','','{}',233,'2016-07-08 17:27:06','',0,'2016-07-08 17:27:06','{}','{}',0,'*',1,'2016-07-08 17:27:06','2016-07-08 17:27:06'),(4,1,5,6,1,'amsterdam',' Amsterdam','amsterdam','','',1,0,'2016-07-08 17:27:06',1,'{}','','','{}',233,'2016-07-08 17:27:06','',0,'2016-07-08 17:27:06','{}','{}',0,'*',1,'2016-07-08 17:27:06','2016-07-08 17:27:06'),(5,1,7,8,1,'ενεργοί-πολίτες','ενεργοί πολίτες','ενεργοί-πολίτες','','',1,0,'2016-07-08 17:27:06',1,'{}','','','{}',233,'2016-07-08 17:27:06','',0,'2016-07-08 17:27:06','{}','{}',0,'*',1,'2016-07-08 17:27:06','2016-07-08 17:27:06'),(6,1,9,10,1,'κοινωνική-επιχειρηματικότητα,','κοινωνική επιχειρηματικότητα,','κοινωνική-επιχειρηματικότητα,','','',1,0,'2016-07-08 18:08:28',1,'{}','','','{}',233,'2016-07-08 18:08:28','',0,'2016-07-08 18:08:28','{}','{}',0,'*',1,'2016-07-08 18:08:28','2016-07-08 18:08:28'),(7,1,11,12,1,'κοινωνική-επιχείρηση,','κοινωνική επιχείρηση,','κοινωνική-επιχείρηση,','','',1,0,'2016-07-08 18:08:28',1,'{}','','','{}',233,'2016-07-08 18:08:28','',0,'2016-07-08 18:08:28','{}','{}',0,'*',1,'2016-07-08 18:08:28','2016-07-08 18:08:28'),(8,1,13,14,1,'κοινσεπ,','ΚΟΙΝΣΕΠ,','κοινσεπ,','','',1,0,'2016-07-08 18:08:28',1,'{}','','','{}',233,'2016-07-08 18:08:28','',0,'2016-07-08 18:08:28','{}','{}',0,'*',1,'2016-07-08 18:08:28','2016-07-08 18:08:28'),(10,1,17,18,1,'παγκόσμια-ημέρα-περιβάλλοντος,','παγκόσμια ημέρα περιβάλλοντος,','παγκόσμια-ημέρα-περιβάλλοντος,','','',1,0,'2016-07-08 19:53:04',1,'{}','','','{}',233,'2016-07-08 19:53:04','',0,'2016-07-08 19:53:04','{}','{}',0,'*',1,'2016-07-08 19:53:04','2016-07-08 19:53:04'),(11,1,19,20,1,'wwf-hellas,',' wwf hellas,','wwf-hellas,','','',1,0,'2016-07-08 19:53:04',1,'{}','','','{}',233,'2016-07-08 19:53:04','',0,'2016-07-08 19:53:04','{}','{}',0,'*',1,'2016-07-08 19:53:04','2016-07-08 19:53:04'),(13,1,23,24,1,'δήμος-αθηναίων,',' Δήμος Αθηναίων,','δήμος-αθηναίων,','','',1,0,'2016-07-08 19:53:04',1,'{}','','','{}',233,'2016-07-08 19:53:04','',0,'2016-07-08 19:53:04','{}','{}',0,'*',1,'2016-07-08 19:53:04','2016-07-08 19:53:04'),(14,1,25,26,1,'green-spaces',' green spaces','green-spaces','','',1,0,'2016-07-08 19:53:04',1,'{}','','','{}',233,'2016-07-08 19:53:04','',0,'2016-07-08 19:53:04','{}','{}',0,'*',1,'2016-07-08 19:53:04','2016-07-08 19:53:04'),(15,1,27,28,1,'οπανδα','ΟΠΑΝΔΑ','οπανδα','','',1,0,'2016-07-08 19:53:04',1,'{}','','','{}',233,'2016-07-08 19:53:04','',0,'2016-07-08 19:53:04','{}','{}',0,'*',1,'2016-07-08 19:53:04','2016-07-08 19:53:04'),(16,1,29,30,1,'monumenta','monumenta','monumenta','','',1,0,'2016-07-08 20:10:46',1,'{}','','','{}',233,'2016-07-08 20:10:46','',0,'2016-07-08 20:10:46','{}','{}',0,'*',1,'2016-07-08 20:10:46','2016-07-08 20:10:46'),(17,1,31,32,1,'open-house','open house','open-house','','',1,0,'2016-07-08 20:10:46',1,'{}','','','{}',233,'2016-07-08 20:10:46','',0,'2016-07-08 20:10:46','{}','{}',0,'*',1,'2016-07-08 20:10:46','2016-07-08 20:10:46'),(19,1,35,36,1,'ithaka-laundry','ithaka laundry','ithaka-laundry','','',1,0,'2016-07-08 20:42:49',1,'{}','','','{}',233,'2016-07-08 20:42:49','',0,'2016-07-08 20:42:49','{}','{}',0,'*',1,'2016-07-08 20:42:49','2016-07-08 20:42:49'),(20,1,37,38,1,'one-stop','one stop','one-stop','','',1,0,'2016-07-08 20:42:49',1,'{}','','','{}',233,'2016-07-08 20:42:49','',0,'2016-07-08 20:42:49','{}','{}',0,'*',1,'2016-07-08 20:42:49','2016-07-08 20:42:49'),(21,1,39,40,1,'share-to-dare','Share to dare','share-to-dare','','',1,0,'2016-07-08 20:42:49',1,'{}','','','{}',233,'2016-07-08 20:42:49','',0,'2016-07-08 20:42:49','{}','{}',0,'*',1,'2016-07-08 20:42:49','2016-07-08 20:42:49'),(22,1,41,42,1,'γέφυρα','Γέφυρα','γέφυρα','','',1,0,'2016-07-08 20:42:49',1,'{}','','','{}',233,'2016-07-08 20:42:49','',0,'2016-07-08 20:42:49','{}','{}',0,'*',1,'2016-07-08 20:42:49','2016-07-08 20:42:49'),(24,1,45,46,1,'κυαδα','ΚΥΑΔΑ','κυαδα','','',1,0,'2016-07-08 21:06:38',1,'{}','','','{}',233,'2016-07-08 21:06:38','',0,'2016-07-08 21:06:38','{}','{}',0,'*',1,'2016-07-08 21:06:38','2016-07-08 21:06:38'),(26,1,49,50,1,'athens-digital-arts-festival','athens digital arts festival','athens-digital-arts-festival','','',1,0,'2016-07-08 21:29:08',1,'{}','','','{}',233,'2016-07-08 21:29:08','',0,'2016-07-08 21:29:08','{}','{}',0,'*',1,'2016-07-08 21:29:08','2016-07-08 21:29:08'),(27,1,51,52,1,'arch-points','arch points','arch-points','','',1,0,'2016-07-08 21:29:08',1,'{}','','','{}',233,'2016-07-08 21:29:08','',0,'2016-07-08 21:29:08','{}','{}',0,'*',1,'2016-07-08 21:29:08','2016-07-08 21:29:08'),(29,1,55,56,1,'urban-dig','urban dig','urban-dig','','',1,0,'2016-07-08 21:29:08',1,'{}','','','{}',233,'2016-07-08 21:29:08','',0,'2016-07-08 21:29:08','{}','{}',0,'*',1,'2016-07-08 21:29:08','2016-07-08 21:29:08'),(30,1,57,58,1,'neon','neon','neon','','',1,0,'2016-07-08 21:29:08',1,'{}','','','{}',233,'2016-07-08 21:29:08','',0,'2016-07-08 21:29:08','{}','{}',0,'*',1,'2016-07-08 21:29:08','2016-07-08 21:29:08'),(32,1,61,62,1,'κυψέλη','Κυψέλη','κυψέλη','','',1,0,'2016-07-08 21:46:46',1,'{}','','','{}',233,'2016-07-08 21:46:46','',0,'2016-07-08 21:46:46','{}','{}',0,'*',1,'2016-07-08 21:46:46','2016-07-08 21:46:46'),(33,1,63,64,1,'community-project','Community project','community-project','','',1,0,'2016-07-08 21:46:46',1,'{}','','','{}',233,'2016-07-08 21:46:46','',0,'2016-07-08 21:46:46','{}','{}',0,'*',1,'2016-07-08 21:46:46','2016-07-08 21:46:46'),(34,1,65,66,1,'the-unseen','the unseen','the-unseen','','',1,0,'2016-07-08 22:16:40',1,'{}','','','{}',233,'2016-07-08 22:16:40','',0,'2016-07-08 22:16:40','{}','{}',0,'*',1,'2016-07-08 22:16:40','2016-07-08 22:16:40'),(35,1,67,68,1,'παρεα','ΠΑΡΕΑ','παρεα','','',1,0,'2016-07-08 22:16:40',1,'{}','','','{}',233,'2016-07-08 22:16:40','',0,'2016-07-08 22:16:40','{}','{}',0,'*',1,'2016-07-08 22:16:40','2016-07-08 22:16:40'),(36,1,69,70,1,'κοινωνία-των-πολιτών','κοινωνία των πολιτών','κοινωνία-των-πολιτών','','',1,0,'2016-07-12 21:41:50',1,'{}','','','{}',233,'2016-07-12 21:41:50','',0,'2016-07-12 21:41:50','{}','{}',0,'*',1,'2016-07-12 21:41:50','2016-07-12 21:41:50'),(37,1,71,72,1,'αλληλέγγυα','αλληλέγγυα','αλληλέγγυα','','',1,0,'2016-07-22 11:51:00',1,'{}','','','{}',233,'2016-07-22 11:51:00','',0,'2016-07-22 11:51:00','{}','{}',0,'*',1,'2016-07-22 11:51:00','2016-07-22 11:51:00'),(38,1,73,74,1,'πηγαία','πηγαία','πηγαία','','',1,0,'2016-07-22 11:51:00',1,'{}','','','{}',233,'2016-07-22 11:51:00','',0,'2016-07-22 11:51:00','{}','{}',0,'*',1,'2016-07-22 11:51:00','2016-07-22 11:51:00'),(39,1,75,76,1,'idea-camp','Idea Camp','idea-camp','','',1,0,'2016-07-29 09:58:38',1,'{}','','','{}',233,'2016-07-29 09:58:38','',0,'2016-07-29 09:58:38','{}','{}',0,'*',1,'2016-07-29 09:58:38','2016-07-29 09:58:38'),(40,1,77,78,1,'european-cultural-foundation','European Cultural Foundation','european-cultural-foundation','','',1,0,'2016-07-29 09:58:38',1,'{}','','','{}',233,'2016-07-29 09:58:38','',0,'2016-07-29 09:58:38','{}','{}',0,'*',1,'2016-07-29 09:58:38','2016-07-29 09:58:38'),(41,1,79,80,1,'sharing-economy,','sharing economy,','sharing-economy,','','',1,0,'2016-08-04 15:03:41',1,'{}','','','{}',233,'2016-08-04 15:03:41','',0,'2016-08-04 15:03:41','{}','{}',0,'*',1,'2016-08-04 15:03:41','2016-08-04 15:03:41'),(42,1,81,82,1,'εελ-λακ','ΕΕΛ/ΛΑΚ','εελ-λακ','','',1,0,'2016-08-04 15:03:41',1,'{}','','','{}',233,'2016-08-04 15:03:41','',0,'2016-08-04 15:03:41','{}','{}',0,'*',1,'2016-08-04 15:03:41','2016-08-04 15:03:41'),(44,1,85,86,1,'acro-market','acro market','acro-market','','',1,0,'2016-08-04 15:03:41',1,'{}','','','{}',233,'2016-08-04 15:03:41','',0,'2016-08-04 15:03:41','{}','{}',0,'*',1,'2016-08-04 15:03:41','2016-08-04 15:03:41'),(45,1,87,88,1,'trade-school-athens','trade school athens','trade-school-athens','','',1,0,'2016-08-04 15:03:41',1,'{}','','','{}',233,'2016-08-04 15:03:41','',0,'2016-08-04 15:03:41','{}','{}',0,'*',1,'2016-08-04 15:03:41','2016-08-04 15:03:41'),(46,1,89,90,1,'athens-fringe-network','athens fringe network','athens-fringe-network','','',1,0,'2016-08-04 15:03:41',1,'{}','','','{}',233,'2016-08-04 15:03:41','',0,'2016-08-04 15:03:41','{}','{}',0,'*',1,'2016-08-04 15:03:41','2016-08-04 15:03:41'),(47,1,91,92,1,'οικονομία-διαμοιρασμού','οικονομία διαμοιρασμού','οικονομία-διαμοιρασμού','','',1,0,'2016-08-04 15:03:41',1,'{}','','','{}',233,'2016-08-04 15:03:41','',0,'2016-08-04 15:03:41','{}','{}',0,'*',1,'2016-08-04 15:03:41','2016-08-04 15:03:41'),(48,1,93,94,1,'placemaking','placemaking','placemaking','','',1,0,'2016-08-08 10:05:30',1,'{}','','','{}',233,'2016-08-08 10:05:30','',0,'2016-08-08 10:05:30','{}','{}',0,'*',1,'2016-08-08 10:05:30','2016-08-08 10:05:30'),(49,1,95,96,1,'ideas-city','ideas city','ideas-city','','',1,0,'2016-09-28 12:30:21',1,'{}','','','{}',233,'2016-09-28 12:30:21','',0,'2016-09-28 12:30:21','{}','{}',0,'*',1,'2016-09-28 12:30:21','2016-09-28 12:30:21'),(50,1,97,98,1,'στέγη','Στέγη','στέγη','','',1,0,'2016-10-03 14:59:47',1,'{}','','','{}',233,'2016-10-03 14:59:47','',0,'2016-10-03 14:59:47','{}','{}',0,'*',1,'2016-10-03 14:59:47','2016-10-03 14:59:47'),(51,1,99,100,1,'πρόσφυγες','πρόσφυγες','πρόσφυγες','','',1,0,'2016-10-03 14:59:47',1,'{}','','','{}',233,'2016-10-03 14:59:47','',0,'2016-10-03 14:59:47','{}','{}',0,'*',1,'2016-10-03 14:59:47','2016-10-03 14:59:47'),(52,1,101,102,1,'bloomberg-philanthropies','bloomberg philanthropies','bloomberg-philanthropies','','',1,0,'2016-10-05 13:24:05',1,'{}','','','{}',233,'2016-10-05 13:24:05','',0,'2016-10-05 13:24:05','{}','{}',0,'*',1,'2016-10-05 13:24:05','2016-10-05 13:24:05'),(53,1,103,104,1,'khora','khora','khora','','',1,0,'2016-10-12 18:38:50',1,'{}','','','{}',233,'2016-10-12 18:38:50','',0,'2016-10-12 18:38:50','{}','{}',0,'*',1,'2016-10-12 18:38:50','2016-10-12 18:38:50'),(54,1,105,106,1,'campfire-innovation','campfire innovation','campfire-innovation','','',1,0,'2016-10-12 18:38:50',1,'{}','','','{}',233,'2016-10-12 18:38:50','',0,'2016-10-12 18:38:50','{}','{}',0,'*',1,'2016-10-12 18:38:50','2016-10-12 18:38:50'),(55,1,107,108,1,'impact-hub','impact hub','impact-hub','','',1,0,'2016-10-12 18:38:50',1,'{}','','','{}',233,'2016-10-12 18:38:50','',0,'2016-10-12 18:38:50','{}','{}',0,'*',1,'2016-10-12 18:38:50','2016-10-12 18:38:50'),(56,1,109,110,1,'solomon','solomon','solomon','','',1,0,'2016-10-12 18:38:50',1,'{}','','','{}',233,'2016-10-12 18:38:50','',0,'2016-10-12 18:38:50','{}','{}',0,'*',1,'2016-10-12 18:38:50','2016-10-12 18:38:50'),(60,1,117,118,1,'eurocities','Eurocities','eurocities','','',1,0,'2016-10-24 13:23:29',1,'{}','','','{}',233,'2016-10-24 13:23:29','',0,'2016-10-24 13:23:29','{}','{}',0,'*',1,'2016-10-24 13:23:29','2016-10-24 13:23:29'),(61,1,119,120,1,'creative-citizenship','creative citizenship','creative-citizenship','','',1,0,'2016-10-24 13:23:29',1,'{}','','','{}',233,'2016-10-24 13:23:29','',0,'2016-10-24 13:23:29','{}','{}',0,'*',1,'2016-10-24 13:23:29','2016-10-24 13:23:29'),(62,1,121,122,1,'urbact','Urbact','urbact','','',1,0,'2016-10-24 13:23:29',1,'{}','','','{}',233,'2016-10-24 13:23:29','',0,'2016-10-24 13:23:29','{}','{}',0,'*',1,'2016-10-24 13:23:29','2016-10-24 13:23:29'),(63,1,123,124,1,'ανοιχτά-σχολεία','Ανοιχτά Σχολεία','ανοιχτά-σχολεία','','',1,0,'2016-10-26 12:34:11',1,'{}','','','{}',233,'2016-10-26 12:34:11','',0,'2016-10-26 12:34:11','{}','{}',0,'*',1,'2016-10-26 12:34:11','2016-10-26 12:34:11'),(64,1,125,126,1,'βιώσιμη-διατροφή','βιώσιμη διατροφή','βιώσιμη-διατροφή','','',1,0,'2016-11-04 14:14:10',1,'{}','','','{}',233,'2016-11-04 14:14:10','',0,'2016-11-04 14:14:10','{}','{}',0,'*',1,'2016-11-04 14:14:10','2016-11-04 14:14:10'),(65,1,127,128,1,'καλές-πρακτικές','καλές πρακτικές','καλές-πρακτικές','','',1,0,'2016-11-04 14:14:10',1,'{}','','','{}',233,'2016-11-04 14:14:10','',0,'2016-11-04 14:14:10','{}','{}',0,'*',1,'2016-11-04 14:14:10','2016-11-04 14:14:10'),(66,1,129,130,1,'πλατεία-καλλιγά','Πλατεία Καλλιγά','πλατεία-καλλιγά','','',1,0,'2016-11-06 21:47:34',1,'{}','','','{}',233,'2016-11-06 21:47:34','',0,'2016-11-06 21:47:34','{}','{}',0,'*',1,'2016-11-06 21:47:34','2016-11-06 21:47:34'),(67,1,131,132,1,'νόμος','νόμος','νόμος','','',1,0,'2016-11-11 10:38:13',1,'{}','','','{}',233,'2016-11-11 10:38:13','',0,'2016-11-11 10:38:13','{}','{}',0,'*',1,'2016-11-11 10:38:13','2016-11-11 10:38:13'),(68,1,133,134,1,'ίδρυμα-μποδοσάκη','Ίδρυμα Μποδοσάκη','ίδρυμα-μποδοσάκη','','',1,0,'2016-11-11 14:17:35',1,'{}','','','{}',233,'2016-11-11 14:17:35','',0,'2016-11-11 14:17:35','{}','{}',0,'*',1,'2016-11-11 14:17:35','2016-11-11 14:17:35'),(69,1,135,136,1,'είμαστε-όλοι-πολίτες','είμαστε όλοι πολίτες','είμαστε-όλοι-πολίτες','','',1,0,'2016-11-11 14:17:35',1,'{}','','','{}',233,'2016-11-11 14:17:35','',0,'2016-11-11 14:17:35','{}','{}',0,'*',1,'2016-11-11 14:17:35','2016-11-11 14:17:35'),(70,1,137,138,1,'ορχήστρα-των-χωμάτων','ορχήστρα των χωμάτων','ορχήστρα-των-χωμάτων','','',1,0,'2016-11-18 11:17:03',1,'{}','','','{}',233,'2016-11-18 11:17:03','',0,'2016-11-18 11:17:03','{}','{}',0,'*',1,'2016-11-18 11:17:03','2016-11-18 11:17:03'),(71,1,139,140,1,'social-dynamo','social dynamo','social-dynamo','','',1,0,'2016-11-22 16:41:00',1,'{}','','','{}',233,'2016-11-22 16:41:00','',0,'2016-11-22 16:41:00','{}','{}',0,'*',1,'2016-11-22 16:41:00','2016-11-22 16:41:00'),(72,1,141,142,1,'δημοτική-αγορά-κυψέλης','δημοτική αγορά κυψέλης','δημοτική-αγορά-κυψέλης','','',1,0,'2016-11-29 14:12:15',1,'{}','','','{}',233,'2016-11-29 14:12:15','',0,'2016-11-29 14:12:15','{}','{}',0,'*',1,'2016-11-29 14:12:15','2016-11-29 14:12:15'),(73,1,143,144,1,'mayors-challenge','mayors challenge','mayors-challenge','','',1,0,'2016-12-02 15:02:55',1,'{}','','','{}',233,'2016-12-02 15:02:55','',0,'2016-12-02 15:02:55','{}','{}',0,'*',1,'2016-12-02 15:02:55','2016-12-02 15:02:55'),(75,1,147,148,1,'καθαριότητα','καθαριότητα','καθαριότητα','','',1,0,'2016-12-05 12:44:24',1,'{}','','','{}',233,'2016-12-05 12:44:24','',0,'2016-12-05 12:44:24','{}','{}',0,'*',1,'2016-12-05 12:44:24','2016-12-05 12:44:24');
/*!40000 ALTER TABLE `prefi_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prefi_team_activities`
--

DROP TABLE IF EXISTS `prefi_team_activities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `prefi_team_activities` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(1000) NOT NULL,
  `name_en` varchar(200) NOT NULL,
  `image` varchar(300) NOT NULL DEFAULT 'images/activities/',
  `color` varchar(10) NOT NULL,
  `published` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prefi_team_activities`
--

LOCK TABLES `prefi_team_activities` WRITE;
/*!40000 ALTER TABLE `prefi_team_activities` DISABLE KEYS */;
INSERT INTO `prefi_team_activities` VALUES (1,'ΑΛΛΗΛΕΓΓΥΗ','SOLIDARITY','images/activities/1.png','6da9a4',1),(2,'ΠΟΛΙΤΙΣΜΟΣ','CULTURE','images/activities/2.png','be5d33',1),(4,'ΟΙΚΟΝΟΜΙΑ','ECONOMY','images/activities/3.png','ab6ad1',1),(5,'ΔΗΜΟΣΙΟΣ ΧΩΡΟΣ','PUBLIC SPACE','images/activities/6.png','ff9933',1),(6,'ΠΕΡΙΒΑΛΛΟΝ','ENVIRONMENT','images/activities/4.png','41c241',1),(7,'ΤΕΧΝΟΛΟΓΙΑ','TECHNOLOGY','images/activities/7.png','6851ff',1),(8,'ΥΓΕΙΑ','HEALTH','images/activities/8.png','1d9ee5',1),(9,'ΕΚΠΑΙΔΕΥΣΗ / ΕΝΗΜΕΡΩΣΗ','EDUCATION / INFORMATION','images/activities/9.png','c29950',1),(10,'ΤΟΥΡΙΣΜΟΣ','TOURISM','images/activities/10.png','d1b700',1),(11,'ΠΑΙΔΙ','CHILDREN','images/activities/5.png','dfb0dc',1),(12,'ΜΕΤΑΝΑΣΤΕΣ & ΠΡΟΣΦΥΓΕΣ','REFUGEES & IMMIGRANTS','images/activities/11.png','6da9a4',1);
/*!40000 ALTER TABLE `prefi_team_activities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prefi_team_donation_types`
--

DROP TABLE IF EXISTS `prefi_team_donation_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `prefi_team_donation_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL,
  `name` varchar(1000) NOT NULL,
  `name_en` varchar(200) NOT NULL,
  `published` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prefi_team_donation_types`
--

LOCK TABLES `prefi_team_donation_types` WRITE;
/*!40000 ALTER TABLE `prefi_team_donation_types` DISABLE KEYS */;
INSERT INTO `prefi_team_donation_types` VALUES (1,0,'Προσφορά σε είδος/υπηρεσία',' In-kind support (Goods & Services)',1),(2,1,'Κατασκευαστικά υλικά','Construction materials',1),(3,1,'Βιβλία / γραφική ύλη','Books/Stationery',1),(4,1,'Έπιπλα / οικιακά σκεύη','Furniture/Homeware',1),(5,1,'Οπτικοακουστικά μέσα','Audiovisual material',1),(6,1,'Παιχνίδια','Toys',1),(7,1,'Ρουχισμός','Clothing',1),(8,1,'Σεντόνια / πετσέτες / κουβέρτες','Sheets/towels/blankets',1),(9,1,'Τεχνολογικός εξοπλισμός / εξοπλισμός για συναυλίες','Technological equipment / equipment for concerts',1),(10,1,'Τρόφιμα','Food',1),(11,1,'Υλικά καθαρισμού','Cleaning products',1),(12,1,'Φάρμακα / νοσηλευτικό υλικό','Medicines and Nursing products',1),(13,1,'Φυτά','Plants',1),(14,1,'Χώρος','Space',0),(15,1,'Μεταφορά','Transportation',1),(16,0,'Προσφορά σε τεχνογνωσία','Know-how',1),(17,16,'Νομική υποστήριξη','Legal support',1),(18,16,'Λογιστική υποστήριξη','Accounting support',1),(19,16,'Επικοινωνία','Communication',1),(20,16,'Project management και οργάνωση event','Project management and Events organization',1),(21,16,'Διαχείριση ανθρώπινων πόρων','Human resource management',1),(22,16,'Σύνταξη business plan και χρηματοδοτικής πρότασης','Business plan and Funding proposal development',1),(23,16,'Χρήση Η/Υ και ψηφιακές εφαρμογές','Computer and Technological applications',1),(24,16,'Αρχιτεκτονικές και τεχνικές μελέτες','Architecture and Construction counseling',1),(25,16,'Επιλογή και χρήση τεχνικών υλικών','Choice and use of materials',1),(26,16,'Γραφικές τέχνες','Graphic design',1),(27,0,'Εθελοντές','Volunteers',1),(28,0,'Χρηματική χορηγία','Donation',1),(31,0,'Προσφορά σε φυτά','',0),(32,0,'Χώρος','Space',1),(35,1,'Είδη προσωπικής υγιεινής','Personal hygiene products',1),(36,1,'Διερμηνεία-Μετάφραση','Interpretation/Translation',1);
/*!40000 ALTER TABLE `prefi_team_donation_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prefi_team_files`
--

DROP TABLE IF EXISTS `prefi_team_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `prefi_team_files` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `team_id` int(11) NOT NULL,
  `path` varchar(1000) NOT NULL,
  `ordering` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prefi_team_files`
--

LOCK TABLES `prefi_team_files` WRITE;
/*!40000 ALTER TABLE `prefi_team_files` DISABLE KEYS */;
/*!40000 ALTER TABLE `prefi_team_files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prefi_team_photos`
--

DROP TABLE IF EXISTS `prefi_team_photos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `prefi_team_photos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `team_id` int(11) NOT NULL,
  `path` varchar(1000) NOT NULL,
  `ordering` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=349 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prefi_team_photos`
--

LOCK TABLES `prefi_team_photos` WRITE;
/*!40000 ALTER TABLE `prefi_team_photos` DISABLE KEYS */;
/*!40000 ALTER TABLE `prefi_team_photos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prefi_team_types`
--

DROP TABLE IF EXISTS `prefi_team_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `prefi_team_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(1000) NOT NULL,
  `published` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prefi_team_types`
--

LOCK TABLES `prefi_team_types` WRITE;
/*!40000 ALTER TABLE `prefi_team_types` DISABLE KEYS */;
INSERT INTO `prefi_team_types` VALUES (1,'Σωματείο\n',1),(2,'ΚοινΣΕπ',1),(4,'AMKE',1);
/*!40000 ALTER TABLE `prefi_team_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prefi_teams`
--

DROP TABLE IF EXISTS `prefi_teams`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `prefi_teams` (
  `id` int(11) NOT NULL DEFAULT '0',
  `asset_id` int(255) unsigned NOT NULL DEFAULT '0',
  `catid` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `name` varchar(1000) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `alias` varchar(500) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `title` varchar(1000) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `create_actions` tinyint(4) NOT NULL,
  `support_actions` tinyint(4) NOT NULL,
  `legal_form` tinyint(2) NOT NULL,
  `profit` tinyint(4) NOT NULL,
  `profit_id` int(11) NOT NULL,
  `profit_custom` varchar(200) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `team_or_org` tinyint(2) NOT NULL,
  `activities` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `org_donation` varchar(200) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `donation_eidos` varchar(1000) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `donation_technology` varchar(1000) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `description` text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `logo` varchar(1000) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `web_link` varchar(1000) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `fb_link` varchar(1000) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `tw_link` varchar(1000) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `pn_link` varchar(1000) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `in_link` varchar(1000) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `go_link` varchar(1000) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `li_link` varchar(1000) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `yt_link` varchar(1000) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `contact_1_name` varchar(150) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `contact_1_email` varchar(150) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `contact_1_phone` varchar(150) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `contact_2_name` varchar(150) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `contact_2_email` varchar(150) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `contact_2_phone` varchar(150) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `contact_3_name` varchar(150) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `contact_3_email` varchar(150) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `contact_3_phone` varchar(150) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `newsletter` tinyint(2) NOT NULL,
  `hidden` tinyint(4) NOT NULL DEFAULT '0',
  `timestamp` varchar(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `published` int(11) NOT NULL,
  `access` int(11) NOT NULL,
  `ordering` int(11) NOT NULL,
  `language` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `created` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `modified` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `created_by` int(11) NOT NULL,
  `modified_by` int(11) NOT NULL,
  `publish_up` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `publish_down` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `checked_out` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prefi_teams`
--

LOCK TABLES `prefi_teams` WRITE;
/*!40000 ALTER TABLE `prefi_teams` DISABLE KEYS */;
INSERT INTO `prefi_teams` VALUES (523,0,0,757,'ΚΩΝΣΤΑΝΤΙΝΟΣ','konstantinos_757','',0,1,0,1,0,'',13,'6,7,','16,23,','','','<p>Περιγραφικό κείμενο ! //k/</p>','','','','','','','','','','ΚΩΝΣΤΑΝΤΙΝΟΣ','aaaa@diamand.gr','6937351046','','','','','','',1,1,'1549970369',1,1,512,'*','2019-02-12 11:19:29','',757,0,'','','');
/*!40000 ALTER TABLE `prefi_teams` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prefi_template_styles`
--

DROP TABLE IF EXISTS `prefi_template_styles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `prefi_template_styles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `template` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `client_id` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `home` char(7) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `params` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_template` (`template`),
  KEY `idx_home` (`home`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prefi_template_styles`
--

LOCK TABLES `prefi_template_styles` WRITE;
/*!40000 ALTER TABLE `prefi_template_styles` DISABLE KEYS */;
INSERT INTO `prefi_template_styles` VALUES (8,'isis',1,'1','isis - Default','{\"templateColor\":\"\",\"logoFile\":\"\"}'),(9,'synathina',0,'1','synathina - Default','');
/*!40000 ALTER TABLE `prefi_template_styles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prefi_ucm_base`
--

DROP TABLE IF EXISTS `prefi_ucm_base`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `prefi_ucm_base` (
  `ucm_id` int(10) unsigned NOT NULL,
  `ucm_item_id` int(10) NOT NULL,
  `ucm_type_id` int(11) NOT NULL,
  `ucm_language_id` int(11) NOT NULL,
  PRIMARY KEY (`ucm_id`),
  KEY `idx_ucm_item_id` (`ucm_item_id`),
  KEY `idx_ucm_type_id` (`ucm_type_id`),
  KEY `idx_ucm_language_id` (`ucm_language_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prefi_ucm_base`
--

LOCK TABLES `prefi_ucm_base` WRITE;
/*!40000 ALTER TABLE `prefi_ucm_base` DISABLE KEYS */;
/*!40000 ALTER TABLE `prefi_ucm_base` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prefi_ucm_content`
--

DROP TABLE IF EXISTS `prefi_ucm_content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `prefi_ucm_content` (
  `core_content_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `core_type_alias` varchar(400) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'FK to the content types table',
  `core_title` varchar(400) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `core_alias` varchar(400) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '',
  `core_body` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `core_state` tinyint(1) NOT NULL DEFAULT '0',
  `core_checked_out_time` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `core_checked_out_user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `core_access` int(10) unsigned NOT NULL DEFAULT '0',
  `core_params` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `core_featured` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `core_metadata` varchar(2048) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'JSON encoded metadata properties.',
  `core_created_user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `core_created_by_alias` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `core_created_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `core_modified_user_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Most recent user that modified',
  `core_modified_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `core_language` char(7) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `core_publish_up` datetime NOT NULL,
  `core_publish_down` datetime NOT NULL,
  `core_content_item_id` int(10) unsigned DEFAULT NULL COMMENT 'ID from the individual type table',
  `asset_id` int(10) unsigned DEFAULT NULL COMMENT 'FK to the #__assets table.',
  `core_images` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `core_urls` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `core_hits` int(10) unsigned NOT NULL DEFAULT '0',
  `core_version` int(10) unsigned NOT NULL DEFAULT '1',
  `core_ordering` int(11) NOT NULL DEFAULT '0',
  `core_metakey` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `core_metadesc` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `core_catid` int(10) unsigned NOT NULL DEFAULT '0',
  `core_xreference` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'A reference to enable linkages to external data sets.',
  `core_type_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`core_content_id`),
  KEY `tag_idx` (`core_state`,`core_access`),
  KEY `idx_access` (`core_access`),
  KEY `idx_alias` (`core_alias`(100)),
  KEY `idx_language` (`core_language`),
  KEY `idx_title` (`core_title`(100)),
  KEY `idx_modified_time` (`core_modified_time`),
  KEY `idx_created_time` (`core_created_time`),
  KEY `idx_content_type` (`core_type_alias`(100)),
  KEY `idx_core_modified_user_id` (`core_modified_user_id`),
  KEY `idx_core_checked_out_user_id` (`core_checked_out_user_id`),
  KEY `idx_core_created_user_id` (`core_created_user_id`),
  KEY `idx_core_type_id` (`core_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Contains core content data in name spaced fields';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prefi_ucm_content`
--

LOCK TABLES `prefi_ucm_content` WRITE;
/*!40000 ALTER TABLE `prefi_ucm_content` DISABLE KEYS */;
/*!40000 ALTER TABLE `prefi_ucm_content` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prefi_ucm_history`
--

DROP TABLE IF EXISTS `prefi_ucm_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `prefi_ucm_history` (
  `version_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ucm_item_id` int(10) unsigned NOT NULL,
  `ucm_type_id` int(10) unsigned NOT NULL,
  `version_note` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'Optional version name',
  `save_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `editor_user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `character_count` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Number of characters in this version.',
  `sha1_hash` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'SHA1 hash of the version_data column.',
  `version_data` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'json-encoded string of version data',
  `keep_forever` tinyint(4) NOT NULL DEFAULT '0' COMMENT '0=auto delete; 1=keep',
  PRIMARY KEY (`version_id`),
  KEY `idx_ucm_item_id` (`ucm_type_id`,`ucm_item_id`),
  KEY `idx_save_date` (`save_date`)
) ENGINE=InnoDB AUTO_INCREMENT=2169 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prefi_ucm_history`
--

LOCK TABLES `prefi_ucm_history` WRITE;
/*!40000 ALTER TABLE `prefi_ucm_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `prefi_ucm_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prefi_update_sites`
--

DROP TABLE IF EXISTS `prefi_update_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `prefi_update_sites` (
  `update_site_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `location` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `enabled` int(11) DEFAULT '0',
  `last_check_timestamp` bigint(20) DEFAULT '0',
  `extra_query` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`update_site_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Update Sites';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prefi_update_sites`
--

LOCK TABLES `prefi_update_sites` WRITE;
/*!40000 ALTER TABLE `prefi_update_sites` DISABLE KEYS */;
INSERT INTO `prefi_update_sites` VALUES (1,'Core Core','collection','http://update.joomla.org/core/list.xml',1,0,''),(2,'Core Extension Directory','collection','http://update.joomla.org/jed/list.xml',1,1467066598,''),(3,'Accredited Core Translations','collection','http://update.joomla.org/language/translationlist_3.xml',1,0,''),(4,'Core Update Component Update Site','extension','http://update.joomla.org/core/extensions/com_joomlaupdate.xml',1,0,''),(7,'JCE Editor Updates','extension','https://www.joomlacontenteditor.net/index.php?option=com_updates&view=update&format=xml&id=1&file=extension.xml',1,0,''),(8,'Attachments Updates','extension','http://jmcameron.net/attachments/updates/updates.xml',1,0,'');
/*!40000 ALTER TABLE `prefi_update_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prefi_update_sites_extensions`
--

DROP TABLE IF EXISTS `prefi_update_sites_extensions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `prefi_update_sites_extensions` (
  `update_site_id` int(11) NOT NULL DEFAULT '0',
  `extension_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`update_site_id`,`extension_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Links extensions to update sites';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prefi_update_sites_extensions`
--

LOCK TABLES `prefi_update_sites_extensions` WRITE;
/*!40000 ALTER TABLE `prefi_update_sites_extensions` DISABLE KEYS */;
INSERT INTO `prefi_update_sites_extensions` VALUES (1,700),(2,700),(3,600),(3,10018),(4,28),(7,10019),(8,10032);
/*!40000 ALTER TABLE `prefi_update_sites_extensions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prefi_updates`
--

DROP TABLE IF EXISTS `prefi_updates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `prefi_updates` (
  `update_id` int(11) NOT NULL AUTO_INCREMENT,
  `update_site_id` int(11) DEFAULT '0',
  `extension_id` int(11) DEFAULT '0',
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `element` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `folder` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `client_id` tinyint(3) DEFAULT '0',
  `version` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `data` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `detailsurl` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `infourl` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `extra_query` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`update_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Available Updates';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prefi_updates`
--

LOCK TABLES `prefi_updates` WRITE;
/*!40000 ALTER TABLE `prefi_updates` DISABLE KEYS */;
/*!40000 ALTER TABLE `prefi_updates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prefi_user_keys`
--

DROP TABLE IF EXISTS `prefi_user_keys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `prefi_user_keys` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` varchar(400) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `series` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `invalid` tinyint(4) NOT NULL,
  `time` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `uastring` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `series` (`series`),
  UNIQUE KEY `series_2` (`series`),
  UNIQUE KEY `series_3` (`series`),
  KEY `user_id` (`user_id`(100))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prefi_user_keys`
--

LOCK TABLES `prefi_user_keys` WRITE;
/*!40000 ALTER TABLE `prefi_user_keys` DISABLE KEYS */;
/*!40000 ALTER TABLE `prefi_user_keys` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prefi_user_notes`
--

DROP TABLE IF EXISTS `prefi_user_notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `prefi_user_notes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `catid` int(10) unsigned NOT NULL DEFAULT '0',
  `subject` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `body` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `state` tinyint(3) NOT NULL DEFAULT '0',
  `checked_out` int(10) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `created_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_user_id` int(10) unsigned NOT NULL,
  `modified_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `review_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_category_id` (`catid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prefi_user_notes`
--

LOCK TABLES `prefi_user_notes` WRITE;
/*!40000 ALTER TABLE `prefi_user_notes` DISABLE KEYS */;
/*!40000 ALTER TABLE `prefi_user_notes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prefi_user_profiles`
--

DROP TABLE IF EXISTS `prefi_user_profiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `prefi_user_profiles` (
  `user_id` int(11) NOT NULL,
  `profile_key` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `profile_value` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `ordering` int(11) NOT NULL DEFAULT '0',
  UNIQUE KEY `idx_user_id_profile_key` (`user_id`,`profile_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Simple user profile storage table';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prefi_user_profiles`
--

LOCK TABLES `prefi_user_profiles` WRITE;
/*!40000 ALTER TABLE `prefi_user_profiles` DISABLE KEYS */;
/*!40000 ALTER TABLE `prefi_user_profiles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prefi_user_usergroup_map`
--

DROP TABLE IF EXISTS `prefi_user_usergroup_map`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `prefi_user_usergroup_map` (
  `user_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Foreign Key to #__users.id',
  `group_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Foreign Key to #__usergroups.id',
  PRIMARY KEY (`user_id`,`group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prefi_user_usergroup_map`
--

LOCK TABLES `prefi_user_usergroup_map` WRITE;
/*!40000 ALTER TABLE `prefi_user_usergroup_map` DISABLE KEYS */;
INSERT INTO `prefi_user_usergroup_map` VALUES (233,8),(756,10),(756,13),(757,10),(757,13);
/*!40000 ALTER TABLE `prefi_user_usergroup_map` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prefi_usergroups`
--

DROP TABLE IF EXISTS `prefi_usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `prefi_usergroups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Primary Key',
  `parent_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Adjacency List Reference Id',
  `lft` int(11) NOT NULL DEFAULT '0' COMMENT 'Nested set lft.',
  `rgt` int(11) NOT NULL DEFAULT '0' COMMENT 'Nested set rgt.',
  `title` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_usergroup_parent_title_lookup` (`parent_id`,`title`),
  KEY `idx_usergroup_title_lookup` (`title`),
  KEY `idx_usergroup_adjacency_lookup` (`parent_id`),
  KEY `idx_usergroup_nested_set_lookup` (`lft`,`rgt`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prefi_usergroups`
--

LOCK TABLES `prefi_usergroups` WRITE;
/*!40000 ALTER TABLE `prefi_usergroups` DISABLE KEYS */;
INSERT INTO `prefi_usergroups` VALUES (1,0,1,26,'Public'),(2,1,8,23,'Registered'),(3,2,9,14,'Author'),(4,3,10,13,'Editor'),(5,4,11,12,'Publisher'),(6,1,4,7,'Manager'),(7,6,5,6,'Administrator'),(8,1,24,25,'Super Users'),(9,1,2,3,'Guest'),(10,2,19,20,'Ομάδα πολιτών'),(11,2,21,22,'Φορέας/Οργανισμός'),(12,2,15,16,'Επιχείριση/Εταιρεία'),(13,2,17,18,'Ιδιώτης/Δημότης');
/*!40000 ALTER TABLE `prefi_usergroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prefi_users`
--

DROP TABLE IF EXISTS `prefi_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `prefi_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(400) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `username` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `password` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `block` tinyint(4) NOT NULL DEFAULT '0',
  `sendEmail` tinyint(4) DEFAULT '0',
  `registerDate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `lastvisitDate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `activation` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `params` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `lastResetTime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Date of last password reset',
  `resetCount` int(11) NOT NULL DEFAULT '0' COMMENT 'Count of password resets since lastResetTime',
  `otpKey` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'Two factor authentication encrypted keys',
  `otep` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'One time emergency passwords',
  `requireReset` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'Require user to reset password on next login',
  PRIMARY KEY (`id`),
  KEY `idx_name` (`name`(100)),
  KEY `idx_block` (`block`),
  KEY `username` (`username`),
  KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=758 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prefi_users`
--

LOCK TABLES `prefi_users` WRITE;
/*!40000 ALTER TABLE `prefi_users` DISABLE KEYS */;
INSERT INTO `prefi_users` VALUES (233,'Super User','admin','admin@synathina.gr','$2y$10$hvuz6BeNDuRzxQrZMK9Zo.C9L4/CKvqQ8c5.tNJdMEAJcaCL7oksu',0,1,'2016-03-28 10:08:10','2019-02-27 10:22:46','0','{\"admin_style\":\"\",\"admin_language\":\"en-GB\",\"language\":\"\",\"editor\":\"\",\"helpsite\":\"\",\"timezone\":\"\"}','0000-00-00 00:00:00',0,'','',0),(756,'Demo Team','aa@synathina.gr','aa@synathina.gr','$2y$10$0J.RcWxnMQiXZ1KD3fLJEu8KO4xGCqjw0ZdouYXg12xHj0T0QXt9a',0,0,'2019-02-01 12:19:53','2019-02-04 08:38:05','','{\"admin_style\":\"\",\"admin_language\":\"\",\"language\":\"\",\"editor\":\"\",\"helpsite\":\"\",\"timezone\":\"\"}','0000-00-00 00:00:00',0,'','',0),(757,'Demo Team2','aaaa@synathina.gr','aaaa@synathina.gr','$2y$10$qUcI0F57UHznQutif.bPveOQdMXzCzgiFijWcX/7VC6T0JdJt1Nrq',0,0,'2019-02-12 11:19:29','2019-02-13 08:32:00','','{\"admin_style\":\"\",\"admin_language\":\"\",\"language\":\"\",\"editor\":\"\",\"helpsite\":\"\",\"timezone\":\"\"}','0000-00-00 00:00:00',0,'','',0);
/*!40000 ALTER TABLE `prefi_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prefi_utf8_conversion`
--

DROP TABLE IF EXISTS `prefi_utf8_conversion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `prefi_utf8_conversion` (
  `converted` tinyint(4) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prefi_utf8_conversion`
--

LOCK TABLES `prefi_utf8_conversion` WRITE;
/*!40000 ALTER TABLE `prefi_utf8_conversion` DISABLE KEYS */;
INSERT INTO `prefi_utf8_conversion` VALUES (2);
/*!40000 ALTER TABLE `prefi_utf8_conversion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prefi_viewlevels`
--

DROP TABLE IF EXISTS `prefi_viewlevels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `prefi_viewlevels` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Primary Key',
  `title` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `rules` varchar(5120) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'JSON encoded access control.',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_assetgroup_title_lookup` (`title`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prefi_viewlevels`
--

LOCK TABLES `prefi_viewlevels` WRITE;
/*!40000 ALTER TABLE `prefi_viewlevels` DISABLE KEYS */;
INSERT INTO `prefi_viewlevels` VALUES (1,'Public',0,'[1]'),(2,'Registered',2,'[6,2,8]'),(3,'Special',3,'[6,3,8]'),(5,'Guest',1,'[9]'),(6,'Super Users',4,'[8]');
/*!40000 ALTER TABLE `prefi_viewlevels` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prefi_wf_profiles`
--

DROP TABLE IF EXISTS `prefi_wf_profiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `prefi_wf_profiles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `users` text NOT NULL,
  `types` text NOT NULL,
  `components` text NOT NULL,
  `area` tinyint(3) NOT NULL,
  `device` varchar(255) NOT NULL,
  `rows` text NOT NULL,
  `plugins` text NOT NULL,
  `published` tinyint(3) NOT NULL,
  `ordering` int(11) NOT NULL,
  `checked_out` tinyint(3) NOT NULL,
  `checked_out_time` datetime NOT NULL,
  `params` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prefi_wf_profiles`
--

LOCK TABLES `prefi_wf_profiles` WRITE;
/*!40000 ALTER TABLE `prefi_wf_profiles` DISABLE KEYS */;
INSERT INTO `prefi_wf_profiles` VALUES (1,'Default','Default Profile for all users','','6,7,3,4,5,8','',0,'desktop,tablet,phone','undo,redo,spacer,bold,italic,underline,strikethrough,justifyfull,justifycenter,justifyleft,justifyright,spacer;spacer,clipboard,lists,sub,sup,charmap,hr,fontsizeselect;anchor,unlink,link,imgmanager,spellchecker','clipboard,lists,charmap,hr,fontsizeselect,anchor,link,imgmanager,spellchecker,browser,contextmenu,inlinepopups,media',1,1,0,'0000-00-00 00:00:00','{\"media\":{\"iframes\":\"1\"},\"editor\":{\"extended_elements\":\"i\"},\"fontsizeselect\":{\"font_sizes\":\"8px,9px,10px,11px,12px,13px,14px,15px,16px,17px,18px,19px,20px,21px,22px,23px,24px\"}}'),(2,'Front End','Sample Front-end Profile','','9,3,4,5,12,10,11','',1,'desktop,tablet,phone','undo,redo,spacer,bold,spacer,link,unlink','link,inlinepopups',1,2,0,'0000-00-00 00:00:00','{\"editor\":{\"toggle\":\"0\",\"cdata\":\"1\",\"verify_html\":\"0\"},\"link\":{\"file_browser\":\"0\",\"tabs_advanced\":\"0\",\"attributes_anchor\":\"0\",\"attributes_target\":\"0\",\"links\":{\"joomlalinks\":{\"enable\":\"0\"}},\"popups\":{\"jcemediabox\":{\"enable\":\"0\"},\"window\":{\"enable\":\"0\"}},\"search\":{\"link\":{\"enable\":\"0\"}},\"target\":\"_blank\"}}'),(3,'Blogger','Simple Blogging Profile','','3,4,5,6,8,7','',0,'desktop,tablet,phone','bold,italic,strikethrough,lists,blockquote,spacer,justifyleft,justifycenter,justifyright,spacer,link,unlink,imgmanager,article,spellchecker,fullscreen,kitchensink;formatselect,styleselect,underline,justifyfull,clipboard,removeformat,charmap,indent,outdent,undo,redo,help','link,imgmanager,article,spellchecker,fullscreen,kitchensink,clipboard,contextmenu,inlinepopups,lists,formatselect,styleselect',0,3,0,'0000-00-00 00:00:00','{\"editor\":{\"toggle\":\"0\"}}'),(4,'Mobile','Sample Mobile Profile','','3,4,5,6,8,7','',0,'tablet,phone','undo,redo,spacer,bold,italic,underline,formatselect,spacer,justifyleft,justifycenter,justifyfull,justifyright,spacer,fullscreen,kitchensink;styleselect,lists,spellchecker,article,link,unlink','fullscreen,kitchensink,spellchecker,article,link,inlinepopups,lists,formatselect,styleselect',0,4,0,'0000-00-00 00:00:00','{\"editor\":{\"toolbar_theme\":\"mobile\",\"resizing\":\"0\",\"resize_horizontal\":\"0\",\"resizing_use_cookie\":\"0\",\"toggle\":\"0\",\"links\":{\"popups\":{\"default\":\"\",\"jcemediabox\":{\"enable\":\"0\"},\"window\":{\"enable\":\"0\"}}}}}');
/*!40000 ALTER TABLE `prefi_wf_profiles` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-02-27 12:51:32
